package com.waleed.remix

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.widget.Toast
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PrivacyTip
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.core.os.LocaleListCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun RemixApp(
    vm: RemixViewModel,
    onShowInterstitial: () -> Unit,
    isRewardedReady: () -> Boolean,
    onShowRewarded: (onResult: (earned: Boolean) -> Unit) -> Unit,
) {
    val context = LocalContext.current
    var showPrivacy by remember { mutableStateOf(false) }
    var showSaveDialog by remember { mutableStateOf(false) }
    var pendingExport by remember { mutableStateOf(false) }
    var pendingPro by remember { mutableStateOf(false) }

    // اختيار الوسائط: الأساسي (يستبدل) والإضافي (يضيف)
    val pickMulti = rememberLauncherForActivityResult(
        ActivityResultContracts.PickMultipleVisualMedia(4),
    ) { uris -> if (uris.isNotEmpty()) vm.replaceUris(uris) }
    val pickMore = rememberLauncherForActivityResult(
        ActivityResultContracts.PickMultipleVisualMedia(4),
    ) { uris -> if (uris.isNotEmpty()) vm.addUris(uris) }
    val pickOne = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia(),
    ) { uri -> if (uri != null) vm.addUris(listOf(uri)) }
    // ضغط الفيديو: اختيار فيديو واحد فقط
    val pickVideo = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia(),
    ) { uri -> if (uri != null) vm.replaceUris(listOf(uri)) }
    val videoOnly = PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
    val both = PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo)
    val pickAudio = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument(),
    ) { uri -> if (uri != null) vm.importAudio(uri) }

    val storagePermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { granted -> if (granted && pendingExport) vm.export(pendingPro); pendingExport = false }

    // إذن الإشعارات (أندرويد 13+) لإشعار التقدّم
    val notifPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    fun startExport(pro: Boolean) {
        val needsPermission = Build.VERSION.SDK_INT < Build.VERSION_CODES.Q &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_EXTERNAL_STORAGE) !=
            PackageManager.PERMISSION_GRANTED
        if (needsPermission) {
            pendingExport = true
            pendingPro = pro
            storagePermission.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        } else {
            vm.export(pro)
        }
    }

    fun onExportClick() {
        if (vm.isBusy()) {
            Toast.makeText(context, context.getString(R.string.merge_busy), Toast.LENGTH_LONG).show()
            return
        }
        showSaveDialog = true
    }

    // لو حاول المستخدم بدء عملية وفي عملية شغالة (حتى من نسخة سابقة للتطبيق)
    LaunchedEffect(vm.busyNotice) {
        if (vm.busyNotice) {
            Toast.makeText(context, context.getString(R.string.merge_busy), Toast.LENGTH_LONG).show()
            vm.consumeBusyNotice()
        }
    }

    BackHandler(enabled = vm.screen == Screen.PREVIEW) { vm.screen = Screen.HOME }

    val isArabic = LocalConfiguration.current.locales[0].language == "ar"

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                modifier = Modifier.statusBarsPadding(),
                title = { Text(stringResource(R.string.app_name)) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    titleContentColor = MaterialTheme.colorScheme.primary,
                ),
                actions = {
                    TextButton(onClick = {
                        AppCompatDelegate.setApplicationLocales(
                            LocaleListCompat.forLanguageTags(if (isArabic) "en" else "ar"),
                        )
                    }) {
                        Icon(Icons.Default.Language, contentDescription = stringResource(R.string.language))
                        Spacer(Modifier.size(4.dp))
                        Text(if (isArabic) "EN" else "ع")
                    }
                    IconButton(onClick = { showPrivacy = true }) {
                        Icon(Icons.Default.PrivacyTip, contentDescription = stringResource(R.string.privacy))
                    }
                },
            )
        },
        bottomBar = {
            Box(Modifier.navigationBarsPadding()) { BannerAd() }
        },
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            when (vm.screen) {
                Screen.HOME -> HomeScreen(
                    vm = vm,
                    onPickMain = { if (vm.mode == RemixMode.COMPRESS) pickVideo.launch(videoOnly) else pickMulti.launch(both) },
                    onPickAudio = { pickAudio.launch(arrayOf("audio/*")) },
                    onPickMore = {
                        val room = vm.maxItems - vm.items.size
                        if (room >= 2) pickMore.launch(both) else if (room == 1) pickOne.launch(both)
                    },
                    onExport = ::onExportClick,
                )
                Screen.PREVIEW -> PreviewScreen(vm = vm, onExport = ::onExportClick)
            }
        }
    }

    if (showSaveDialog) {
        val online = isOnline(context)
        val rewardedReady = online && isRewardedReady()
        AlertDialog(
            onDismissRequest = { showSaveDialog = false },
            title = { Text(stringResource(R.string.save_dialog_title)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = {
                            showSaveDialog = false
                            onShowInterstitial() // إعلان بيني أثناء انتظار الدمج
                            startExport(pro = false)
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text(stringResource(R.string.save_free)) }
                    Button(
                        onClick = {
                            showSaveDialog = false
                            onShowRewarded { earned -> startExport(pro = earned) }
                        },
                        enabled = rewardedReady,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.secondary,
                            contentColor = Color.White,
                        ),
                    ) { Text(stringResource(R.string.save_pro)) }
                    if (!online) {
                        Text(stringResource(R.string.no_internet_pro), style = MaterialTheme.typography.bodySmall)
                    } else if (!rewardedReady) {
                        Text(stringResource(R.string.ad_not_ready), style = MaterialTheme.typography.bodySmall)
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showSaveDialog = false }) { Text(stringResource(R.string.close)) }
            },
        )
    }

    if (showPrivacy) PrivacyDialog(context) { showPrivacy = false }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun HomeScreen(
    vm: RemixViewModel,
    onPickMain: () -> Unit,
    onPickMore: () -> Unit,
    onPickAudio: () -> Unit,
    onExport: () -> Unit,
) {
    val busy = vm.compressing || vm.exportState is ExportState.Running
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text(
            stringResource(R.string.offline_note),
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.primary,
        )
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = vm.mode == RemixMode.MERGE,
                onClick = { vm.switchMode(RemixMode.MERGE) },
                enabled = !busy,
                label = { Text(stringResource(R.string.mode_merge)) },
            )
            FilterChip(
                selected = vm.mode == RemixMode.CONCAT,
                onClick = { vm.switchMode(RemixMode.CONCAT) },
                enabled = !busy,
                label = { Text(stringResource(R.string.mode_concat)) },
            )
            FilterChip(
                selected = vm.mode == RemixMode.COMPRESS,
                onClick = { vm.switchMode(RemixMode.COMPRESS) },
                enabled = !busy,
                label = { Text(stringResource(R.string.mode_compress)) },
            )
        }
        Text(
            stringResource(
                when (vm.mode) {
                    RemixMode.MERGE -> R.string.intro
                    RemixMode.CONCAT -> R.string.intro_concat
                    RemixMode.COMPRESS -> R.string.intro_compress
                },
            ),
            style = MaterialTheme.typography.bodyMedium,
        )
        Text(
            stringResource(
                when (vm.mode) {
                    RemixMode.MERGE -> R.string.limits_note
                    RemixMode.CONCAT -> R.string.limits_concat
                    RemixMode.COMPRESS -> R.string.limits_compress
                },
            ),
            style = MaterialTheme.typography.bodySmall,
        )
        if (vm.weakDevice && vm.mode == RemixMode.MERGE) {
            Text(
                stringResource(R.string.weak_note),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.primary,
            )
        }
        if (vm.skippedDevice > 0) {
            Text(stringResource(R.string.weak_skipped, vm.skippedDevice), color = Color(0xFFFF6B6B))
        }

        Button(onClick = onPickMain, enabled = !busy, modifier = Modifier.fillMaxWidth().height(52.dp)) {
            Icon(Icons.Default.VideoLibrary, null)
            Spacer(Modifier.size(8.dp))
            Text(stringResource(if (vm.mode == RemixMode.COMPRESS) R.string.upload_compress else R.string.upload_main))
        }
        if (vm.mode != RemixMode.COMPRESS) {
            OutlinedButton(
                onClick = onPickMore,
                enabled = vm.items.isNotEmpty() && vm.items.size < vm.maxItems && !busy,
                modifier = Modifier.fillMaxWidth().height(52.dp),
            ) {
                Icon(Icons.Default.AddPhotoAlternate, null)
                Spacer(Modifier.size(8.dp))
                Text(stringResource(R.string.add_more))
            }
        }

        if (vm.compressing) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    stringResource(
                        R.string.compressing,
                        vm.compressIndex,
                        vm.compressTotal,
                        (vm.compressProgress * 100).toInt(),
                    ),
                )
                LinearProgressIndicator(progress = { vm.compressProgress }, modifier = Modifier.fillMaxWidth())
                OutlinedButton(onClick = { vm.cancel() }, modifier = Modifier.fillMaxWidth()) {
                    Text(stringResource(R.string.cancel))
                }
            }
        }
        if (vm.skippedLong > 0) {
            Text(stringResource(R.string.too_long, vm.skippedLong), color = Color(0xFFFF6B6B))
        }

        if (vm.items.isEmpty()) {
            Text(stringResource(R.string.empty_state), color = MaterialTheme.colorScheme.onSurface.copy(alpha = .6f))
        } else {
            Text(stringResource(R.string.selected_items, vm.items.size), style = MaterialTheme.typography.titleSmall)
            var photoCount = 0
            var videoCount = 0
            vm.items.forEachIndexed { i, item ->
                val label = if (item.isVideo) {
                    videoCount++
                    stringResource(R.string.video_n, videoCount, formatDuration(item.durationMs))
                } else {
                    photoCount++
                    stringResource(R.string.photo_n, photoCount)
                }
                val isPrimary = i == vm.primaryIndex
                val tag = if (isPrimary) stringResource(R.string.tag_main) else stringResource(R.string.tag_secondary)
                ItemRow(
                    number = i + 1,
                    item = item,
                    label = label,
                    tag = tag,
                    isPrimary = isPrimary,
                    onSetPrimary = { vm.selectPrimary(i) },
                    enabled = !busy,
                    canUp = i > 0,
                    canDown = i < vm.items.lastIndex,
                    onUp = { vm.move(i, -1) },
                    onDown = { vm.move(i, 1) },
                    onRemove = { vm.removeAt(i) },
                )
            }
        }

        if (vm.canExport) {
            if (vm.mode == RemixMode.MERGE) {
                Text(stringResource(R.string.layout_title), style = MaterialTheme.typography.titleSmall)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    vm.availableLayouts.forEach { l ->
                        FilterChip(
                            selected = vm.layout == l,
                            onClick = { vm.selectLayout(l) },
                            label = { Text(stringResource(l.labelRes)) },
                        )
                    }
                }
            }

            if (vm.mode == RemixMode.MERGE && vm.layout?.isPip == true) {
                Text(stringResource(R.string.pip_title), style = MaterialTheme.typography.titleSmall)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PipCorner.values().forEach { c ->
                        FilterChip(
                            selected = vm.pipCorner == c,
                            onClick = { vm.selectPipCorner(c) },
                            label = { Text(stringResource(c.labelRes)) },
                        )
                    }
                }
            }

            if (vm.mode == RemixMode.COMPRESS) {
                CompressLevelChips(vm, enabled = !busy)
            } else {
                Text(stringResource(R.string.fit_title), style = MaterialTheme.typography.titleSmall)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = vm.fitFull,
                        onClick = { vm.selectFit(true) },
                        label = { Text(stringResource(R.string.fit_full)) },
                    )
                    FilterChip(
                        selected = !vm.fitFull,
                        onClick = { vm.selectFit(false) },
                        label = { Text(stringResource(R.string.fit_fill)) },
                    )
                }

                Text(stringResource(R.string.audio_title), style = MaterialTheme.typography.titleSmall)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (vm.mode == RemixMode.MERGE) {
                        vm.items.forEachIndexed { i, item ->
                            if (item.isVideo) {
                                FilterChip(
                                    selected = vm.audioIndex == i,
                                    onClick = { vm.selectAudio(i) },
                                    label = { Text(stringResource(R.string.audio_item, i + 1)) },
                                )
                            }
                        }
                    } else {
                        FilterChip(
                            selected = vm.audioChoice != -1 && vm.audioChoice != AUDIO_PHONE,
                            onClick = { vm.selectAudio(0) },
                            label = { Text(stringResource(R.string.audio_original)) },
                        )
                    }
                    FilterChip(
                        selected = vm.audioChoice == -1,
                        onClick = { vm.selectAudio(-1) },
                        label = { Text(stringResource(R.string.audio_none)) },
                    )
                    if (vm.extraAudioUri != null) {
                        FilterChip(
                            selected = vm.audioChoice == AUDIO_PHONE,
                            onClick = { vm.selectAudio(AUDIO_PHONE) },
                            label = { Text(stringResource(R.string.sound_chip, vm.extraAudioName), maxLines = 1) },
                        )
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(onClick = onPickAudio, enabled = !busy, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Default.MusicNote, null)
                        Spacer(Modifier.size(8.dp))
                        Text(stringResource(R.string.add_sound))
                    }
                    if (vm.extraAudioUri != null) {
                        IconButton(onClick = { vm.removeExtraAudio() }, enabled = !busy) {
                            Icon(Icons.Default.Close, contentDescription = stringResource(R.string.remove))
                        }
                    }
                }

                OutlinedButton(onClick = { vm.reverse() }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.SwapVert, null)
                    Spacer(Modifier.size(8.dp))
                    Text(stringResource(R.string.reverse))
                }
            }
            ExportSection(vm, onExport)
        } else if (vm.items.size == 1 && vm.mode != RemixMode.COMPRESS) {
            Text(stringResource(R.string.need_two), color = MaterialTheme.colorScheme.primary)
        }

        if (vm.items.isNotEmpty()) {
            TextButton(onClick = { vm.clearAll() }, enabled = !busy) {
                Text(stringResource(R.string.clear_all))
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun ItemRow(
    number: Int,
    item: MediaEntry,
    label: String,
    tag: String,
    isPrimary: Boolean,
    onSetPrimary: () -> Unit,
    enabled: Boolean,
    canUp: Boolean,
    canDown: Boolean,
    onUp: () -> Unit,
    onDown: () -> Unit,
    onRemove: () -> Unit,
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(14.dp),
    ) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(52.dp).clip(RoundedCornerShape(10.dp)).background(MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center,
            ) {
                if (item.isVideo) {
                    Icon(Icons.Default.Movie, null, tint = MaterialTheme.colorScheme.primary)
                } else {
                    AsyncImage(
                        model = item.uri,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize(),
                    )
                }
            }
            Spacer(Modifier.size(12.dp))
            Column(Modifier.weight(1f)) {
                Text("$number. $label")
                // زر اختيار العنصر الأساسي: النص تحته (أساسي / فرعي) يتغير حسب الاختيار
                FilterChip(
                    selected = isPrimary,
                    onClick = onSetPrimary,
                    enabled = enabled,
                    label = { Text(tag, style = MaterialTheme.typography.labelSmall) },
                    leadingIcon = {
                        Icon(
                            Icons.Default.Star,
                            contentDescription = stringResource(R.string.set_primary),
                            modifier = Modifier.size(16.dp),
                        )
                    },
                )
            }
            IconButton(onClick = onUp, enabled = enabled && canUp) {
                Icon(Icons.Default.ArrowUpward, contentDescription = stringResource(R.string.move_up))
            }
            IconButton(onClick = onDown, enabled = enabled && canDown) {
                Icon(Icons.Default.ArrowDownward, contentDescription = stringResource(R.string.move_down))
            }
            IconButton(onClick = onRemove, enabled = enabled) {
                Icon(
                    Icons.Default.Delete,
                    contentDescription = stringResource(R.string.remove),
                    tint = if (enabled) Color(0xFFFF6B6B) else MaterialTheme.colorScheme.onSurface.copy(alpha = .3f),
                )
            }
        }
    }
}

@Composable
private fun ExportSection(vm: RemixViewModel, onExport: () -> Unit) {
    val context = LocalContext.current
    when (val s = vm.exportState) {
        is ExportState.Running -> {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(stringResource(R.string.exporting, (s.progress * 100).toInt()))
                LinearProgressIndicator(progress = { s.progress }, modifier = Modifier.fillMaxWidth())
                Text(stringResource(R.string.keep_open), style = MaterialTheme.typography.labelSmall)
                Text(stringResource(R.string.merge_busy), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                OutlinedButton(onClick = { vm.cancel() }, modifier = Modifier.fillMaxWidth()) {
                    Text(stringResource(R.string.cancel))
                }
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { BannerAd(medium = true) }
            }
        }
        else -> {
            Button(
                onClick = onExport,
                enabled = !vm.compressing,
                modifier = Modifier.fillMaxWidth().height(56.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.secondary,
                    contentColor = Color.White,
                ),
            ) {
                Icon(Icons.Default.Save, null)
                Spacer(Modifier.size(8.dp))
                Text(stringResource(R.string.export_btn))
            }
            if (s is ExportState.Done) {
                Text(stringResource(R.string.saved), color = MaterialTheme.colorScheme.primary)
                if (vm.outputBytes > 0) {
                    Text(
                        stringResource(R.string.output_size, formatSize(vm.outputBytes)),
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
                TextButton(onClick = {
                    val intent = Intent(Intent.ACTION_VIEW).setDataAndType(s.uri, "video/mp4")
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    try { context.startActivity(intent) } catch (_: Exception) {}
                }) { Text(stringResource(R.string.open_video)) }
            }
            if (s is ExportState.Error) {
                Text(stringResource(R.string.error_fmt, s.message), color = Color(0xFFFF6B6B))
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun PreviewScreen(vm: RemixViewModel, onExport: () -> Unit) {
    val layout = vm.activeLayout
    val busy = vm.compressing || vm.exportState is ExportState.Running
    Column(
        Modifier.fillMaxSize().padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        if (vm.mode == RemixMode.MERGE && vm.canExport) {
            // تغيير شكل الدمج مباشرة من المعاينة
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                vm.availableLayouts.forEach { l ->
                    FilterChip(
                        selected = vm.layout == l,
                        onClick = { vm.selectLayout(l) },
                        enabled = !busy,
                        label = { Text(stringResource(l.labelRes)) },
                    )
                }
            }
        }
        if (vm.mode == RemixMode.COMPRESS) {
            val item = vm.items.firstOrNull()
            if (item != null) {
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    val ratio = if (item.width > 0 && item.height > 0) item.width.toFloat() / item.height else 9f / 16f
                    VideoCell(
                        item.uri,
                        muted = false,
                        fit = true,
                        modifier = Modifier.aspectRatio(ratio).clip(RoundedCornerShape(12.dp)).background(Color.Black),
                    )
                }
                CompressLevelChips(vm, enabled = !busy)
            }
        } else if (layout != null && vm.canExport) {
            val audioIdx = vm.audioIndex
            val fit = vm.fitFull
            val allMuted = vm.audioChoice == -1 || vm.audioChoice == AUDIO_PHONE
            if (vm.weakDevice) {
                Text(
                    stringResource(R.string.weak_preview),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary,
                )
            }
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                // نثبّت الاتجاه LTR حتى تطابق المعاينة الفيديو الناتج في العربي أيضًا
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    BoxWithConstraints(
                        Modifier
                            .aspectRatio(layout.canvasW.toFloat() / layout.canvasH)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.Black),
                    ) {
                        val w = maxWidth
                        val h = maxHeight
                        if (layout.isSequential) {
                            SequenceCell(
                                entries = vm.mergeOrder.map { vm.items[it] },
                                muted = allMuted,
                                fit = fit,
                                modifier = Modifier.fillMaxSize(),
                            )
                        } else run {
                            // العنصر الأساسي يظهر في الخلية الأولى، ثم باقي العناصر بترتيبها
                            val order = vm.mergeOrder
                            layout.cells(vm.pipCorner).forEachIndexed { i, c ->
                                val srcIdx = order[i]
                                val item = vm.items[srcIdx]
                                Box(
                                    Modifier
                                        .offset(w * c.x, h * c.y)
                                        .size(w * c.w, h * c.h)
                                        .background(Color.Black),
                                ) {
                                    if (item.isVideo) {
                                        VideoCell(item.uri, muted = srcIdx != audioIdx, fit = fit, modifier = Modifier.fillMaxSize())
                                    } else {
                                        AsyncImage(
                                            model = item.uri,
                                            contentDescription = null,
                                            contentScale = if (fit) ContentScale.Fit else ContentScale.Crop,
                                            modifier = Modifier.fillMaxSize(),
                                        )
                                    }
                                }
                            }
                        }
                        // العلامة المائية (معاينة): أيقونة التطبيق شبه شفافة في المنتصف
                        Image(
                            painter = painterResource(R.drawable.watermark_logo),
                            contentDescription = null,
                            modifier = Modifier.align(Alignment.Center).fillMaxWidth(0.55f).alpha(0.4f),
                        )
                    }
                }
            }
        }
        if (vm.mode != RemixMode.COMPRESS && vm.audioChoice == AUDIO_PHONE) {
            vm.extraAudioUri?.let { AudioPreview(it) }
        }
        ExportSection(vm, onExport)
        OutlinedButton(onClick = { vm.screen = Screen.HOME }, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, null)
            Spacer(Modifier.size(8.dp))
            Text(stringResource(R.string.back))
        }
    }
}

/** تشغيل الصوت المختار من الهاتف أثناء المعاينة. */
@Composable
private fun AudioPreview(uri: Uri) {
    val context = LocalContext.current
    val player = remember(uri) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(uri))
            repeatMode = Player.REPEAT_MODE_ALL
            prepare()
            playWhenReady = true
        }
    }
    DisposableEffect(player) { onDispose { player.release() } }
}

@Composable
private fun VideoCell(uri: Uri, muted: Boolean, fit: Boolean, modifier: Modifier) {
    val context = LocalContext.current
    val player = remember(uri) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(uri))
            repeatMode = Player.REPEAT_MODE_ALL
            prepare()
            playWhenReady = true
        }
    }
    LaunchedEffect(muted, player) { player.volume = if (muted) 0f else 1f }
    DisposableEffect(player) { onDispose { player.release() } }
    val mode = if (fit) AspectRatioFrameLayout.RESIZE_MODE_FIT else AspectRatioFrameLayout.RESIZE_MODE_ZOOM
    AndroidView(
        modifier = modifier,
        factory = {
            PlayerView(it).apply {
                useController = false
                resizeMode = mode
                this.player = player
            }
        },
        update = {
            it.resizeMode = mode
            it.player = player
        },
    )
}

@Composable
private fun PrivacyDialog(context: Context, onDismiss: () -> Unit) {
    val activity = context.findActivity()
    val showAdOptions = ConsentManager.privacyOptionsRequired(context)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.privacy_title)) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text(stringResource(R.string.privacy_text), style = MaterialTheme.typography.bodySmall)
                if (showAdOptions && activity != null) {
                    TextButton(onClick = { ConsentManager.showPrivacyOptions(activity) }) {
                        Text(stringResource(R.string.ad_privacy_options))
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val intent = Intent(Intent.ACTION_SENDTO).apply {
                    data = Uri.parse("mailto:waleedmmh789@gmail.com")
                    putExtra(Intent.EXTRA_SUBJECT, "waleed remix")
                }
                try { context.startActivity(intent) } catch (_: Exception) {}
            }) { Text(stringResource(R.string.support)) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.close)) } },
    )
}

private fun formatDuration(ms: Long): String {
    val total = ms / 1000
    return "%d:%02d".format(total / 60, total % 60)
}

/** معاينة اللصق المتتالي: قائمة تشغيل واحدة تعرض العناصر بالترتيب. */
@Composable
private fun SequenceCell(entries: List<MediaEntry>, muted: Boolean, fit: Boolean, modifier: Modifier) {
    val context = LocalContext.current
    val key = entries.map { it.uri.toString() + it.isVideo }
    val player = remember(key) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItems(
                entries.map { e ->
                    if (e.isVideo) {
                        MediaItem.fromUri(e.uri)
                    } else {
                        MediaItem.Builder().setUri(e.uri).setImageDurationMs(15_000L).build()
                    }
                },
            )
            repeatMode = Player.REPEAT_MODE_ALL
            prepare()
            playWhenReady = true
        }
    }
    LaunchedEffect(muted, player) { player.volume = if (muted) 0f else 1f }
    DisposableEffect(player) { onDispose { player.release() } }
    val mode = if (fit) AspectRatioFrameLayout.RESIZE_MODE_FIT else AspectRatioFrameLayout.RESIZE_MODE_ZOOM
    AndroidView(
        modifier = modifier,
        factory = {
            PlayerView(it).apply {
                useController = false
                resizeMode = mode
                this.player = player
            }
        },
        update = {
            it.resizeMode = mode
            it.player = player
        },
    )
}


@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun CompressLevelChips(vm: RemixViewModel, enabled: Boolean) {
    Text(stringResource(R.string.compress_level_title), style = MaterialTheme.typography.titleSmall)
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        CompressLevel.values().forEach { lv ->
            FilterChip(
                selected = vm.compressLevel == lv,
                onClick = { vm.selectCompressLevel(lv) },
                enabled = enabled,
                label = { Text(stringResource(lv.labelRes)) },
            )
        }
    }
}

private fun formatSize(bytes: Long): String {
    val mb = bytes / (1024.0 * 1024.0)
    return if (mb >= 1.0) String.format(java.util.Locale.US, "%.1f MB", mb)
    else String.format(java.util.Locale.US, "%d KB", (bytes / 1024).coerceAtLeast(1))
}
