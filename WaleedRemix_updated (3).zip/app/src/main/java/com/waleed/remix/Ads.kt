package com.waleed.remix

import android.app.Activity
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.RequestConfiguration
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.google.android.ump.ConsentInformation
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform
import com.google.android.gms.ads.FullScreenContentCallback

private const val MAX_RETRIES = 4
private const val INTERSTITIAL_TTL_MS = 55 * 60 * 1000L // الإعلان البيني ينتهي بعد ساعة
private const val REWARDED_TTL_MS = 3 * 60 * 60 * 1000L // إعلان المكافأة ينتهي بعد 4 ساعات

/**
 * الإعلان البيني: يُحمَّل مسبقًا في الخلفية، ويُعرض مرة واحدة فقط في الجلسة
 * (عند أول عملية دمج)، ولا يُعاد تحميله بعد عرضه.
 */
class InterstitialManager(private val context: Context) {
    private var ad: InterstitialAd? = null
    private var loadedAt = 0L
    private var loading = false
    private var retries = 0
    private var shownThisSession = false
    private val handler = Handler(Looper.getMainLooper())

    fun load() {
        if (shownThisSession || loading) return
        if (ad != null && System.currentTimeMillis() - loadedAt < INTERSTITIAL_TTL_MS) return
        ad = null
        loading = true
        InterstitialAd.load(
            context,
            BuildConfig.INTERSTITIAL_ID,
            AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(loaded: InterstitialAd) {
                    ad = loaded
                    loadedAt = System.currentTimeMillis()
                    loading = false
                    retries = 0
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    ad = null
                    loading = false
                    if (retries < MAX_RETRIES) {
                        retries++
                        handler.postDelayed({ load() }, 15_000L * retries)
                    }
                }
            },
        )
    }

    /** يعرض الإعلان لو كان جاهزًا ولم يُعرض في هذه الجلسة. لا ينتظر ولا يعلّق الواجهة. */
    fun showOnce(activity: Activity) {
        if (shownThisSession) return
        val current = ad
        if (current == null || System.currentTimeMillis() - loadedAt >= INTERSTITIAL_TTL_MS) {
            load()
            return
        }
        shownThisSession = true
        ad = null
        current.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdFailedToShowFullScreenContent(error: com.google.android.gms.ads.AdError) {
                // فشل العرض: نسمح بمحاولة لاحقة
                shownThisSession = false
                load()
            }
        }
        current.show(activity)
    }
}

fun initAds(context: Context) {
    // إعلانات مناسبة للعائلة والأطفال: أعلى تصنيف مسموح G (للجميع)
    MobileAds.setRequestConfiguration(
        RequestConfiguration.Builder()
            .setMaxAdContentRating(RequestConfiguration.MAX_AD_CONTENT_RATING_G)
            .build(),
    )
    Thread { MobileAds.initialize(context) {} }.start()
}

@Composable
fun BannerAd(modifier: Modifier = Modifier, medium: Boolean = false) {
    AndroidView(
        modifier = modifier.fillMaxWidth(),
        factory = { ctx ->
            AdView(ctx).apply {
                setAdSize(if (medium) AdSize.MEDIUM_RECTANGLE else AdSize.BANNER)
                adUnitId = BuildConfig.BANNER_ID
                adListener = object : AdListener() {}
                loadAd(AdRequest.Builder().build())
            }
        },
        onRelease = { it.destroy() },
    )
}


/** هل يوجد اتصال بالإنترنت؟ (الدمج نفسه لا يحتاج إنترنت، الإعلانات فقط). */
fun isOnline(context: Context): Boolean {
    val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
    val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
    return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
}

/**
 * إعلان المكافأة: مشاهدته تفتح الحفظ بدون علامة مائية.
 * يُحمَّل مسبقًا ويُعاد تحميله تلقائيًا (مع إعادة المحاولة وانتظار الإنترنت)، وحالة [ready]
 * تتحدث الواجهة فور جاهزيته حتى يعمل الزر فورًا بدون تأخير.
 */
class RewardedManager(private val context: Context) {
    private var ad: RewardedAd? = null
    private var loadedAt = 0L
    private var loading = false
    private var retries = 0
    private val handler = Handler(Looper.getMainLooper())

    /** حالة قابلة للمراقبة من Compose. */
    var ready by mutableStateOf(false)
        private set

    private val retryRunnable = Runnable { load() }

    private fun scheduleRetry(delayMs: Long) {
        handler.removeCallbacks(retryRunnable)
        handler.postDelayed(retryRunnable, delayMs)
    }

    fun isReady(): Boolean = ready && System.currentTimeMillis() - loadedAt < REWARDED_TTL_MS

    fun load() {
        if (ad != null || loading) return
        if (!isOnline(context)) {
            // لا يوجد إنترنت الآن: نعيد المحاولة بعد قليل
            scheduleRetry(10_000L)
            return
        }
        loading = true
        RewardedAd.load(
            context,
            BuildConfig.REWARDED_ID,
            AdRequest.Builder().build(),
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(loaded: RewardedAd) {
                    ad = loaded
                    loadedAt = System.currentTimeMillis()
                    loading = false
                    retries = 0
                    ready = true
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    ad = null
                    ready = false
                    loading = false
                    if (retries < MAX_RETRIES + 2) {
                        retries++
                        scheduleRetry(10_000L * retries)
                    }
                }
            },
        )
    }

    /** يعرض الإعلان ويرجع النتيجة مرة واحدة: true لو شاهده حتى استحق المكافأة، وإلا false. */
    fun show(activity: Activity, onResult: (earned: Boolean) -> Unit) {
        val current = ad
        if (current == null || !isReady()) {
            ad = null
            ready = false
            load()
            onResult(false)
            return
        }
        // نستهلك الإعلان فورًا ونبدأ تحميل التالي في الخلفية
        ad = null
        ready = false
        var earned = false
        var finished = false
        fun finish(result: Boolean) {
            if (finished) return
            finished = true
            onResult(result)
        }
        current.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                load()
                finish(earned)
            }

            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                load()
                finish(false)
            }
        }
        current.show(activity) { earned = true }
    }
}

/** نافذة موافقة المستخدم (UMP) المطلوبة لإعلانات جوجل (أوروبا وغيرها). */
object ConsentManager {
    fun gather(activity: Activity, onReady: () -> Unit) {
        val info = UserMessagingPlatform.getConsentInformation(activity)
        val params = ConsentRequestParameters.Builder().build()
        info.requestConsentInfoUpdate(
            activity,
            params,
            {
                UserMessagingPlatform.loadAndShowConsentFormIfRequired(activity) { _ ->
                    if (info.canRequestAds()) onReady()
                }
            },
            { _ -> if (info.canRequestAds()) onReady() },
        )
        // لو الموافقة محفوظة من قبل نبدأ الإعلانات فورًا
        if (info.canRequestAds()) onReady()
    }

    fun privacyOptionsRequired(context: Context): Boolean =
        UserMessagingPlatform.getConsentInformation(context).privacyOptionsRequirementStatus ==
            ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED

    fun showPrivacyOptions(activity: Activity) {
        UserMessagingPlatform.showPrivacyOptionsForm(activity) { _ -> }
    }
}
