package com.waleed.remix

import android.app.ActivityManager
import android.content.Context
import android.media.MediaCodecList

/** يحدد لو الهاتف ضعيف (رام قليلة أو عدد قليل من مفككات الفيديو) فيدعم فيديو مزدوج فقط. */
object DeviceCapability {
    fun isWeak(context: Context): Boolean {
        return try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            if (am.isLowRamDevice) return true
            val info = ActivityManager.MemoryInfo()
            am.getMemoryInfo(info)
            val totalGb = info.totalMem / (1024.0 * 1024.0 * 1024.0)
            if (totalGb < 3.0) return true
            hardwareAvcInstances() in 1..3
        } catch (_: Exception) {
            false
        }
    }

    private fun hardwareAvcInstances(): Int {
        var best = 0
        for (info in MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos) {
            if (info.isEncoder) continue
            if (info.supportedTypes.none { it.equals("video/avc", ignoreCase = true) }) continue
            val n = info.name.lowercase()
            if (n.startsWith("omx.google") || n.startsWith("c2.android")) continue // برمجي وليس عتاد
            val max = info.getCapabilitiesForType("video/avc").maxSupportedInstances
            if (max > best) best = max
        }
        return best
    }
}
