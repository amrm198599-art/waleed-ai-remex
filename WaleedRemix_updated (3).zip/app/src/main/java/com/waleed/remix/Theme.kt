package com.waleed.remix

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Colors = darkColorScheme(
    primary = Color(0xFFFF8A00),
    onPrimary = Color(0xFF1A1000),
    secondary = Color(0xFF7C3AED),
    background = Color(0xFF120D2E),
    surface = Color(0xFF1C1642),
    surfaceVariant = Color(0xFF2A2260),
    onBackground = Color.White,
    onSurface = Color.White,
)

@Composable
fun RemixTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Colors, content = content)
}
