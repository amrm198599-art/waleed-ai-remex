package com.waleed.remix

import android.net.Uri
import androidx.annotation.StringRes
import kotlin.math.roundToInt

/** عنصر مختار: كل الملفات محفوظة داخل مخزن التطبيق (480p للفيديو) لذلك لا تضيع. */
data class MediaEntry(
    val uri: Uri,
    val isVideo: Boolean,
    val durationMs: Long,
    val shortSide: Int = 0,
    /** الأبعاد المعروضة (بعد الدوران) قبل الضغط، لحساب مقاس 480. */
    val width: Int = 0,
    val height: Int = 0,
)

/** خلية داخل الشاشة النهائية، كنسب من 0 إلى 1 (من أعلى اليسار). */
data class Cell(val x: Float, val y: Float, val w: Float, val h: Float)

/** مكان الفيديو الصغير (صورة الوجه مثلًا) في وضع "شاشة كاملة + فيديو صغير". */
enum class PipCorner(@StringRes val labelRes: Int) {
    TOP_LEFT(R.string.corner_tl),
    TOP_RIGHT(R.string.corner_tr),
    BOTTOM_LEFT(R.string.corner_bl),
    BOTTOM_RIGHT(R.string.corner_br),
}

// كل الإخراج بدقة 480 فقط
private const val PW = 480 // عرض الشاشة الطولية
private const val PH = 854 // ارتفاعها

enum class RemixLayout(
    @StringRes val labelRes: Int,
    val canvasW: Int,
    val canvasH: Int,
    private val baseCells: List<Cell>,
    val isPip: Boolean = false,
    /** واحد وراه واحد (تتابع) بدل عرض الفيديوهات معًا. */
    val isSequential: Boolean = false,
) {
    SEQ_P(R.string.layout_seq_p, PW, PH, listOf(Cell(0f, 0f, 1f, 1f)), isSequential = true),
    SEQ_L(R.string.layout_seq_l, PH, PW, listOf(Cell(0f, 0f, 1f, 1f)), isSequential = true),
    V2(R.string.layout_v2, PW, PH, listOf(Cell(0f, 0f, 1f, .5f), Cell(0f, .5f, 1f, .5f))),
    H2(R.string.layout_h2, PH, PW, listOf(Cell(0f, 0f, .5f, 1f), Cell(.5f, 0f, .5f, 1f))),
    PIP_P(R.string.layout_pip_p, PW, PH, listOf(Cell(0f, 0f, 1f, 1f), Cell(0f, 0f, 0.3f, 0.3f)), isPip = true),
    PIP_L(R.string.layout_pip_l, PH, PW, listOf(Cell(0f, 0f, 1f, 1f), Cell(0f, 0f, 0.3f, 0.3f)), isPip = true),
    V3(
        R.string.layout_v3, PW, PH,
        listOf(Cell(0f, 0f, 1f, 1f / 3), Cell(0f, 1f / 3, 1f, 1f / 3), Cell(0f, 2f / 3, 1f, 1f / 3)),
    ),
    H3(
        R.string.layout_h3, PH, PW,
        listOf(Cell(0f, 0f, 1f / 3, 1f), Cell(1f / 3, 0f, 1f / 3, 1f), Cell(2f / 3, 0f, 1f / 3, 1f)),
    ),
    G4(
        R.string.layout_g4, PW, PH,
        listOf(Cell(0f, 0f, .5f, .5f), Cell(.5f, 0f, .5f, .5f), Cell(0f, .5f, .5f, .5f), Cell(.5f, .5f, .5f, .5f)),
    );

    val count: Int get() = baseCells.size

    /** خلايا الدمج؛ في وضع الفيديو الصغير يتحدد مكانه حسب [corner]. */
    fun cells(corner: PipCorner): List<Cell> {
        if (!isPip) return baseCells
        val sidePx = if (canvasW < canvasH) 0.32f * canvasW else 0.22f * canvasW
        val w = sidePx / canvasW
        val h = sidePx / canvasH
        val mx = 0.04f
        val myTop = 0.05f
        val myBottom = 0.11f // مساحة أكبر بالأسفل حتى لا يغطي العلامة المائية
        val x = if (corner == PipCorner.TOP_LEFT || corner == PipCorner.BOTTOM_LEFT) mx else 1f - mx - w
        val y = if (corner == PipCorner.TOP_LEFT || corner == PipCorner.TOP_RIGHT) myTop else 1f - myBottom - h
        return listOf(Cell(0f, 0f, 1f, 1f), Cell(x, y, w, h))
    }

    fun cellWidthPx(i: Int, corner: PipCorner): Int = even(cells(corner)[i].w * canvasW)
    fun cellHeightPx(i: Int, corner: PipCorner): Int = even(cells(corner)[i].h * canvasH)

    companion object {
        fun forCount(n: Int): List<RemixLayout> = when (n) {
            2 -> listOf(SEQ_P, SEQ_L, V2, H2, PIP_P, PIP_L)
            3 -> listOf(SEQ_P, SEQ_L, V3, H3)
            4 -> listOf(SEQ_P, SEQ_L, G4)
            else -> emptyList()
        }

        private fun even(v: Float): Int = (v.roundToInt() / 2) * 2
    }
}

sealed interface ExportState {
    data object Idle : ExportState
    data class Running(val progress: Float) : ExportState
    data class Done(val uri: Uri) : ExportState
    data class Error(val message: String) : ExportState
}
