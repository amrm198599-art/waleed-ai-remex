package com.waleed.remix

import android.app.Application
import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.text.Layout
import android.text.SpannableString
import android.text.Spanned
import android.text.style.AbsoluteSizeSpan
import android.text.style.AlignmentSpan
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.Size
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.OverlaySettings
import androidx.media3.effect.Presentation
import androidx.media3.effect.TextOverlay
import androidx.media3.effect.TextureOverlay
import androidx.media3.effect.VideoCompositorSettings
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import com.google.common.collect.ImmutableList
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.roundToInt
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

enum class Screen { HOME, PREVIEW }

/** أقصى مدة للفيديو الواحد: دقيقة. */
const val MAX_VIDEO_MS = 60_000L
private const val SHORT_SIDE = 480

/** قيمة audioChoice التي تعني: استخدم الصوت المختار من الهاتف. */
const val AUDIO_PHONE = -2


/** مدة الصورة: 15 ثانية. */
private const val IMAGE_MS = 15_000L
private const val IN_BITRATE = 1_200_000
private const val OUT_BITRATE = 1_500_000

class RemixViewModel(app: Application) : AndroidViewModel(app) {

    val items = mutableStateListOf<MediaEntry>()
    var layout by mutableStateOf<RemixLayout?>(null)
        private set

    /** فهرس العنصر الأساسي (الذي يختاره المستخدم) داخل [items]. */
    var primaryIndex by mutableStateOf(0)
        private set
    var pipCorner by mutableStateOf(PipCorner.BOTTOM_RIGHT)
        private set

    /** true = الفيديو كامل بدون قص (حواف سوداء)، false = ملء الإطار مع قص الأطراف. */
    var fitFull by mutableStateOf(true)
        private set

    /** فهرس العنصر الذي يُسمع صوته، أو -1 لبدون صوت. */
    var audioChoice by mutableStateOf(0)
        private set

    /** صوت اختاره المستخدم من الهاتف (اختيار الصوت = -2). */
    var extraAudioUri by mutableStateOf<Uri?>(null)
        private set
    var extraAudioName by mutableStateOf("")
        private set
    var screen by mutableStateOf(Screen.HOME)
    var exportState by mutableStateOf<ExportState>(ExportState.Idle)
        private set

    var compressing by mutableStateOf(false)
        private set
    var compressIndex by mutableStateOf(0)
        private set
    var compressTotal by mutableStateOf(0)
        private set
    var compressProgress by mutableStateOf(0f)
        private set
    var skippedLong by mutableStateOf(0)
        private set
    var skippedDevice by mutableStateOf(0)
        private set

    /** هاتف ضعيف: يدعم فيديو مزدوج فقط. */
    val weakDevice: Boolean = DeviceCapability.isWeak(app)
    val maxVideos: Int get() = if (weakDevice) 2 else 4

    /** يتحول true عندما يحاول المستخدم بدء دمج وفيه دمج شغال؛ الواجهة تعرض رسالة ثم تصفّره. */
    var busyNotice by mutableStateOf(false)
        private set

    private val appCtx: Application = app
    private val prefs = app.getSharedPreferences("remix_state", Context.MODE_PRIVATE)
    private val inputsDir = File(app.filesDir, "inputs").apply { mkdirs() }

    // نطاق مستقل عن الشاشة: العمل يكمل حتى لو الـ Activity اتقفلت
    private val workScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var transformer: Transformer? = null
    private var importJob: Job? = null
    private var exportJob: Job? = null
    private var lastPercent = -1

    init {
        restore()
    }

    val availableLayouts: List<RemixLayout> get() = RemixLayout.forCount(items.size)

    /**
     * ترتيب الدمج الفعلي (فهارس داخل [items]): العنصر الأساسي أولًا ثم باقي العناصر بترتيبها.
     * الأساسي يأخذ الخلية الأولى (فوق / يسار / الشاشة الكاملة في وضع الفيديو الصغير).
     */
    val mergeOrder: List<Int>
        get() {
            val p = primaryIndex.coerceIn(0, (items.size - 1).coerceAtLeast(0))
            return if (items.isEmpty()) emptyList() else listOf(p) + items.indices.filter { it != p }
        }

    fun isBusy(): Boolean = compressing || exportState is ExportState.Running || ExportService.busy

    fun consumeBusyNotice() {
        busyNotice = false
    }

    val audioIndex: Int
        get() {
            if (audioChoice == -1 || audioChoice == AUDIO_PHONE) return -1
            val c = items.getOrNull(audioChoice)
            if (c != null && c.isVideo) return audioChoice
            return items.indexOfFirst { it.isVideo }
        }

    // ───────────────────── حفظ واسترجاع الحالة ─────────────────────

    private fun persist() {
        val arr = JSONArray()
        items.forEach {
            arr.put(
                JSONObject()
                    .put("p", it.uri.path ?: "")
                    .put("v", it.isVideo)
                    .put("d", it.durationMs)
                    .put("s", it.shortSide),
            )
        }
        prefs.edit()
            .putString("items", arr.toString())
            .putInt("audio", audioChoice)
            .putInt("primary", primaryIndex)
            .putString("xaudio", extraAudioUri?.path)
            .putString("xname", extraAudioName)
            .putInt("corner", pipCorner.ordinal)
            .putBoolean("fit", fitFull)
            .putString("layout", layout?.name)
            .apply()
    }

    private fun restore() {
        try {
            val raw = prefs.getString("items", null)
            if (raw != null) {
                val arr = JSONArray(raw)
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val f = File(o.getString("p"))
                    if (f.exists()) {
                        items.add(MediaEntry(Uri.fromFile(f), o.getBoolean("v"), o.getLong("d"), o.optInt("s", 0)))
                    }
                }
            }
        } catch (_: Exception) {
            items.clear()
        }
        audioChoice = prefs.getInt("audio", 0)
        // قيمة قديمة (-3) كانت لوضع "واحد وراه واحد" المحذوف
        if (audioChoice < -2) audioChoice = 0
        primaryIndex = prefs.getInt("primary", 0).coerceIn(0, (items.size - 1).coerceAtLeast(0))
        prefs.getString("xaudio", null)?.let { p ->
            val f = File(p)
            if (f.exists()) {
                extraAudioUri = Uri.fromFile(f)
                extraAudioName = prefs.getString("xname", "") ?: ""
            }
        }
        if (audioChoice == AUDIO_PHONE && extraAudioUri == null) audioChoice = 0
        fitFull = prefs.getBoolean("fit", true)
        pipCorner = PipCorner.values().getOrElse(prefs.getInt("corner", PipCorner.BOTTOM_RIGHT.ordinal)) {
            PipCorner.BOTTOM_RIGHT
        }
        val saved = prefs.getString("layout", null)
        val options = RemixLayout.forCount(items.size)
        layout = options.firstOrNull { it.name == saved } ?: options.firstOrNull()
        // حذف أي ملفات غير مستخدمة
        val used = items.map { File(it.uri.path ?: "").name }.toSet() +
            listOfNotNull(extraAudioUri?.path?.let { File(it).name })
        inputsDir.listFiles()?.forEach { if (it.name !in used) it.delete() }
        // ملفات مؤقتة قديمة
        appCtx.cacheDir.listFiles()?.forEach { if (it.name.startsWith("remix_")) it.delete() }
    }

    private fun deleteFilesOf(list: List<MediaEntry>) {
        list.forEach { e ->
            val f = File(e.uri.path ?: return@forEach)
            if (f.parentFile == inputsDir) f.delete()
        }
    }

    // ───────────────────── استيراد وضغط 480 ─────────────────────

    fun addUris(uris: List<Uri>) = importUris(uris, replace = false)

    fun replaceUris(uris: List<Uri>) = importUris(uris, replace = true)

    private fun importUris(uris: List<Uri>, replace: Boolean) {
        if (isBusy()) {
            busyNotice = true
            return
        }
        ExportService.busy = true
        importJob = workScope.launch {
            val room = if (replace) 4 else 4 - items.size
            val picked = uris.take(room)
            if (picked.isEmpty()) {
                ExportService.busy = false
                return@launch
            }
            compressing = true
            compressTotal = picked.size
            compressIndex = 0
            compressProgress = 0f
            skippedLong = 0
            skippedDevice = 0
            ExportService.start(appCtx, appCtx.getString(R.string.notif_working))
            val result = mutableListOf<MediaEntry>()
            try {
                for (u in picked) {
                    compressIndex++
                    compressProgress = 0f
                    lastPercent = -1
                    val e = withContext(Dispatchers.IO) { readEntry(u) }
                    if (e.isVideo && e.durationMs > MAX_VIDEO_MS + 500) {
                        skippedLong++
                        continue
                    }
                    val videosSoFar = (if (replace) 0 else items.count { it.isVideo }) + result.count { it.isVideo }
                    if (e.isVideo && videosSoFar >= maxVideos) {
                        skippedDevice++
                        continue
                    }
                    result += if (e.isVideo) prepareVideo(e) else withContext(Dispatchers.IO) { copyImage(e) }
                }
            } catch (ex: CancellationException) {
                deleteFilesOf(result)
                throw ex
            } finally {
                compressing = false
                ExportService.busy = false
                ExportService.stop(appCtx)
            }
            if (replace) {
                deleteFilesOf(items.toList())
                items.clear()
                primaryIndex = 0
            }
            items.addAll(result)
            refreshLayout()
            persist()
        }
    }

    private fun readEntry(uri: Uri): MediaEntry {
        val type = appCtx.contentResolver.getType(uri) ?: ""
        val isVideo = type.startsWith("video")
        var duration = 0L
        var shortSide = 0
        var dispW = 0
        var dispH = 0
        if (isVideo) {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(appCtx, uri)
                duration = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
                val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
                val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
                if (w > 0 && h > 0) {
                    shortSide = minOf(w, h)
                    val swap = rot == 90 || rot == 270
                    dispW = if (swap) h else w
                    dispH = if (swap) w else h
                }
            } catch (_: Exception) {
            } finally {
                try { r.release() } catch (_: Exception) {}
            }
        }
        return MediaEntry(uri, isVideo, duration, shortSide, dispW, dispH)
    }

    private fun copyToInputs(src: Uri, name: String): File? {
        return try {
            val out = File(inputsDir, name)
            val input = appCtx.contentResolver.openInputStream(src) ?: return null
            input.use { i -> out.outputStream().use { o -> i.copyTo(o) } }
            out
        } catch (_: Exception) {
            null
        }
    }

    private fun copyImage(e: MediaEntry): MediaEntry {
        val type = appCtx.contentResolver.getType(e.uri) ?: ""
        val ext = when {
            type.contains("png") -> "png"
            type.contains("webp") -> "webp"
            type.contains("heic") -> "heic"
            else -> "jpg"
        }
        val f = copyToInputs(e.uri, "img_${System.nanoTime()}.$ext") ?: return e
        return e.copy(uri = Uri.fromFile(f))
    }

    /** يحفظ الفيديو داخل التطبيق بدقة 480 (ضغط خفيف، أو نسخ مباشر لو هو أصلًا 480 أو أقل). */
    private suspend fun prepareVideo(e: MediaEntry): MediaEntry {
        val out = File(inputsDir, "v_${System.nanoTime()}.mp4")
        val needsCompress = e.shortSide > SHORT_SIDE && e.width > 0 && e.height > 0
        if (needsCompress) {
            try {
                // تصغير بحيث الضلع الأقصر = 480 مع الحفاظ على النسبة
                val factor = SHORT_SIDE.toFloat() / minOf(e.width, e.height)
                val outW = evenSize(e.width * factor)
                val outH = evenSize(e.height * factor)
                val item = EditedMediaItem.Builder(MediaItem.fromUri(e.uri))
                    .setEffects(
                        Effects(
                            emptyList(),
                            listOf(Presentation.createForWidthAndHeight(outW, outH, Presentation.LAYOUT_SCALE_TO_FIT)),
                        ),
                    )
                    .build()
                awaitTransformer(
                    start = { it.start(item, out.absolutePath) },
                    onProgress = {
                        compressProgress = it
                        notifyProgress(R.string.notif_compressing, it)
                    },
                    bitrate = IN_BITRATE,
                )
                return e.copy(uri = Uri.fromFile(out), shortSide = SHORT_SIDE)
            } catch (ex: CancellationException) {
                out.delete()
                throw ex
            } catch (ex: Exception) {
                out.delete()
            }
        }
        // لا حاجة للضغط أو فشل الضغط: نسخة كما هي داخل التطبيق
        val copied = withContext(Dispatchers.IO) { copyToInputs(e.uri, out.name) }
        return if (copied != null) e.copy(uri = Uri.fromFile(copied)) else e
    }

    private fun evenSize(v: Float): Int = maxOf(2, (v.roundToInt() / 2) * 2)

    private fun notifyProgress(textRes: Int, fraction: Float) {
        val pct = (fraction * 100).toInt()
        if (pct == lastPercent) return
        lastPercent = pct
        ExportService.update(appCtx, appCtx.getString(textRes, pct), pct)
    }

    // ───────────────────── التحكم في القائمة والخيارات ─────────────────────

    fun removeAt(index: Int) {
        if (compressing || exportState is ExportState.Running) return
        if (index in items.indices) {
            val removed = items.removeAt(index)
            deleteFilesOf(listOf(removed))
            if (audioChoice == index) audioChoice = 0 else if (audioChoice > index) audioChoice--
            if (primaryIndex == index) primaryIndex = 0 else if (primaryIndex > index) primaryIndex--
        }
        refreshLayout()
        persist()
    }

    /** اختيار ملف صوت من الهاتف ليكون صوت الفيديو الناتج. */
    fun importAudio(uri: Uri) {
        if (exportState is ExportState.Running) return
        workScope.launch {
            val type = appCtx.contentResolver.getType(uri) ?: ""
            val ext = when {
                type.contains("mpeg") || type.contains("mp3") -> "mp3"
                type.contains("mp4") || type.contains("m4a") || type.contains("aac") -> "m4a"
                type.contains("wav") -> "wav"
                type.contains("ogg") -> "ogg"
                else -> "mp3"
            }
            val name = withContext(Dispatchers.IO) { displayName(uri) }
            val copied = withContext(Dispatchers.IO) { copyToInputs(uri, "aud_${System.nanoTime()}.$ext") }
            if (copied != null) {
                removeExtraAudioFile()
                extraAudioUri = Uri.fromFile(copied)
                extraAudioName = name
                audioChoice = AUDIO_PHONE
                persist()
            }
        }
    }

    fun removeExtraAudio() {
        if (exportState is ExportState.Running) return
        removeExtraAudioFile()
        if (audioChoice == AUDIO_PHONE) audioChoice = 0
        persist()
    }

    private fun removeExtraAudioFile() {
        extraAudioUri?.path?.let { File(it).delete() }
        extraAudioUri = null
        extraAudioName = ""
    }

    private fun displayName(uri: Uri): String = try {
        appCtx.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
            ?: "audio"
    } catch (_: Exception) {
        "audio"
    }

    fun clearAll() {
        if (compressing || exportState is ExportState.Running) return
        deleteFilesOf(items.toList())
        removeExtraAudioFile()
        if (audioChoice == AUDIO_PHONE) audioChoice = 0
        items.clear()
        primaryIndex = 0
        refreshLayout()
        persist()
    }

    fun reverse() {
        val reversed = items.reversed()
        items.clear()
        items.addAll(reversed)
        if (audioChoice >= 0) audioChoice = items.size - 1 - audioChoice
        primaryIndex = items.size - 1 - primaryIndex
        persist()
    }

    /** تحريك عنصر لأعلى/لأسفل لترتيب الفيديوهات واحد وراه واحد. */
    fun move(index: Int, delta: Int) {
        if (isBusy()) return
        val to = index + delta
        if (index !in items.indices || to !in items.indices) return
        val e = items.removeAt(index)
        items.add(to, e)
        if (audioChoice == index) audioChoice = to else if (audioChoice == to) audioChoice = index
        if (primaryIndex == index) primaryIndex = to else if (primaryIndex == to) primaryIndex = index
        persist()
    }

    /** يحدد العنصر الأساسي الذي سيُعتمد عليه في الدمج. */
    fun selectPrimary(index: Int) {
        if (isBusy()) return
        if (index !in items.indices) return
        primaryIndex = index
        exportState = ExportState.Idle
        persist()
    }

    fun selectLayout(l: RemixLayout) {
        layout = l
        persist()
    }

    fun selectPipCorner(c: PipCorner) {
        pipCorner = c
        persist()
    }

    fun selectFit(full: Boolean) {
        fitFull = full
        persist()
    }

    fun selectAudio(index: Int) {
        audioChoice = index
        persist()
    }

    fun resetExport() {
        exportState = ExportState.Idle
    }

    private fun refreshLayout() {
        val options = availableLayouts
        layout = if (options.isEmpty()) null else if (layout in options) layout else options.first()
        if (audioChoice >= items.size) audioChoice = 0
        if (audioChoice == AUDIO_PHONE && extraAudioUri == null) audioChoice = 0
        primaryIndex = primaryIndex.coerceIn(0, (items.size - 1).coerceAtLeast(0))
        exportState = ExportState.Idle
    }

    /** إلغاء الضغط أو الدمج الجاري. */
    fun cancel() {
        importJob?.cancel()
        exportJob?.cancel()
        transformer?.cancel()
        if (exportState is ExportState.Running) exportState = ExportState.Idle
    }

    // ───────────────────────── التصدير ─────────────────────────

    /** [pro] = شاهد إعلان المكافأة → بدون علامة مائية. الجودة 480 دائمًا. */
    fun export(pro: Boolean) {
        val l = layout ?: return
        if (items.size < 2) return
        if (items.size != l.count) return
        if (isBusy()) {
            busyNotice = true
            return
        }
        // الأساسي أولًا ثم الباقي: يتغير ترتيب الخلايا وفق اختيار المستخدم
        val order = mergeOrder
        val snapshot = order.map { items[it] }
        val audioIdx = order.indexOf(audioIndex)
        val phoneAudio = if (audioChoice == AUDIO_PHONE) extraAudioUri else null
        val keepOriginalAudio = audioChoice != -1 && audioChoice != AUDIO_PHONE
        val corner = pipCorner
        val fit = fitFull
        exportState = ExportState.Running(0f)
        lastPercent = -1
        ExportService.busy = true
        ExportService.start(appCtx, appCtx.getString(R.string.notif_working))
        exportJob = workScope.launch {
            val outFile = File(appCtx.cacheDir, "remix_${System.currentTimeMillis()}.mp4")
            try {
                val composition = buildComposition(snapshot, l, audioIdx, phoneAudio, keepOriginalAudio, corner, fit, watermark = !pro)
                awaitTransformer(
                    start = { it.start(composition, outFile.absolutePath) },
                    onProgress = {
                        exportState = ExportState.Running(it)
                        notifyProgress(R.string.notif_merging, it)
                    },
                    bitrate = OUT_BITRATE,
                )
                val uri = withContext(Dispatchers.IO) { saveToGallery(outFile) }
                exportState = ExportState.Done(uri)
                ExportService.done(appCtx, appCtx.getString(R.string.notif_done))
            } catch (e: CancellationException) {
                exportState = ExportState.Idle
                throw e
            } catch (e: Exception) {
                exportState = ExportState.Error(e.message ?: e.javaClass.simpleName)
                ExportService.done(appCtx, appCtx.getString(R.string.notif_failed))
            } finally {
                outFile.delete()
                transformer = null
                ExportService.busy = false
                ExportService.stop(appCtx)
            }
        }
    }

    private fun buildComposition(
        entries: List<MediaEntry>,
        l: RemixLayout,
        audioIdx: Int,
        phoneAudio: Uri?,
        keepOriginalAudio: Boolean,
        corner: PipCorner,
        fit: Boolean,
        watermark: Boolean,
    ): Composition {
        // كامل بدون قص (حواف سوداء) أو ملء الإطار مع قص الأطراف
        val layoutMode = if (fit) Presentation.LAYOUT_SCALE_TO_FIT else Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP
        val sequences = mutableListOf<EditedMediaItemSequence>()
        var compositor: VideoCompositorSettings? = null

        run {
            val cells = l.cells(corner)
            val maxVideoMs = entries.filter { it.isVideo }.maxOfOrNull { it.durationMs }?.takeIf { it > 0 } ?: IMAGE_MS
            val totalUs = maxVideoMs * 1000
            entries.forEachIndexed { i, e ->
                val effects = Effects(
                    emptyList(),
                    listOf(
                        Presentation.createForWidthAndHeight(
                            l.cellWidthPx(i, corner),
                            l.cellHeightPx(i, corner),
                            layoutMode,
                        ),
                    ),
                )
                val item = EditedMediaItem.Builder(MediaItem.fromUri(e.uri)).setEffects(effects)
                if (e.isVideo) {
                    item.setRemoveAudio(i != audioIdx)
                } else {
                    item.setDurationUs(totalUs).setFrameRate(30)
                }
                val seq = EditedMediaItemSequence.Builder(item.build())
                if (e.isVideo && e.durationMs in 1 until (maxVideoMs - 50)) seq.setIsLooping(true)
                sequences.add(seq.build())
            }
            compositor = object : VideoCompositorSettings {
                override fun getOutputSize(inputSizes: List<Size>): Size = Size(l.canvasW, l.canvasH)

                override fun getOverlaySettings(inputId: Int, presentationTimeUs: Long): OverlaySettings {
                    val c = cells[inputId.coerceIn(0, cells.lastIndex)]
                    val ax = (c.x + c.w / 2f) * 2f - 1f
                    val ay = 1f - (c.y + c.h / 2f) * 2f
                    return OverlaySettings.Builder()
                        .setBackgroundFrameAnchor(ax, ay)
                        .setOverlayFrameAnchor(0f, 0f)
                        .build()
                }
            }
        }

        // صوت من الهاتف: مسار صوت مستقل يتكرر حتى ينتهي الفيديو (وأصوات الفيديوهات مكتومة)
        if (phoneAudio != null) {
            val audioItem = EditedMediaItem.Builder(MediaItem.fromUri(phoneAudio)).build()
            sequences.add(EditedMediaItemSequence.Builder(audioItem).setIsLooping(true).build())
        }

        val builder = Composition.Builder(sequences)
        compositor?.let { builder.setVideoCompositorSettings(it) }
        if (watermark) {
            builder.setEffects(Effects(emptyList(), listOf(watermarkEffect(l))))
        }
        return builder.build()
    }

    /** علامة مائية: أيقونة التطبيق شبه شفافة في منتصف الفيديو. */
    private fun watermarkEffect(l: RemixLayout): OverlayEffect {
        val src = BitmapFactory.decodeResource(appCtx.resources, R.drawable.watermark_logo)
        val targetW = (minOf(l.canvasW, l.canvasH) * 0.55f).toInt().coerceAtLeast(64)
        val targetH = (targetW * src.height.toFloat() / src.width).toInt().coerceAtLeast(1)
        val bmp = Bitmap.createScaledBitmap(src, targetW, targetH, true)
        val settings = OverlaySettings.Builder()
            .setBackgroundFrameAnchor(0f, 0f)
            .setOverlayFrameAnchor(0f, 0f)
            .setAlphaScale(0.4f)
            .build()
        val overlay = BitmapOverlay.createStaticBitmapOverlay(bmp, settings)
        return OverlayEffect(ImmutableList.of<TextureOverlay>(overlay))
    }

    /** يشغّل Transformer وينتظر انتهاءه، مع تحديث التقدّم على الخيط الرئيسي. */
    private suspend fun awaitTransformer(
        start: (Transformer) -> Unit,
        onProgress: (Float) -> Unit,
        bitrate: Int? = null,
    ) {
        val holder = ProgressHolder()
        coroutineScopeProgress { register ->
            suspendCancellableCoroutine<Unit> { cont ->
                val builder = Transformer.Builder(appCtx)
                    .setVideoMimeType(MimeTypes.VIDEO_H264)
                    .setAudioMimeType(MimeTypes.AUDIO_AAC)
                if (bitrate != null) {
                    builder.setEncoderFactory(
                        DefaultEncoderFactory.Builder(appCtx)
                            .setRequestedVideoEncoderSettings(
                                VideoEncoderSettings.Builder().setBitrate(bitrate).build(),
                            )
                            .build(),
                    )
                }
                val t = builder
                    .addListener(object : Transformer.Listener {
                        override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                            if (cont.isActive) cont.resume(Unit)
                        }

                        override fun onError(
                            composition: Composition,
                            exportResult: ExportResult,
                            exportException: ExportException,
                        ) {
                            if (cont.isActive) cont.resumeWithException(exportException)
                        }
                    })
                    .build()
                transformer = t
                start(t)
                register {
                    if (t.getProgress(holder) == Transformer.PROGRESS_STATE_AVAILABLE) {
                        onProgress(holder.progress / 100f)
                    }
                }
                cont.invokeOnCancellation { t.cancel() }
            }
        }
    }

    private suspend fun coroutineScopeProgress(
        block: suspend (registerPoll: (() -> Unit) -> Unit) -> Unit,
    ) {
        var poll: (() -> Unit)? = null
        val poller = workScope.launch {
            while (isActive) {
                delay(300)
                poll?.invoke()
            }
        }
        try {
            block { poll = it }
        } finally {
            poller.cancel()
        }
    }

    private fun saveToGallery(file: File): Uri {
        val name = "WaleedRemix_${System.currentTimeMillis()}.mp4"
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/WaleedRemix")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            } else {
                @Suppress("DEPRECATION")
                val dir = File(
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES),
                    "WaleedRemix",
                )
                dir.mkdirs()
                @Suppress("DEPRECATION")
                put(MediaStore.Video.Media.DATA, File(dir, name).absolutePath)
            }
        }
        val resolver = appCtx.contentResolver
        val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: error("Could not create gallery entry")
        resolver.openOutputStream(uri)!!.use { out -> file.inputStream().use { it.copyTo(out) } }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val done = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
            resolver.update(uri, done, null, null)
        }
        return uri
    }
}
