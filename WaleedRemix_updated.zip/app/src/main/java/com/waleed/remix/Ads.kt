package com.waleed.remix

import android.app.Activity
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.RequestConfiguration
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.google.android.ump.ConsentInformation
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform
import com.google.android.gms.ads.FullScreenContentCallback

/** إدارة الإعلان البيني (Interstitial). */
class InterstitialManager(private val context: Context) {
    private var ad: InterstitialAd? = null
    private var loading = false

    fun load() {
        if (ad != null || loading) return
        loading = true
        InterstitialAd.load(
            context,
            BuildConfig.INTERSTITIAL_ID,
            AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(loaded: InterstitialAd) {
                    ad = loaded
                    loading = false
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    ad = null
                    loading = false
                }
            },
        )
    }

    fun show(activity: Activity) {
        val current = ad
        if (current == null) {
            load()
            return
        }
        current.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                ad = null
                load()
            }

            override fun onAdFailedToShowFullScreenContent(error: com.google.android.gms.ads.AdError) {
                ad = null
                load()
            }
        }
        current.show(activity)
    }
}

fun initAds(context: Context) {
    // إعلانات مناسبة للعائلة والأطفال: أعلى تصنيف مسموح G (للجميع)
    MobileAds.setRequestConfiguration(
        RequestConfiguration.Builder()
            .setMaxAdContentRating(RequestConfiguration.MAX_AD_CONTENT_RATING_G)
            .build(),
    )
    Thread { MobileAds.initialize(context) {} }.start()
}

@Composable
fun BannerAd(modifier: Modifier = Modifier, medium: Boolean = false) {
    AndroidView(
        modifier = modifier.fillMaxWidth(),
        factory = { ctx ->
            AdView(ctx).apply {
                setAdSize(if (medium) AdSize.MEDIUM_RECTANGLE else AdSize.BANNER)
                adUnitId = BuildConfig.BANNER_ID
                adListener = object : AdListener() {}
                loadAd(AdRequest.Builder().build())
            }
        },
        onRelease = { it.destroy() },
    )
}


/** هل يوجد اتصال بالإنترنت؟ (الدمج نفسه لا يحتاج إنترنت، الإعلانات فقط). */
fun isOnline(context: Context): Boolean {
    val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
    val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
    return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
}

/** إعلان المكافأة: مشاهدته تفتح الحفظ بدون علامة مائية وبأعلى جودة. */
class RewardedManager(private val context: Context) {
    private var ad: RewardedAd? = null
    private var loading = false

    fun isReady(): Boolean = ad != null

    fun load() {
        if (ad != null || loading || !isOnline(context)) return
        loading = true
        RewardedAd.load(
            context,
            BuildConfig.REWARDED_ID,
            AdRequest.Builder().build(),
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(loaded: RewardedAd) {
                    ad = loaded
                    loading = false
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    ad = null
                    loading = false
                }
            },
        )
    }

    /** يعرض الإعلان ويرجع النتيجة مرة واحدة: true لو شاهده حتى استحق المكافأة، وإلا false. */
    fun show(activity: Activity, onResult: (earned: Boolean) -> Unit) {
        val current = ad
        if (current == null) {
            load()
            onResult(false)
            return
        }
        var earned = false
        var finished = false
        fun finish(result: Boolean) {
            if (finished) return
            finished = true
            onResult(result)
        }
        current.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                ad = null
                load()
                finish(earned)
            }

            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                ad = null
                load()
                finish(false)
            }
        }
        current.show(activity) { earned = true }
    }
}

/** نافذة موافقة المستخدم (UMP) المطلوبة لإعلانات جوجل (أوروبا وغيرها). */
object ConsentManager {
    fun gather(activity: Activity, onReady: () -> Unit) {
        val info = UserMessagingPlatform.getConsentInformation(activity)
        val params = ConsentRequestParameters.Builder().build()
        info.requestConsentInfoUpdate(
            activity,
            params,
            {
                UserMessagingPlatform.loadAndShowConsentFormIfRequired(activity) { _ ->
                    if (info.canRequestAds()) onReady()
                }
            },
            { _ -> if (info.canRequestAds()) onReady() },
        )
        // لو الموافقة محفوظة من قبل نبدأ الإعلانات فورًا
        if (info.canRequestAds()) onReady()
    }

    fun privacyOptionsRequired(context: Context): Boolean =
        UserMessagingPlatform.getConsentInformation(context).privacyOptionsRequirementStatus ==
            ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED

    fun showPrivacyOptions(activity: Activity) {
        UserMessagingPlatform.showPrivacyOptionsForm(activity) { _ -> }
    }
}
