#!/usr/bin/env node
/**
 * Prepares the Capacitor Android project for a signed release build.
 *  1. If the android/ folder is incomplete (no gradlew), regenerate it with `npx cap add android`.
 *  2. Append a signing block to android/app/build.gradle (idempotent).
 * No secrets are written anywhere: the block only READS environment variables at build time.
 */
import { execFileSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';

const ROOT = process.cwd();
const ANDROID = path.join(ROOT, 'android');
const GRADLE = path.join(ANDROID, 'app', 'build.gradle');
const START = '// >>> waleed-signing (managed by scripts/android-prepare.mjs) >>>';
const END = '// <<< waleed-signing <<<';

const BLOCK = `
${START}
// Signing: only active when KEYSTORE_PATH is set (CI sets it; local debug builds are unaffected).
def waleedStoreFile = System.getenv("KEYSTORE_PATH")
if (waleedStoreFile) {
    android {
        signingConfigs {
            release {
                storeFile file(waleedStoreFile)
                storePassword System.getenv("KEYSTORE_PASSWORD")
                keyAlias System.getenv("KEY_ALIAS") ?: "waleed"
                keyPassword System.getenv("KEY_PASSWORD")
            }
        }
        buildTypes {
            release {
                signingConfig signingConfigs.release
            }
        }
    }
}
// SDK levels: never below 36 (Google Play target requirement). minSdk is left at Capacitor's default.
android {
    compileSdk = Math.max(rootProject.ext.compileSdkVersion as int, 36)
    defaultConfig {
        targetSdkVersion Math.max(rootProject.ext.targetSdkVersion as int, 36)
    }
}
// Version: CI passes a growing number so every build can be uploaded as an update.
def waleedVersionCode = System.getenv("ANDROID_VERSION_CODE")
if (waleedVersionCode) {
    android {
        defaultConfig {
            versionCode waleedVersionCode.toInteger()
            versionName System.getenv("ANDROID_VERSION_NAME") ?: "1.0"
        }
    }
}
${END}
`;

export function patchGradle(text) {
  // If an older managed block exists, replace it so the file always has the current one.
  const s = text.indexOf(START), e = text.indexOf(END);
  if (s !== -1 && e !== -1) {
    const next = text.slice(0, s).replace(/\s*$/, '\n') + BLOCK.trimStart() + text.slice(e + END.length).replace(/^\n?/, '');
    return { text: next, changed: next !== text };
  }
  return { text: text.replace(/\s*$/, '\n') + BLOCK, changed: true };
}

function ensureAndroidProject() {
  const complete = fs.existsSync(path.join(ANDROID, 'gradlew')) && fs.existsSync(path.join(ANDROID, 'settings.gradle'));
  if (complete) return console.log('android/ project is complete.');
  console.log('android/ is missing or incomplete: regenerating with `npx cap add android` ...');
  // Never destroy anything before the new project exists: move the old folder aside first.
  const backup = path.join(ROOT, 'android.stale-backup');
  const hadOld = fs.existsSync(ANDROID);
  fs.rmSync(backup, { recursive: true, force: true });
  if (hadOld) fs.renameSync(ANDROID, backup);
  try {
    execFileSync('npx', ['cap', 'add', 'android'], { stdio: 'inherit', cwd: ROOT, shell: process.platform === 'win32' });
  } catch (err) {
    fs.rmSync(ANDROID, { recursive: true, force: true });
    if (hadOld) fs.renameSync(backup, ANDROID); // put the old folder back
    throw new Error('`npx cap add android` failed; your original android/ folder was restored. ' + err.message);
  }
  fs.rmSync(backup, { recursive: true, force: true });
}

// AdMob App ID (not an ad unit id): ca-app-pub-XXXXXXXXXXXXXXXX~YYYYYYYYYY. Defaults to the app's real AdMob App ID.
const ADMOB_APP_ID = process.env.ADMOB_APP_ID || 'ca-app-pub-9932315898148137~8767644167';

export function patchManifest(text, appId = ADMOB_APP_ID) {
  const tag = `<meta-data android:name="com.google.android.gms.ads.APPLICATION_ID" android:value="${appId}" />`;
  const re = /<meta-data android:name="com\.google\.android\.gms\.ads\.APPLICATION_ID"[^>]*\/>/;
  if (re.test(text)) return text.replace(re, tag);
  return text.replace('</application>', `    ${tag}\n    </application>`);
}

function patchAdMob() {
  const manifest = path.join(ANDROID, 'app', 'src', 'main', 'AndroidManifest.xml');
  if (!fs.existsSync(manifest)) throw new Error('AndroidManifest.xml not found');
  fs.writeFileSync(manifest, patchManifest(fs.readFileSync(manifest, 'utf8')));
  console.log('AdMob App ID set in AndroidManifest.xml');
}

function main() {
  ensureAndroidProject();
  patchAdMob();
  if (!fs.existsSync(GRADLE)) throw new Error(`${GRADLE} not found after preparing the project`);
  const { text, changed } = patchGradle(fs.readFileSync(GRADLE, 'utf8'));
  if (changed) fs.writeFileSync(GRADLE, text);
  console.log(changed ? 'Signing block added to android/app/build.gradle' : 'Signing block already present.');
}

if (import.meta.url === `file://${process.argv[1]}`) {
  try { main(); } catch (e) { console.error(e.message); process.exit(1); }
}
