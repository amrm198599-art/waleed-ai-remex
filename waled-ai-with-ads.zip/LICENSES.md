# Waled AI — Asset Licenses and Attribution

All character models, audio compositions, vector backgrounds, and props included in the initial Waled AI library are custom-engineered vector assets created for Waled AI or licensed under permissive open-source / public domain licenses (Creative Commons CC0 1.0 Universal).

## 1. Character Rigs & Vector Sprites

- **Bader the Rabbit (الأرنب بدر)**
  - Type: Vector Rig (SVG / Procedural 2D Skeletal Mesh)
  - Author: Waled AI Creative Studio
  - License: CC0 1.0 Universal (Public Domain Dedication)
  - Permitted Use: Free for personal and commercial video generation, modification, and distribution.

- **Faris the Bear (الدب فارس)**
  - Type: Vector Rig (SVG / Procedural 2D Skeletal Mesh)
  - Author: Waled AI Creative Studio
  - License: CC0 1.0 Universal (Public Domain Dedication)
  - Permitted Use: Free for personal and commercial video generation, modification, and distribution.

- **Maymoun the Monkey (القرد ميمون)**
  - Type: Vector Rig (SVG / Procedural 2D Skeletal Mesh)
  - Author: Waled AI Creative Studio
  - License: CC0 1.0 Universal (Public Domain Dedication)
  - Permitted Use: Free for personal and commercial video generation, modification, and distribution.

- **Salma the Explorer (سلمى المستكشفة)**
  - Type: Vector Rig (SVG / Procedural 2D Skeletal Mesh)
  - Author: Waled AI Creative Studio
  - License: CC0 1.0 Universal (Public Domain Dedication)
  - Permitted Use: Free for personal and commercial video generation, modification, and distribution.

- **Robo-Z (الروبوت زيرو)**
  - Type: Vector Rig (SVG / Procedural 2D Skeletal Mesh)
  - Author: Waled AI Creative Studio
  - License: CC0 1.0 Universal (Public Domain Dedication)
  - Permitted Use: Free for personal and commercial video generation, modification, and distribution.

## 2. Background Environments

- **Enchanted Forest (الغابة السحرية)**: Procedural Canvas/SVG Layers (Sunlight shafts, glowing flora, deep canopy). License: MIT / CC0.
- **Sunny Meadow (المرج المشمس)**: Multi-layer parallax landscape (Azure sky, fluffy clouds, rolling hills, daisies). License: MIT / CC0.
- **Cozy Treehouse (بيت الشجرة)**: Warm wooden interior with glowing lantern and storytelling window. License: MIT / CC0.
- **Cosmic Galaxy (الفضاء الخارجي)**: Dynamic starfield with gradient nebulae and planetary horizons. License: MIT / CC0.
- **City Park (حديقة المدينة)**: Modern metropolitan skyline with pedestrian path, trees, and street lamp. License: MIT / CC0.

## 3. Audio & Sound FX

- **Synthesized Voiceovers**: Generated via Web Audio Synthesizer or server-side Gemini 3.8 Flash Lite TTS (`gemini-3.8-flash-lite-tts`).
- **Sound Effects (SFX)**:
  - `pop`, `boing`, `whoosh`, `cheer`, `footsteps`, `laugh`: Synthesized dynamically with Web Audio API harmonic oscillators (Zero external binary dependencies, 100% royalty-free).
- **Background Music Tracks**:
  - `Playful Adventure` (مغامرة مرحة): Synthesized acoustic chord progression (C Major, 110 BPM).
  - `Whimsical Story` (حكاية خيالية): Ambient marimba & bell arpeggios (G Major, 96 BPM).
  - `Upbeat Groove` (إيقاع حيوي): Energetic electro-pop beat (A Minor, 120 BPM).

## 4. Software Dependencies

- **FFmpeg**: GNU Lesser General Public License (LGPL) version 2.1+.
- **Express**: MIT License.
- **React & Vite**: MIT License.
- **Tailwind CSS**: MIT License.
- **Lucide Icons**: ISC License.
- **Motion**: MIT License.
