import { runFfmpeg, probeDuration } from './ffmpeg';

export type AudioMode = 'both' | 'top' | 'bottom' | 'none';
export type DurationMode = 'shortest' | 'longest';

/** True if the file has at least one audio stream. */
export async function hasAudio(file: string): Promise<boolean> {
  try {
    await runFfmpeg(['-i', file], 20_000);
  } catch (e: any) {
    return /Stream #\d+:\d+.*Audio:/.test(String(e.message));
  }
  return false;
}

export interface RemixOptions {
  top: string;
  bottom: string;
  out: string;
  audio?: AudioMode;
  duration?: DurationMode;
  width?: number;  // output is width x (2 * halfHeight)
  halfHeight?: number;
  maxSeconds?: number;
}

/**
 * Split-screen remix: `top` video above `bottom` video, both cropped to fill their half.
 * Output: vertical H.264/AAC mp4, the format phone galleries accept.
 */
export async function remixSplitScreen(o: RemixOptions) {
  const W = o.width ?? 720;
  const HH = o.halfHeight ?? 640;
  const audioMode = o.audio ?? 'both';
  const maxSeconds = o.maxSeconds ?? 120;

  const [dTop, dBottom, aTop, aBottom] = await Promise.all([
    probeDuration(o.top), probeDuration(o.bottom), hasAudio(o.top), hasAudio(o.bottom),
  ]);
  if (dTop <= 0 || dBottom <= 0) throw new Error('One of the videos could not be read');

  const longest = (o.duration ?? 'shortest') === 'longest';
  const total = Math.min(longest ? Math.max(dTop, dBottom) : Math.min(dTop, dBottom), maxSeconds);
  // In "longest" mode the shorter clip loops; in "shortest" mode nothing needs to loop.
  const loop = (d: number) => (longest && d < total - 0.05 ? ['-stream_loop', '-1'] : []);

  const half = (i: number, label: string) =>
    `[${i}:v]scale=${W}:${HH}:force_original_aspect_ratio=increase,crop=${W}:${HH},setsar=1,fps=30,format=yuv420p[${label}]`;

  const useTop = (audioMode === 'both' || audioMode === 'top') && aTop;
  const useBottom = (audioMode === 'both' || audioMode === 'bottom') && aBottom;
  const norm = (i: number, label: string, vol: number) =>
    `[${i}:a]aresample=44100,aformat=channel_layouts=stereo,volume=${vol}[${label}]`;

  const parts = [half(0, 't'), half(1, 'b'), '[t][b]vstack=inputs=2[v]'];
  if (useTop && useBottom) {
    parts.push(norm(0, 'a0', 0.8), norm(1, 'a1', 0.8), '[a0][a1]amix=inputs=2:duration=longest:normalize=0[a]');
  } else if (useTop) {
    parts.push(norm(0, 'a', 1));
  } else if (useBottom) {
    parts.push(norm(1, 'a', 1));
  } else {
    parts.push('anullsrc=r=44100:cl=stereo[a]');
  }

  await runFfmpeg([
    ...loop(dTop), '-i', o.top,
    ...loop(dBottom), '-i', o.bottom,
    '-filter_complex', parts.join(';'),
    '-map', '[v]', '-map', '[a]',
    '-t', total.toFixed(3),
    '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '23', '-pix_fmt', 'yuv420p', '-r', '30',
    '-c:a', 'aac', '-b:a', '160k', '-ar', '44100', '-ac', '2',
    '-movflags', '+faststart', o.out,
  ], 10 * 60_000);
  return { seconds: total };
}
