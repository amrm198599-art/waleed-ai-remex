import { Router } from 'express';
import { db } from '../db';
import { providerAvailability } from './config';
import { getAiJob, spendToday, startAiVideoJob, type VisualStyle } from './orchestrator';
import type { AiVideoProviderId } from './types';

export const aiVideoRouter = Router();

// Which providers can be used right now (and why not), plus today's paid-spend meter.
aiVideoRouter.get('/providers', (_req, res) => {
  res.json({ providers: providerAvailability(), spend: spendToday() });
});

aiVideoRouter.post('/create', (req, res) => {
  const profile = db.getProfile();
  const { projectId, provider = 'slideshow', style = 'cartoon' } = req.body || {};

  if (typeof projectId !== 'string') return res.status(400).json({ error: 'projectId is required' });
  if (!['slideshow', 'fal'].includes(provider)) return res.status(400).json({ error: 'Invalid provider' });
  if (!['cartoon', 'realistic', 'cinematic'].includes(style)) return res.status(400).json({ error: 'Invalid style' });

  const project = db.getProject(projectId, profile.id);
  if (!project) return res.status(404).json({ error: 'Project not found' });

  const result = startAiVideoJob(project, provider as AiVideoProviderId, style as VisualStyle);
  if (!result.job) return res.status(result.status || 500).json({ error: result.error });
  res.status(202).json({ job: result.job });
});

aiVideoRouter.get('/jobs/:id', (req, res) => {
  const job = getAiJob(req.params.id);
  if (!job) return res.status(404).json({ error: 'Job not found' });
  res.json(job);
});
