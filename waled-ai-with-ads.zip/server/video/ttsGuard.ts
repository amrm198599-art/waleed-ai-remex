import crypto from 'crypto';
import fs from 'fs';
import path from 'path';

const CACHE_DIR = path.resolve(process.cwd(), '.data', 'tts-cache');

/** Same text + voice + model always gives the same file, so repeated stories cost no API calls. */
export function cacheKey(text: string, voice: string, model: string) {
  return crypto.createHash('sha1').update(`${model}|${voice}|${text.trim()}`).digest('hex');
}
export function cacheGet(key: string): string | null {
  const f = path.join(CACHE_DIR, `${key}.wav`);
  return fs.existsSync(f) ? f : null;
}
export async function cachePut(key: string, wavFile: string) {
  await fs.promises.mkdir(CACHE_DIR, { recursive: true });
  await fs.promises.copyFile(wavFile, path.join(CACHE_DIR, `${key}.wav`));
}

/** Serialises calls and keeps a minimum gap between them (the free tier allows only a few requests/minute). */
export class RateGate {
  private last = 0;
  private chain: Promise<unknown> = Promise.resolve();
  private minIntervalMs: number;
  private now: () => number;
  private sleep: (ms: number) => Promise<void>;
  constructor(
    minIntervalMs: number,
    now: () => number = Date.now,
    sleep: (ms: number) => Promise<void> = (ms) => new Promise((r) => setTimeout(r, ms))
  ) {
    this.minIntervalMs = minIntervalMs;
    this.now = now;
    this.sleep = sleep;
  }
  run<T>(fn: () => Promise<T>): Promise<T> {
    const task = this.chain.then(async () => {
      const wait = this.last + this.minIntervalMs - this.now();
      if (wait > 0) await this.sleep(wait);
      try { return await fn(); } finally { this.last = this.now(); }
    });
    this.chain = task.catch(() => {});
    return task;
  }
}

export function isRateLimitError(e: any): boolean {
  const m = String(e?.message || e);
  return e?.status === 429 || /429|RESOURCE_EXHAUSTED|quota/i.test(m);
}
/** True when the error says the DAILY quota is gone (retrying within the minute is pointless). */
export function isDailyQuotaError(e: any): boolean {
  return /PerDay|per day|daily/i.test(String(e?.message || e));
}
