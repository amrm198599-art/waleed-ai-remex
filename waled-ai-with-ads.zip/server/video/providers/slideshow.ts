import path from 'path';
import { ClipResult, ProviderContext, SceneInput, VideoProvider } from '../types';
import { generateNarration, generateSceneImage } from '../media';
import { probeDuration, stillToClip } from '../ffmpeg';

/**
 * Free provider: AI still image per scene + Ken Burns motion + optional narration.
 * Costs nothing, and every scene is an independent image so there is no character drift.
 */
export const slideshowProvider: VideoProvider = {
  id: 'slideshow',

  estimateCostUsd() {
    return 0;
  },

  async generateClip(scene: SceneInput, ctx: ProviderContext): Promise<ClipResult> {
    const n = scene.index + 1;
    const imagePath = path.join(ctx.workDir, `scene_${n}.png`);
    const audioPath = path.join(ctx.workDir, `scene_${n}`);
    const out = path.join(ctx.workDir, `clip_${n}.mp4`);

    const image = await generateSceneImage(scene.visualPrompt, imagePath, ctx.width, ctx.height, ctx.seed + scene.index);
    if (!image.real) ctx.report(-1, `Scene ${n}: image service unavailable, using a gradient (${image.error})`);

    const narr = await generateNarration(scene.narration, audioPath, ctx.language);
    const audio = narr ? narr.file : null;
    let duration = scene.duration;
    if (audio) duration = Math.max(duration, (await probeDuration(audio)) + 0.4);
    duration = Math.min(Math.max(duration, 2), 20);

    await stillToClip({
      image: imagePath,
      audio,
      duration,
      width: ctx.width,
      height: ctx.height,
      seed: ctx.seed + scene.index,
      out,
    });
    return { file: out, hasNarration: !!audio, narrationEngine: narr?.engine };
  },
};
