import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { Project, Scene, GenerationJob, QuotaStatus, UserProfile } from '../src/types';

interface QuotaReservation {
  id: string;
  userId: string;
  jobId: string;
  reservedAt: string;
  status: 'active' | 'consumed' | 'released';
  releasedAt?: string;
  releaseReason?: string;
}

interface DatabaseSchema {
  profiles: Record<string, UserProfile>;
  projects: Record<string, Project>;
  jobs: Record<string, GenerationJob>;
  quotaReservations: QuotaReservation[];
}

const DATA_DIR = path.resolve(process.cwd(), '.data');
const DB_FILE = path.join(DATA_DIR, 'waled_ai.json');

// Default initial user for development/demo
const DEFAULT_USER_ID = 'user_waled_creator_01';
const DEFAULT_PROFILE: UserProfile = {
  id: DEFAULT_USER_ID,
  displayName: 'Waled Creator',
  email: 'creator@waled.ai',
  preferredLanguage: 'ar',
  preferredTheme: 'dark',
};

class LocalDatabase {
  private data: DatabaseSchema;
  private lock: boolean = false;

  constructor() {
    this.data = {
      profiles: {
        [DEFAULT_USER_ID]: DEFAULT_PROFILE,
      },
      projects: {},
      jobs: {},
      quotaReservations: [],
    };
    this.load();
    this.seedSampleProjectIfEmpty();
  }

  private load() {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
      if (fs.existsSync(DB_FILE)) {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        const parsed = JSON.parse(raw);
        this.data = {
          profiles: parsed.profiles || { [DEFAULT_USER_ID]: DEFAULT_PROFILE },
          projects: parsed.projects || {},
          jobs: parsed.jobs || {},
          quotaReservations: parsed.quotaReservations || [],
        };

        // Reconcile video file status on disk
        Object.values(this.data.projects).forEach((p) => {
          if (this.hasVideoFile(p.id)) {
            p.renderedVideoUrl = `/api/videos/${p.id}/view`;
            p.streamUrl = `/api/videos/${p.id}/view`;
            p.downloadUrl = `/api/videos/${p.id}/download`;
            p.status = 'completed';
          }
        });
      } else {
        this.save();
      }
    } catch (e) {
      console.error('[DB] Error loading database file:', e);
    }
  }

  private save() {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
      fs.writeFileSync(DB_FILE, JSON.stringify(this.data, null, 2), 'utf-8');
    } catch (e) {
      console.error('[DB] Error saving database file:', e);
    }
  }

  private seedSampleProjectIfEmpty() {
    if (Object.keys(this.data.projects).length === 0) {
      const sampleProjectId = 'proj_forest_adventure_01';
      const sampleProject: Project = {
        id: sampleProjectId,
        userId: DEFAULT_USER_ID,
        title: 'مغامرة الأرنب والدب في الغابة السحرية',
        description: 'قصة كرتونية مرحة عن الأرنب بدر والدب فارس واكتشاف موزة ذهبية في الغابة.',
        language: 'ar',
        aspectRatio: '16:9',
        videoStyle: 'cartoon',
        duration: 15,
        status: 'completed',
        renderedVideoUrl: `/api/videos/${sampleProjectId}/view`,
        streamUrl: `/api/videos/${sampleProjectId}/view`,
        downloadUrl: `/api/videos/${sampleProjectId}/download`,
        createdAt: new Date(Date.now() - 3600000 * 2).toISOString(),
        updatedAt: new Date(Date.now() - 1800000).toISOString(),
        scenes: [
          {
            id: 'scene_01',
            order: 0,
            duration: 5,
            narration: 'في يوم مشمس داخل الغابة السحرية، كان الأرنب بدر يتجول سعيداً.',
            dialogue: [
              {
                id: 'diag_01',
                characterId: 'bader_rabbit',
                speakerName: 'الأرنب بدر',
                text: 'ما أجمل هذا اليوم! انظروا ماذا وجدت هنا!',
                expression: 'happy',
              },
            ],
            characters: [
              {
                characterId: 'bader_rabbit',
                action: 'walk',
                x: 35,
                y: 82,
                scale: 1.1,
                flipX: false,
                zIndex: 1,
              },
            ],
            backgroundId: 'enchanted_forest',
            camera: 'pan_right',
            transition: 'fade',
            sfx: 'pop',
            musicTrack: 'playful_adventure',
            subtitlesEnabled: true,
          },
          {
            id: 'scene_02',
            order: 1,
            duration: 5,
            narration: 'فجأة، ظهر الدب فارس باحثاً عن وجبته الخفيفة المفضلة.',
            dialogue: [
              {
                id: 'diag_02',
                characterId: 'faris_bear',
                speakerName: 'الدب فارس',
                text: 'أهلاً يا صديقي بدر! هل هذه موزة لذيذة تشاركني إياها؟',
                expression: 'surprised',
              },
            ],
            characters: [
              {
                characterId: 'bader_rabbit',
                action: 'wave',
                x: 25,
                y: 82,
                scale: 1.0,
                flipX: false,
                zIndex: 1,
              },
              {
                characterId: 'faris_bear',
                action: 'talk',
                x: 75,
                y: 84,
                scale: 1.25,
                flipX: true,
                zIndex: 2,
              },
            ],
            backgroundId: 'enchanted_forest',
            camera: 'zoom_in',
            transition: 'cut',
            sfx: 'boing',
            musicTrack: 'playful_adventure',
            subtitlesEnabled: true,
          },
          {
            id: 'scene_03',
            order: 2,
            duration: 5,
            narration: 'ضحك الصديقان وقررا تقاسم الموزة معاً والاحتفال بالصداقة.',
            dialogue: [
              {
                id: 'diag_03',
                characterId: 'bader_rabbit',
                speakerName: 'الأرنب والدب',
                text: 'الصداقة والمشاركة تصنعان أجمل اللحظات دائماً!',
                expression: 'laughing',
              },
            ],
            characters: [
              {
                characterId: 'bader_rabbit',
                action: 'celebrate',
                x: 40,
                y: 82,
                scale: 1.05,
                flipX: false,
                zIndex: 1,
              },
              {
                characterId: 'faris_bear',
                action: 'celebrate',
                x: 65,
                y: 84,
                scale: 1.25,
                flipX: false,
                zIndex: 2,
              },
            ],
            backgroundId: 'sunny_meadow',
            camera: 'static',
            transition: 'fade',
            sfx: 'cheer',
            musicTrack: 'whimsical_story',
            subtitlesEnabled: true,
          },
        ],
      };
      this.data.projects[sampleProjectId] = sampleProject;
      this.save();
    }
  }

  // ---------------------------------------------------------------------------
  // PROFILE & AUTH
  // ---------------------------------------------------------------------------
  public getProfile(userId: string = DEFAULT_USER_ID): UserProfile {
    if (!this.data.profiles[userId]) {
      this.data.profiles[userId] = {
        ...DEFAULT_PROFILE,
        id: userId,
      };
      this.save();
    }
    return this.data.profiles[userId];
  }

  // ---------------------------------------------------------------------------
  // QUOTA & CONCURRENCY SYSTEM (Unlimited Daily Generations + Concurrency Guard)
  // Allows unlimited daily video generations, with max 2 concurrent in-flight jobs.
  // ---------------------------------------------------------------------------
  public getQuotaStatus(userId: string = DEFAULT_USER_ID): QuotaStatus {
    const maxConcurrentJobs = 2;
    const maxAllowed = Number(process.env.DAILY_FREE_QUOTA_LIMIT) > 0 ? Number(process.env.DAILY_FREE_QUOTA_LIMIT) : 30;

    // Count in-flight generation jobs for this user
    const inFlightJobs = Object.values(this.data.jobs).filter(
      (j) =>
        j.userId === userId &&
        (j.status === 'queued' ||
          j.status === 'validating_assets' ||
          j.status === 'synthesizing_audio' ||
          j.status === 'rendering_frames' ||
          j.status === 'assembling_stream')
    );

    const activeJobs = inFlightJobs.length;

    // Today UTC date string (YYYY-MM-DD)
    const todayUtcDate = new Date().toISOString().split('T')[0];

    // Count successful/completed jobs today UTC
    const usedToday = Object.values(this.data.jobs).filter(
      (j) =>
        j.userId === userId &&
        j.status === 'completed' &&
        (j.completedAt || j.createdAt || '').startsWith(todayUtcDate)
    ).length;

    const remaining = Math.max(0, maxAllowed - usedToday);
    const canGenerate = remaining > 0 && activeJobs < maxConcurrentJobs;

    const totalGenerated = Object.values(this.data.jobs).filter(
      (j) => j.userId === userId && j.status === 'completed'
    ).length;

    const now = new Date();
    const tomorrowUtc = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate() + 1, 0, 0, 0));
    const resetInSeconds = Math.floor((tomorrowUtc.getTime() - now.getTime()) / 1000);
    const nextResetIso = tomorrowUtc.toISOString();

    return {
      isUnlimited: false,
      activeJobs,
      maxConcurrentJobs,
      canGenerate,
      totalGenerated,
      planName: 'المجاني (30 فيديو يومياً)',
      usedToday,
      maxAllowed,
      remaining,
      resetInSeconds,
      nextResetIso,
    };
  }

  /**
   * Reserves a generation slot with 30 videos/day limit, concurrency protection, and idempotency checks.
   */
  public reserveQuota(
    userId: string,
    jobId: string,
    idempotencyKey?: string
  ): { success: boolean; reservationId?: string; quota: QuotaStatus; error?: string; existingJobId?: string } {
    // 1. Idempotency Check
    if (idempotencyKey) {
      const existingJob = Object.values(this.data.jobs).find(
        (j) => j.userId === userId && j.idempotencyKey === idempotencyKey
      );
      if (existingJob) {
        return {
          success: true,
          reservationId: `idem_${existingJob.id}`,
          existingJobId: existingJob.id,
          quota: this.getQuotaStatus(userId),
        };
      }
    }

    const status = this.getQuotaStatus(userId);

    // 2. Daily Quota Check (30 videos per day limit)
    if (status.usedToday >= status.maxAllowed || status.remaining <= 0) {
      return {
        success: false,
        quota: status,
        error: 'لقد استخدمت الحد اليومي البالغ 30 فيديو. يمكنك المحاولة بعد إعادة تعيين الحد اليومي.',
      };
    }

    // 3. Concurrency check (protect server from unbounded simultaneous renders)
    if (!status.canGenerate) {
      return {
        success: false,
        quota: status,
        error: 'Too many concurrent video renders in progress. Please wait for an active job to finish.',
      };
    }

    const reservation: QuotaReservation = {
      id: crypto.randomUUID(),
      userId,
      jobId,
      reservedAt: new Date().toISOString(),
      status: 'active',
    };

    this.data.quotaReservations.push(reservation);
    this.save();

    return {
      success: true,
      reservationId: reservation.id,
      quota: this.getQuotaStatus(userId),
    };
  }

  /**
   * Releases reserved slot upon an execution failure or completion.
   */
  public releaseQuota(userId: string, jobId: string, reason: string): boolean {
    const reservation = this.data.quotaReservations.find(
      (r) => r.userId === userId && r.jobId === jobId && r.status === 'active'
    );

    if (reservation) {
      reservation.status = 'released';
      reservation.releasedAt = new Date().toISOString();
      reservation.releaseReason = reason;
      this.save();
      return true;
    }
    return false;
  }

  // ---------------------------------------------------------------------------
  // VIDEO FILE PERSISTENT STORAGE
  // ---------------------------------------------------------------------------
  public getVideoDir(): string {
    const dir = path.join(DATA_DIR, 'videos');
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    return dir;
  }

  public getVideoFilePath(projectId: string): string {
    return path.join(this.getVideoDir(), `${projectId}.mp4`);
  }

  public hasVideoFile(projectId: string): boolean {
    return fs.existsSync(this.getVideoFilePath(projectId));
  }

  public async saveVideoFile(projectId: string, buffer: Buffer): Promise<string> {
    const filePath = this.getVideoFilePath(projectId);
    await fs.promises.writeFile(filePath, buffer);
    return filePath;
  }

  // ---------------------------------------------------------------------------
  // PROJECTS & SCENES
  // ---------------------------------------------------------------------------
  public getProjects(userId: string = DEFAULT_USER_ID): Project[] {
    return Object.values(this.data.projects)
      .filter((p) => p.userId === userId)
      .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
  }

  public getProject(id: string, userId: string = DEFAULT_USER_ID): Project | null {
    const project = this.data.projects[id];
    if (!project || project.userId !== userId) return null;
    return project;
  }

  public saveProject(project: Project): Project {
    project.updatedAt = new Date().toISOString();
    this.data.projects[project.id] = project;
    this.save();
    return project;
  }

  public deleteProject(id: string, userId: string = DEFAULT_USER_ID): boolean {
    const project = this.data.projects[id];
    if (!project || project.userId !== userId) return false;
    delete this.data.projects[id];
    this.save();
    return true;
  }

  // ---------------------------------------------------------------------------
  // GENERATION JOBS
  // ---------------------------------------------------------------------------
  public createJob(job: GenerationJob): GenerationJob {
    this.data.jobs[job.id] = job;
    this.save();
    return job;
  }

  public getJob(id: string): GenerationJob | null {
    return this.data.jobs[id] || null;
  }

  public updateJob(id: string, updates: Partial<GenerationJob>): GenerationJob | null {
    const job = this.data.jobs[id];
    if (!job) return null;
    Object.assign(job, updates);
    this.save();
    return job;
  }
}

export const db = new LocalDatabase();
