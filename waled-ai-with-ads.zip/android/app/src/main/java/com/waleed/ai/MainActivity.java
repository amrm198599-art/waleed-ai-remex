package com.waleed.ai;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
