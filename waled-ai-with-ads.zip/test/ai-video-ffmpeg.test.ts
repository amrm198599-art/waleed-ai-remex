// Run with: npx tsx test/ai-video-ffmpeg.test.ts   (needs ffmpeg on PATH or FFMPEG_PATH)
import os from 'os';
import path from 'path';
import fs from 'fs';
import { makeGradientImage, stillToClip, normalizeVideoClip, concatClips, probeDuration, runFfmpeg } from '../server/video/ffmpeg';

const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'waled_test_'));
const p = (n: string) => path.join(dir, n);
let failed = 0;
const check = (ok: boolean, name: string) => { console.log(`${ok ? '✅' : '❌'} ${name}`); if (!ok) failed++; };

await makeGradientImage(p('g.png'), 640, 360, 1);
await runFfmpeg(['-f', 'lavfi', '-i', 'sine=frequency=440:duration=2', p('n.mp3')], 30000);
await stillToClip({ image: p('g.png'), audio: p('n.mp3'), duration: 2.5, width: 640, height: 360, seed: 0, out: p('a.mp4') });
await stillToClip({ image: p('g.png'), audio: null, duration: 2, width: 640, height: 360, seed: 2, out: p('b.mp4') });
await runFfmpeg(['-f', 'lavfi', '-i', 'testsrc=size=320x180:rate=24:duration=1', '-pix_fmt', 'yuv420p', p('raw.mp4')], 30000);
await normalizeVideoClip({ video: p('raw.mp4'), audio: null, duration: 3, width: 640, height: 360, out: p('c.mp4') });
await concatClips([p('a.mp4'), p('b.mp4'), p('c.mp4')], p('list.txt'), p('final.mp4'));

const near = (a: number, b: number) => Math.abs(a - b) < 0.3;
check(near(await probeDuration(p('a.mp4')), 2.5), 'still clip has the requested duration');
check(near(await probeDuration(p('c.mp4')), 3), 'short generated clip is looped to scene length');
check(near(await probeDuration(p('final.mp4')), 7.5), 'concatenated video length is the sum of clips');
fs.rmSync(dir, { recursive: true, force: true });
if (failed) process.exit(1);
