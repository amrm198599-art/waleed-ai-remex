import { db } from '../server/db';
import { generateScriptWithAI, testGeminiConnection } from '../server/ai';
import { execFile } from 'child_process';

async function runTests() {
  console.log('\n========================================');
  console.log('WALED AI — AUTOMATED TEST SUITE');
  console.log('========================================\n');

  let passed = 0;
  let failed = 0;

  function assert(condition: boolean, testName: string, details?: string) {
    if (condition) {
      console.log(`✅ [PASS] ${testName}`);
      passed++;
    } else {
      console.error(`❌ [FAIL] ${testName}: ${details || 'Assertion failed'}`);
      failed++;
    }
  }

  // TEST 1: User Profile & Database Initialization
  try {
    const testUserId = `test_user_${Date.now()}`;
    const profile = db.getProfile(testUserId);
    assert(profile.id === testUserId, 'User Profile auto-provisioning');
  } catch (e: any) {
    assert(false, 'User Profile auto-provisioning', e.message);
  }

  // TEST 2: Quota Initial Allowance (30 per day)
  const testQuotaUser = `quota_user_${Date.now()}`;
  try {
    const initialQuota = db.getQuotaStatus(testQuotaUser);
    assert(
      initialQuota.maxAllowed === 30 && initialQuota.remaining === 30 && initialQuota.canGenerate === true,
      'Initial quota allows 30 video generations per day'
    );
  } catch (e: any) {
    assert(false, 'Initial quota allows 30 video generations', e.message);
  }

  // TEST 3: Simulating 30 successful generations & 31st rejection
  try {
    const today = new Date().toISOString().split('T')[0];
    for (let i = 1; i <= 30; i++) {
      db.createJob({
        id: `job_test_${i}`,
        userId: testQuotaUser,
        projectId: `proj_test_${i}`,
        status: 'completed',
        progress: 100,
        idempotencyKey: `idem_${i}`,
        logs: ['Completed'],
        createdAt: `${today}T10:00:00.000Z`,
        completedAt: `${today}T10:01:00.000Z`,
      });
    }

    const quotaAfter30 = db.getQuotaStatus(testQuotaUser);
    assert(
      quotaAfter30.usedToday === 30 && quotaAfter30.remaining === 0 && quotaAfter30.canGenerate === false,
      'Quota correctly reflects 30 used videos and 0 remaining'
    );

    const res31 = db.reserveQuota(testQuotaUser, 'job_test_31', 'idem_31');
    assert(
      res31.success === false && !!res31.error,
      '31st video generation request is strictly rejected when daily limit of 30 is reached'
    );
  } catch (e: any) {
    assert(false, '30 daily limit and 31st rejection test', e.message);
  }

  // TEST 4: Failed jobs do not count towards daily quota
  const testFailUser = `fail_user_${Date.now()}`;
  try {
    const today = new Date().toISOString().split('T')[0];
    for (let i = 1; i <= 5; i++) {
      db.createJob({
        id: `job_fail_${i}`,
        userId: testFailUser,
        projectId: `proj_fail_${i}`,
        status: 'failed',
        progress: 20,
        idempotencyKey: `idem_fail_${i}`,
        logs: ['Failed'],
        createdAt: `${today}T10:00:00.000Z`,
      });
    }

    const quotaFail = db.getQuotaStatus(testFailUser);
    assert(
      quotaFail.usedToday === 0 && quotaFail.remaining === 30,
      'Failed generations do not consume daily quota'
    );
  } catch (e: any) {
    assert(false, 'Failed jobs quota test', e.message);
  }

  // TEST 6: Project Persistence & Scene Updates
  try {
    const created = db.saveProject({
      id: `proj_test_${Date.now()}`,
      userId: testQuotaUser,
      title: 'Automated Test Cartoon Project',
      description: 'Testing project persistence',
      language: 'ar',
      aspectRatio: '16:9',
      videoStyle: 'cartoon',
      duration: 10,
      scenes: [],
      status: 'draft',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    });

    const retrieved = db.getProject(created.id, testQuotaUser);
    assert(retrieved !== null && retrieved.title === created.title, 'Project can be created and retrieved');

    // Update scenes
    retrieved!.scenes = [
      {
        id: 's_01',
        order: 0,
        duration: 5,
        narration: 'Test Narration',
        dialogue: [],
        characters: [],
        backgroundId: 'enchanted_forest',
        camera: 'static',
        transition: 'fade',
      },
    ];
    db.saveProject(retrieved!);

    const afterUpdate = db.getProject(created.id, testQuotaUser);
    assert(
      afterUpdate !== null && afterUpdate.scenes.length === 1,
      'Project scene changes persist accurately across reloads'
    );
  } catch (e: any) {
    assert(false, 'Project Persistence', e.message);
  }

  // TEST 7: AI Script Generation & Schema Conformity
  try {
    const script = await generateScriptWithAI({
      prompt: 'Cartoon rabbit jumping and finding a banana in the forest',
      language: 'ar',
      aspectRatio: '16:9',
      durationSeconds: 15,
    });

    assert(
      script.scenes.length >= 2 && !!script.title,
      'AI Script generator returns structured scenes with valid schema'
    );
    assert(
      script.scenes[0].characters.length > 0 && !!script.scenes[0].backgroundId,
      'Scene assigns valid characters and backgrounds'
    );
  } catch (e: any) {
    assert(false, 'AI Script Generation', e.message);
  }

  // TEST 8: FFmpeg Binary Availability
  try {
    await new Promise<void>((resolve, reject) => {
      execFile('/usr/bin/ffmpeg', ['-version'], (err, stdout) => {
        if (err) return reject(err);
        if (stdout.includes('ffmpeg version')) {
          assert(true, 'FFmpeg binary is operational for media transcoding');
          resolve();
        } else {
          reject(new Error('Unexpected output'));
        }
      });
    });
  } catch (e: any) {
    assert(false, 'FFmpeg binary verification', e.message);
  }

    // TEST 9: Gemini Connection Test Function
  try {
    const connResult = await testGeminiConnection();
    assert(typeof connResult.success === "boolean" && typeof connResult.message === "string", "Gemini connection test returns structured result without exposing key");
  } catch (e: any) {
    assert(false, "Gemini connection test", e.message);
  }

  console.log('\n========================================');
  console.log(`TOTAL: ${passed + failed} | PASSED: ${passed} | FAILED: ${failed}`);
  console.log('========================================\n');

  if (failed > 0) {
    process.exit(1);
  }
}

runTests().catch((err) => {
  console.error('Fatal test error:', err);
  process.exit(1);
});
