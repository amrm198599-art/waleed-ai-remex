

export async function testGeminiConnection(): Promise<{ success: boolean; model: string; message: string }> {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey.trim().length === 0 || apiKey === 'MY_GEMINI_API_KEY') {
    return {
      success: false,
      model: 'gemini-3.8-flash',
      message: 'GEMINI_API_KEY is not configured or is using a placeholder value on the server.',
    };
  }
  try {
    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: 'Ping test: respond with exactly OK',
    });
    const text = response.text?.trim() || '';
    return {
      success: true,
      model: 'gemini-3.8-flash',
      message: 'Gemini API connection test succeeded. Model responded successfully.',
    };
  } catch (err: any) {
    return {
      success: false,
      model: 'gemini-3.8-flash',
      message: `Gemini API connection failed: ${err.message || 'Unknown error'}. Please verify your API key privileges.`,
    };
  }
}
