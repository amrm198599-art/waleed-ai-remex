import type { CapacitorConfig } from '@capacitor/cli';

// The app's API (/api/...) lives on the Express server. A phone cannot reach "localhost" on your PC,
// so set CAP_SERVER_URL to your hosted HTTPS address and the APK will load the app from there.
// Without it the APK only contains the static UI and every feature that needs the server will fail.
const serverUrl = process.env.CAP_SERVER_URL;

const config: CapacitorConfig = {
  appId: 'com.waleed.ai',
  appName: 'Waleed AI',
  webDir: 'dist',
  ...(serverUrl
    ? { server: { url: serverUrl, cleartext: serverUrl.startsWith('http://'), androidScheme: 'https' } }
    : {}),
};

export default config;
