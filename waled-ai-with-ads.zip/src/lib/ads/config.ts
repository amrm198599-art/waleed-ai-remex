/**
 * AdMob configuration. Replace the TEST ids with your real ids before publishing.
 * (The AdMob *App ID* is NOT here: it goes in android/app/src/main/res/values/strings.xml,
 *  and is injected automatically by scripts/android-prepare.mjs from ADMOB_APP_ID.)
 */
export const ADS_CONFIG = {
  // Real AdMob ad unit ids. NEVER click your own ads (can get the account banned).
  // To test safely, set testMode to true below.
  bannerId: 'ca-app-pub-9932315898148137/9009372657',
  interstitialId: 'ca-app-pub-9932315898148137/8007282175',

  // false = real ads (release). true = Google test ads (safe for your own testing).
  testMode: false,

  // Interstitial frequency: never annoy the user.
  interstitialMinGapMs: 3 * 60 * 1000, // at least 3 minutes between two interstitials
  interstitialEveryNNavigations: 4,    // and only every 4th screen change
  waitingAdMinGapMs: 60 * 1000,        // ad shown while a remix renders: at most once a minute
};
