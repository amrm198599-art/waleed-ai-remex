import { Capacitor } from '@capacitor/core';
import {
  AdMob,
  AdmobConsentStatus,
  BannerAdPluginEvents,
  BannerAdPosition,
  BannerAdSize,
  InterstitialAdPluginEvents,
  MaxAdContentRating,
} from '@capacitor-community/admob';
import { ADS_CONFIG } from './config';

/** Ads only exist inside the Android app. In the browser everything here is a safe no-op. */
const enabled = () => Capacitor.isNativePlatform();

let initialized = false;
let interstitialReady = false;
let lastInterstitialAt = 0;
let navCount = 0;

export async function initAds(onBannerHeight: (px: number) => void): Promise<void> {
  if (!enabled() || initialized) return;
  try {
    await AdMob.initialize({
      initializeForTesting: ADS_CONFIG.testMode,
      // Strictest content rating = "G": filters out suggestive/mature ads.
      maxAdContentRating: MaxAdContentRating.General,
    });

    // Consent form (required by Google for users in the EEA/UK; harmless elsewhere).
    const consent = await AdMob.requestConsentInfo();
    if (consent.isConsentFormAvailable && consent.status === AdmobConsentStatus.REQUIRED) {
      await AdMob.showConsentForm();
    }
    initialized = true;

    AdMob.addListener(BannerAdPluginEvents.SizeChanged, (size) => onBannerHeight(size.height));
    AdMob.addListener(InterstitialAdPluginEvents.Dismissed, () => {
      interstitialReady = false;
      void preloadInterstitial();
    });

    await showBanner();
    await preloadInterstitial();
  } catch (e) {
    // Ads must never break the app.
    console.warn('[ads] init failed', e);
  }
}

async function showBanner() {
  try {
    await AdMob.showBanner({
      adId: ADS_CONFIG.bannerId,
      adSize: BannerAdSize.ADAPTIVE_BANNER,
      position: BannerAdPosition.BOTTOM_CENTER,
      margin: 0,
      isTesting: ADS_CONFIG.testMode,
    });
  } catch (e) {
    console.warn('[ads] banner failed', e);
  }
}

async function preloadInterstitial() {
  try {
    await AdMob.prepareInterstitial({ adId: ADS_CONFIG.interstitialId, isTesting: ADS_CONFIG.testMode });
    interstitialReady = true;
  } catch (e) {
    interstitialReady = false;
    console.warn('[ads] interstitial preload failed', e);
  }
}

async function tryShowInterstitial(skipGap = false): Promise<void> {
  if (!enabled() || !initialized || !interstitialReady) return;
  if (!skipGap && Date.now() - lastInterstitialAt < ADS_CONFIG.interstitialMinGapMs) return;
  try {
    lastInterstitialAt = Date.now();
    interstitialReady = false;
    await AdMob.showInterstitial();
  } catch (e) {
    console.warn('[ads] interstitial show failed', e);
    void preloadInterstitial();
  }
}

/** Call on every screen change: shows an interstitial only every Nth change (and respects the time gap). */
export function onScreenChange(): void {
  navCount += 1;
  if (navCount % ADS_CONFIG.interstitialEveryNNavigations === 0) void tryShowInterstitial();
}

/** Call when the user starts something that takes a while (e.g. a remix): shows an interstitial while they wait. */
export function showWaitingAd(): void {
  if (!enabled() || !initialized || !interstitialReady) return;
  // Shorter gap than normal screen-change ads, but still protects against back-to-back ads.
  if (Date.now() - lastInterstitialAt < ADS_CONFIG.waitingAdMinGapMs) return;
  void tryShowInterstitial(true);
}

/** Call at a natural pause (e.g. a video/project just finished). Still respects the time gap. */
export function onTaskCompleted(): void {
  void tryShowInterstitial();
}
