import { BackgroundId, CameraMovement } from '../../types';

export interface BackgroundDefinition {
  id: BackgroundId;
  nameEn: string;
  nameAr: string;
  descriptionEn: string;
  descriptionAr: string;
  themeColor: string;
}

export const BACKGROUND_CATALOG: BackgroundDefinition[] = [
  {
    id: 'enchanted_forest',
    nameEn: 'Enchanted Forest',
    nameAr: 'الغابة السحرية',
    descriptionEn: 'Vibrant green trees with magical glowing fireflies and sunbeams',
    descriptionAr: 'أشجار خضراء ساحرة مع يراعات مضيئة وأشعة شمس متسللة',
    themeColor: '#059669',
  },
  {
    id: 'sunny_meadow',
    nameEn: 'Sunny Meadow',
    nameAr: 'المرج المشمس',
    descriptionEn: 'Rolling verdant hills, azure sky, and gentle wildflower breezes',
    descriptionAr: 'تلال خضراء بديعة وسماء زرقاء صافية وزهور برية مبهجة',
    themeColor: '#10b981',
  },
  {
    id: 'treehouse_interior',
    nameEn: 'Cozy Treehouse',
    nameAr: 'بيت الشجرة الدافئ',
    descriptionEn: 'Rustic cedar walls, glowing lantern, and scenic nature window',
    descriptionAr: 'جدران خشبية دافئة مع فانوس مشع ونافذة تطل على الطبيعة',
    themeColor: '#d97706',
  },
  {
    id: 'cosmic_galaxy',
    nameEn: 'Cosmic Galaxy',
    nameAr: 'الفضاء الكوني',
    descriptionEn: 'Vibrant purple nebula with sparkling stars and a ringed planet',
    descriptionAr: 'سديم كوني بنفسجي مذهل مع نجوم متلألئة وكوكب ذو حلقات',
    themeColor: '#7c3aed',
  },
  {
    id: 'city_park',
    nameEn: 'City Park',
    nameAr: 'حديقة المدينة',
    descriptionEn: 'Park bench, lamppost, and towering modern skyline in sunset',
    descriptionAr: 'مقعد حديقة كلاسيكي وفانوس إنارة مع أفق ناطحات السحاب عند الغروب',
    themeColor: '#3b82f6',
  },
];

export function renderBackground(
  ctx: CanvasRenderingContext2D,
  backgroundId: BackgroundId,
  width: number,
  height: number,
  time: number,
  camera: CameraMovement = 'static'
) {
  ctx.save();

  // Apply Camera movement
  applyCamera(ctx, camera, width, height, time);

  switch (backgroundId) {
    case 'enchanted_forest':
      drawEnchantedForest(ctx, width, height, time);
      break;
    case 'sunny_meadow':
      drawSunnyMeadow(ctx, width, height, time);
      break;
    case 'treehouse_interior':
      drawTreehouseInterior(ctx, width, height, time);
      break;
    case 'cosmic_galaxy':
      drawCosmicGalaxy(ctx, width, height, time);
      break;
    case 'city_park':
      drawCityPark(ctx, width, height, time);
      break;
    default:
      drawSunnyMeadow(ctx, width, height, time);
  }

  ctx.restore();
}

function applyCamera(
  ctx: CanvasRenderingContext2D,
  camera: CameraMovement,
  width: number,
  height: number,
  time: number
) {
  const cx = width / 2;
  const cy = height / 2;

  switch (camera) {
    case 'pan_left': {
      const offset = (Math.sin(time * 0.5) * 0.05 + 0.05) * width;
      ctx.translate(-offset * 0.2, 0);
      break;
    }
    case 'pan_right': {
      const offset = (Math.sin(time * 0.5) * 0.05 + 0.05) * width;
      ctx.translate(offset * 0.2, 0);
      break;
    }
    case 'zoom_in': {
      const scale = 1 + (Math.sin(time * 0.4) * 0.03 + 0.03);
      ctx.translate(cx, cy);
      ctx.scale(scale, scale);
      ctx.translate(-cx, -cy);
      break;
    }
    case 'zoom_out': {
      const scale = 1.06 - (Math.sin(time * 0.4) * 0.03 + 0.03);
      ctx.translate(cx, cy);
      ctx.scale(scale, scale);
      ctx.translate(-cx, -cy);
      break;
    }
    case 'shake': {
      const shakeX = (Math.sin(time * 25) * 0.5 + Math.cos(time * 35) * 0.5) * 4;
      const shakeY = (Math.cos(time * 28) * 0.5 + Math.sin(time * 40) * 0.5) * 4;
      ctx.translate(shakeX, shakeY);
      break;
    }
    case 'static':
    default:
      break;
  }
}

// 1. Enchanted Forest
function drawEnchantedForest(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  time: number
) {
  // Sky gradient
  const skyGrad = ctx.createLinearGradient(0, 0, 0, height);
  skyGrad.addColorStop(0, '#064e3b');
  skyGrad.addColorStop(0.5, '#047857');
  skyGrad.addColorStop(1, '#065f46');
  ctx.fillStyle = skyGrad;
  ctx.fillRect(0, 0, width, height);

  // Sunlight beams (god rays)
  ctx.save();
  ctx.globalAlpha = 0.12 + Math.sin(time * 1.5) * 0.04;
  ctx.fillStyle = '#fef08a';
  for (let i = 0; i < 4; i++) {
    ctx.beginPath();
    const startX = width * 0.15 + i * (width * 0.22);
    ctx.moveTo(startX, 0);
    ctx.lineTo(startX + width * 0.25, height);
    ctx.lineTo(startX + width * 0.15, height);
    ctx.lineTo(startX - width * 0.05, 0);
    ctx.closePath();
    ctx.fill();
  }
  ctx.restore();

  // Distant trees
  ctx.fillStyle = '#064e3b';
  for (let i = -1; i < 9; i++) {
    const x = i * (width / 7);
    ctx.beginPath();
    ctx.arc(x, height * 0.65, width * 0.14, 0, Math.PI * 2);
    ctx.fill();
  }

  // Ground hill
  const groundGrad = ctx.createLinearGradient(0, height * 0.65, 0, height);
  groundGrad.addColorStop(0, '#047857');
  groundGrad.addColorStop(1, '#064e3b');
  ctx.fillStyle = groundGrad;
  ctx.beginPath();
  ctx.moveTo(0, height * 0.72);
  ctx.bezierCurveTo(width * 0.3, height * 0.66, width * 0.7, height * 0.76, width, height * 0.7);
  ctx.lineTo(width, height);
  ctx.lineTo(0, height);
  ctx.closePath();
  ctx.fill();

  // Tree trunks
  ctx.fillStyle = '#78350f';
  ctx.fillRect(width * 0.08, height * 0.35, width * 0.05, height * 0.45);
  ctx.fillRect(width * 0.82, height * 0.3, width * 0.06, height * 0.5);

  // Tree foliage (left)
  ctx.fillStyle = '#059669';
  ctx.beginPath();
  ctx.arc(width * 0.1, height * 0.3, width * 0.14, 0, Math.PI * 2);
  ctx.fill();

  // Tree foliage (right)
  ctx.fillStyle = '#10b981';
  ctx.beginPath();
  ctx.arc(width * 0.85, height * 0.25, width * 0.16, 0, Math.PI * 2);
  ctx.fill();

  // Magical floating fireflies
  ctx.save();
  for (let i = 0; i < 12; i++) {
    const fx = (Math.sin(time * 0.8 + i * 1.5) * 0.4 + 0.5) * width;
    const fy = height * 0.4 + (Math.cos(time * 1.2 + i * 2.1) * 0.2 + 0.2) * height;
    const pulse = Math.abs(Math.sin(time * 3 + i));
    ctx.fillStyle = `rgba(253, 224, 71, ${0.4 + pulse * 0.5})`;
    ctx.shadowColor = '#facc15';
    ctx.shadowBlur = 10;
    ctx.beginPath();
    ctx.arc(fx, fy, 3 + pulse * 2, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

// 2. Sunny Meadow
function drawSunnyMeadow(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  time: number
) {
  // Sky
  const skyGrad = ctx.createLinearGradient(0, 0, 0, height);
  skyGrad.addColorStop(0, '#38bdf8');
  skyGrad.addColorStop(0.65, '#bae6fd');
  skyGrad.addColorStop(1, '#e0f2fe');
  ctx.fillStyle = skyGrad;
  ctx.fillRect(0, 0, width, height);

  // Sun with soft glow
  ctx.save();
  ctx.fillStyle = 'rgba(253, 224, 71, 0.3)';
  ctx.beginPath();
  ctx.arc(width * 0.82, height * 0.2, width * 0.12, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#fde047';
  ctx.beginPath();
  ctx.arc(width * 0.82, height * 0.2, width * 0.06, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  // Animated clouds
  ctx.fillStyle = 'rgba(255, 255, 255, 0.85)';
  const cloud1X = ((time * 12) % (width + 200)) - 100;
  drawCloud(ctx, cloud1X, height * 0.18, width * 0.08);

  const cloud2X = (((time * 8) + width * 0.5) % (width + 200)) - 100;
  drawCloud(ctx, cloud2X, height * 0.28, width * 0.06);

  // Distant purple hills
  ctx.fillStyle = '#818cf8';
  ctx.beginPath();
  ctx.moveTo(0, height * 0.6);
  ctx.quadraticCurveTo(width * 0.4, height * 0.48, width * 0.8, height * 0.58);
  ctx.lineTo(width, height * 0.55);
  ctx.lineTo(width, height);
  ctx.lineTo(0, height);
  ctx.closePath();
  ctx.fill();

  // Mid-ground green hill
  ctx.fillStyle = '#34d399';
  ctx.beginPath();
  ctx.moveTo(0, height * 0.68);
  ctx.quadraticCurveTo(width * 0.6, height * 0.58, width, height * 0.65);
  ctx.lineTo(width, height);
  ctx.lineTo(0, height);
  ctx.closePath();
  ctx.fill();

  // Foreground rolling meadow
  const fgGrad = ctx.createLinearGradient(0, height * 0.7, 0, height);
  fgGrad.addColorStop(0, '#10b981');
  fgGrad.addColorStop(1, '#059669');
  ctx.fillStyle = fgGrad;
  ctx.beginPath();
  ctx.moveTo(0, height * 0.76);
  ctx.bezierCurveTo(width * 0.3, height * 0.7, width * 0.7, height * 0.8, width, height * 0.73);
  ctx.lineTo(width, height);
  ctx.lineTo(0, height);
  ctx.closePath();
  ctx.fill();

  // Wildflowers
  ctx.save();
  for (let i = 0; i < 20; i++) {
    const fx = (i * 0.05 + 0.02) * width;
    const fy = height * 0.78 + (Math.sin(i * 3.7) * 0.1 + 0.1) * height * 0.2;
    const sway = Math.sin(time * 3 + i) * 2;
    ctx.fillStyle = i % 3 === 0 ? '#f43f5e' : i % 3 === 1 ? '#f59e0b' : '#ffffff';
    ctx.beginPath();
    ctx.arc(fx + sway, fy, 4, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#fde047';
    ctx.beginPath();
    ctx.arc(fx + sway, fy, 1.8, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

function drawCloud(ctx: CanvasRenderingContext2D, x: number, y: number, r: number) {
  ctx.beginPath();
  ctx.arc(x, y, r, 0, Math.PI * 2);
  ctx.arc(x + r * 0.7, y - r * 0.3, r * 0.8, 0, Math.PI * 2);
  ctx.arc(x + r * 1.4, y, r * 0.7, 0, Math.PI * 2);
  ctx.fill();
}

// 3. Treehouse Interior
function drawTreehouseInterior(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  time: number
) {
  // Wood walls
  const wallGrad = ctx.createLinearGradient(0, 0, 0, height);
  wallGrad.addColorStop(0, '#78350f');
  wallGrad.addColorStop(1, '#451a03');
  ctx.fillStyle = wallGrad;
  ctx.fillRect(0, 0, width, height);

  // Planks lines
  ctx.strokeStyle = '#292524';
  ctx.lineWidth = 2;
  for (let y = 0; y < height; y += height * 0.09) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(width, y);
    ctx.stroke();
  }

  // Scenic window (center-left)
  const winW = width * 0.28;
  const winH = height * 0.38;
  const winX = width * 0.12;
  const winY = height * 0.18;

  // Window view (sky + leaves)
  ctx.save();
  ctx.beginPath();
  ctx.roundRect(winX, winY, winW, winH, 16);
  ctx.clip();
  ctx.fillStyle = '#38bdf8';
  ctx.fillRect(winX, winY, winW, winH);

  // Swaying leaves outside
  ctx.fillStyle = '#10b981';
  for (let i = 0; i < 5; i++) {
    const leafSway = Math.sin(time * 2 + i) * 8;
    ctx.beginPath();
    ctx.arc(winX + i * 20 + leafSway, winY + 20 + i * 15, 24, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();

  // Window frame
  ctx.strokeStyle = '#b45309';
  ctx.lineWidth = 8;
  ctx.strokeRect(winX, winY, winW, winH);
  ctx.beginPath();
  ctx.moveTo(winX + winW / 2, winY);
  ctx.lineTo(winX + winW / 2, winY + winH);
  ctx.moveTo(winX, winY + winH / 2);
  ctx.lineTo(winX + winW, winY + winH / 2);
  ctx.stroke();

  // Bookshelf on the right
  const shelfX = width * 0.68;
  const shelfY = height * 0.22;
  const shelfW = width * 0.24;
  const shelfH = height * 0.42;

  ctx.fillStyle = '#92400e';
  ctx.fillRect(shelfX, shelfY, shelfW, shelfH);

  // Colorful books
  const bookColors = ['#ef4444', '#3b82f6', '#10b981', '#f59e0b', '#8b5cf6'];
  for (let b = 0; b < 8; b++) {
    ctx.fillStyle = bookColors[b % bookColors.length];
    ctx.fillRect(shelfX + 8 + b * (shelfW / 9), shelfY + shelfH * 0.15, shelfW * 0.08, shelfH * 0.35);
  }

  // Hanging glowing lantern
  const lanternX = width * 0.5;
  const lanternY = height * 0.22;
  const lanternSwing = Math.sin(time * 1.5) * 4;

  ctx.strokeStyle = '#475569';
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(lanternX, 0);
  ctx.lineTo(lanternX + lanternSwing, lanternY);
  ctx.stroke();

  // Lantern glow
  const glow = ctx.createRadialGradient(
    lanternX + lanternSwing,
    lanternY + 20,
    5,
    lanternX + lanternSwing,
    lanternY + 20,
    90
  );
  glow.addColorStop(0, 'rgba(251, 191, 36, 0.4)');
  glow.addColorStop(1, 'rgba(251, 191, 36, 0)');
  ctx.fillStyle = glow;
  ctx.beginPath();
  ctx.arc(lanternX + lanternSwing, lanternY + 20, 90, 0, Math.PI * 2);
  ctx.fill();

  // Floor
  ctx.fillStyle = '#451a03';
  ctx.fillRect(0, height * 0.78, width, height * 0.22);
}

// 4. Cosmic Galaxy
function drawCosmicGalaxy(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  time: number
) {
  // Deep space gradient
  const spaceGrad = ctx.createLinearGradient(0, 0, width, height);
  spaceGrad.addColorStop(0, '#090a0f');
  spaceGrad.addColorStop(0.5, '#1e1b4b');
  spaceGrad.addColorStop(1, '#311042');
  ctx.fillStyle = spaceGrad;
  ctx.fillRect(0, 0, width, height);

  // Nebula clouds
  ctx.save();
  const nebGrad = ctx.createRadialGradient(
    width * 0.4,
    height * 0.45,
    20,
    width * 0.4,
    height * 0.45,
    width * 0.4
  );
  nebGrad.addColorStop(0, 'rgba(168, 85, 247, 0.3)');
  nebGrad.addColorStop(0.5, 'rgba(59, 130, 246, 0.2)');
  nebGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
  ctx.fillStyle = nebGrad;
  ctx.fillRect(0, 0, width, height);
  ctx.restore();

  // Twinkling stars
  ctx.save();
  for (let s = 0; s < 50; s++) {
    const sx = ((s * 137.5) % width);
    const sy = ((s * 93.3) % height);
    const twinkle = Math.abs(Math.sin(time * 2 + s));
    ctx.fillStyle = `rgba(255, 255, 255, ${0.3 + twinkle * 0.7})`;
    ctx.beginPath();
    ctx.arc(sx, sy, 1 + twinkle * 1.5, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();

  // Ringed planet (upper right)
  const planetX = width * 0.8;
  const planetY = height * 0.3;
  const planetR = width * 0.08;

  // Planet body
  const planetGrad = ctx.createRadialGradient(
    planetX - planetR * 0.3,
    planetY - planetR * 0.3,
    planetR * 0.1,
    planetX,
    planetY,
    planetR
  );
  planetGrad.addColorStop(0, '#ec4899');
  planetGrad.addColorStop(0.7, '#8b5cf6');
  planetGrad.addColorStop(1, '#3b0764');
  ctx.fillStyle = planetGrad;
  ctx.beginPath();
  ctx.arc(planetX, planetY, planetR, 0, Math.PI * 2);
  ctx.fill();

  // Planetary rings
  ctx.save();
  ctx.translate(planetX, planetY);
  ctx.rotate(-0.4);
  ctx.strokeStyle = 'rgba(216, 180, 254, 0.6)';
  ctx.lineWidth = 6;
  ctx.beginPath();
  ctx.ellipse(0, 0, planetR * 1.8, planetR * 0.4, 0, 0, Math.PI * 2);
  ctx.stroke();
  ctx.restore();

  // Lunar horizon floor
  const moonGrad = ctx.createLinearGradient(0, height * 0.75, 0, height);
  moonGrad.addColorStop(0, '#334155');
  moonGrad.addColorStop(1, '#0f172a');
  ctx.fillStyle = moonGrad;
  ctx.beginPath();
  ctx.moveTo(0, height * 0.8);
  ctx.quadraticCurveTo(width * 0.5, height * 0.72, width, height * 0.82);
  ctx.lineTo(width, height);
  ctx.lineTo(0, height);
  ctx.closePath();
  ctx.fill();
}

// 5. City Park
function drawCityPark(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  time: number
) {
  // Sunset sky
  const skyGrad = ctx.createLinearGradient(0, 0, 0, height);
  skyGrad.addColorStop(0, '#f97316');
  skyGrad.addColorStop(0.4, '#fb923c');
  skyGrad.addColorStop(0.7, '#fde047');
  skyGrad.addColorStop(1, '#e0f2fe');
  ctx.fillStyle = skyGrad;
  ctx.fillRect(0, 0, width, height);

  // Distant skyscrapers silhouette
  ctx.fillStyle = '#1e293b';
  const buildings = [
    { x: 0.05, w: 0.1, h: 0.4 },
    { x: 0.18, w: 0.08, h: 0.55 },
    { x: 0.28, w: 0.14, h: 0.45 },
    { x: 0.45, w: 0.09, h: 0.6 },
    { x: 0.58, w: 0.12, h: 0.38 },
    { x: 0.72, w: 0.1, h: 0.5 },
    { x: 0.85, w: 0.12, h: 0.42 },
  ];

  for (const b of buildings) {
    ctx.fillRect(width * b.x, height * (0.7 - b.h), width * b.w, height * b.h);
  }

  // Park lawn
  ctx.fillStyle = '#15803d';
  ctx.fillRect(0, height * 0.7, width, height * 0.3);

  // Stone path
  ctx.fillStyle = '#94a3b8';
  ctx.beginPath();
  ctx.moveTo(width * 0.35, height * 0.7);
  ctx.lineTo(width * 0.55, height * 0.7);
  ctx.lineTo(width * 0.75, height);
  ctx.lineTo(width * 0.15, height);
  ctx.closePath();
  ctx.fill();

  // Park Bench (left)
  const benchX = width * 0.18;
  const benchY = height * 0.76;
  ctx.fillStyle = '#78350f';
  ctx.fillRect(benchX, benchY, width * 0.14, height * 0.03);
  ctx.fillStyle = '#1e293b';
  ctx.fillRect(benchX + 5, benchY + height * 0.03, 4, height * 0.04);
  ctx.fillRect(benchX + width * 0.14 - 9, benchY + height * 0.03, 4, height * 0.04);

  // Street Lamppost (right) with warm light
  const lampX = width * 0.82;
  const lampY = height * 0.52;
  ctx.fillStyle = '#0f172a';
  ctx.fillRect(lampX - 3, lampY, 6, height * 0.28);
  ctx.fillRect(lampX - 12, lampY, 24, 6);

  // Lamp warm glow
  const lampGlow = ctx.createRadialGradient(lampX, lampY, 4, lampX, lampY, 60);
  lampGlow.addColorStop(0, 'rgba(254, 240, 138, 0.7)');
  lampGlow.addColorStop(1, 'rgba(254, 240, 138, 0)');
  ctx.fillStyle = lampGlow;
  ctx.beginPath();
  ctx.arc(lampX, lampY, 60, 0, Math.PI * 2);
  ctx.fill();
}
