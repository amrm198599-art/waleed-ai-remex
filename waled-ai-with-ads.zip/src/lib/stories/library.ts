import type { BackgroundId, CharacterId, Scene } from '../../types';

/** 50 ready-made Arabic stories = 5 characters x 5 places x 2 plots. Generated, so no copyright issues. */
export interface Story {
  id: string;
  title: string;
  scenes: Scene[];
}

const CHARACTERS: Array<{ id: CharacterId; name: string; female: boolean }> = [
  { id: 'bader_rabbit', name: 'الأرنب بدر', female: false },
  { id: 'faris_bear', name: 'الدب فارس', female: false },
  { id: 'maymoun_monkey', name: 'القرد ميمون', female: false },
  { id: 'salma_explorer', name: 'سلمى المستكشفة', female: true },
  { id: 'robo_z', name: 'الروبوت زيرو', female: false },
];

const PLACES: Array<{ id: BackgroundId; name: string }> = [
  { id: 'enchanted_forest', name: 'الغابة السحرية' },
  { id: 'sunny_meadow', name: 'المرج المشمس' },
  { id: 'treehouse_interior', name: 'بيت الشجرة' },
  { id: 'cosmic_galaxy', name: 'الفضاء الواسع' },
  { id: 'city_park', name: 'حديقة المدينة' },
];

type G = (m: string, f: string) => string;
const PLOTS: Array<{ title: string; lines: (n: string, p: string, g: G) => string[] }> = [
  {
    title: 'الصندوق اللامع',
    lines: (n, p, g) => [
      `في صباح جميل ${g('بدأ', 'بدأت')} ${n} مغامرة جديدة في ${p}.`,
      `${g('وجد', 'وجدت')} ${n} صندوقاً صغيراً يلمع تحت الضوء.`,
      `${g('فتحه', 'فتحته')} ${n} فإذا فيه هدية لكل الأصدقاء، ففرح الجميع.`,
    ],
  },
  {
    title: 'الصديق الجديد',
    lines: (n, p, g) => [
      `${g('كان', 'كانت')} ${n} ${g('وحيداً', 'وحيدة')} في ${p} ${g('ويتمنى', 'وتتمنى')} صديقاً.`,
      `${g('سمع', 'سمعت')} ${n} صوتاً لطيفاً يناديه من بعيد.`,
      `${g('تعرّف', 'تعرّفت')} ${n} على صديق جديد، ومن يومها صار المكان أجمل.`,
    ],
  },
];

export const STORIES: Story[] = (() => {
  const out: Story[] = [];
  for (const c of CHARACTERS) {
    const g: G = (m, f) => (c.female ? f : m);
    for (const place of PLACES) {
      for (const plot of PLOTS) {
        const id = `story_${out.length + 1}`;
        const texts = plot.lines(c.name, place.name, g);
        out.push({
          id,
          title: `${c.name} في ${place.name}: ${plot.title}`,
          scenes: texts.map((narration, i) => ({
            id: `${id}_scene_${i + 1}`,
            order: i,
            duration: 5,
            narration,
            dialogue: [],
            characters: [
              { characterId: c.id, action: i === 2 ? 'celebrate' : i === 1 ? 'walk' : 'idle', x: 50, y: 70, scale: 1, flipX: false, zIndex: 1 },
            ],
            backgroundId: place.id,
            camera: i === 1 ? 'pan_right' : 'zoom_in',
            transition: 'fade',
            sfx: 'none',
            musicTrack: 'whimsical_story',
            subtitlesEnabled: true,
          })),
        });
      }
    }
  }
  return out;
})();
