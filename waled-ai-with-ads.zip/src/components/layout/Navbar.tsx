import React from 'react';
import { useLocalization } from '../../lib/localization';
import { QuotaStatus } from '../../types';
import {
  Sparkles,
  Globe,
  Clock,
  Video,
  Menu,
  Moon,
  Sun,
  ShieldCheck,
} from 'lucide-react';

interface NavbarProps {
  quota: QuotaStatus | null;
  onOpenMobileMenu: () => void;
  onNavigate: (view: string) => void;
  activeView: string;
}

export const Navbar: React.FC<NavbarProps> = ({
  quota,
  onOpenMobileMenu,
  onNavigate,
  activeView,
}) => {
  const { language, setLanguage, isRTL, t } = useLocalization();

  const toggleLanguage = () => {
    setLanguage(language === 'ar' ? 'en' : 'ar');
  };

  const formatResetTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    if (hours > 0) return `${hours}h ${mins}m`;
    return `${mins}m`;
  };

  return (
    <header className="sticky top-0 z-40 w-full glass-panel border-b border-purple-500/20 bg-slate-950/80 backdrop-blur-md px-4 lg:px-8 py-3 transition-colors">
      <div className="flex items-center justify-between">
        {/* Left: Mobile Menu & Brand Logo */}
        <div className="flex items-center gap-3">
          <button
            onClick={onOpenMobileMenu}
            className="lg:hidden p-2 text-slate-300 hover:text-white rounded-lg hover:bg-slate-800 transition"
            aria-label="Toggle Navigation"
          >
            <Menu className="w-5 h-5" />
          </button>

          <button
            onClick={() => onNavigate('dashboard')}
            className="flex items-center gap-2.5 group text-left cursor-pointer"
          >
            <div className="w-9 h-9 rounded-xl bg-waled-gradient flex items-center justify-center shadow-lg shadow-purple-500/30 group-hover:scale-105 transition">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <div>
              <span className="text-xl font-extrabold tracking-tight text-white flex items-center gap-1.5">
                {language === 'ar' ? 'وليد' : 'Waled'}{' '}
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-cyan-400">
                  AI
                </span>
              </span>
              <span className="hidden sm:block text-[11px] font-medium text-purple-300/80 leading-none">
                {language === 'ar' ? 'منصة صناعة الفيديو الكرتوني' : 'Cartoon Video Studio'}
              </span>
            </div>
          </button>
        </div>

        {/* Center: Action Shortcut */}
        <div className="hidden md:flex items-center gap-2">
          <button
            onClick={() => onNavigate('create')}
            className={`px-4 py-2 rounded-xl text-sm font-semibold flex items-center gap-2 transition ${
              activeView === 'create'
                ? 'bg-purple-600 text-white shadow-lg shadow-purple-600/30'
                : 'text-slate-300 hover:text-white hover:bg-purple-950/40 border border-purple-500/20'
            }`}
          >
            <Video className="w-4 h-4 text-purple-400" />
            <span>{t('nav.create_video')}</span>
          </button>
          <button
            onClick={() => onNavigate('studio')}
            className={`px-4 py-2 rounded-xl text-sm font-semibold flex items-center gap-2 transition ${
              activeView === 'studio'
                ? 'bg-purple-600 text-white shadow-lg shadow-purple-600/30'
                : 'text-slate-300 hover:text-white hover:bg-purple-950/40 border border-purple-500/20'
            }`}
          >
            <Sparkles className="w-4 h-4 text-cyan-400" />
            <span>{t('nav.animation_studio')}</span>
          </button>
        </div>

        {/* Right: Quota Badge & Language Switcher */}
        <div className="flex items-center gap-3">
          {/* Quota Badge (30 videos per day) */}
          <div
            title={language === 'ar' ? `الفيديوهات المستخدمة اليوم: ${quota?.usedToday || 0} من 30` : `Videos Used Today: ${quota?.usedToday || 0} of 30`}
            className="px-3.5 py-1.5 rounded-full text-xs font-semibold flex items-center gap-2 border bg-purple-950/60 border-purple-500/40 text-purple-200 shadow-sm"
          >
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            <span className="font-bold text-white tracking-wide">
              {language === 'ar'
                ? `المستخدم: ${quota?.usedToday || 0}/30`
                : `Used: ${quota?.usedToday || 0}/30`}
            </span>
            {quota && quota.activeJobs > 0 && (
              <span className="inline-flex items-center gap-1 text-[10px] text-cyan-300 border-l border-purple-500/30 pl-1.5 animate-pulse">
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
                {quota.activeJobs} {language === 'ar' ? 'نشط' : 'active'}
              </span>
            )}
          </div>

          {/* Persistent Language Switcher */}
          <button
            onClick={toggleLanguage}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-700 bg-slate-900/80 hover:bg-slate-800 text-xs font-bold text-slate-200 transition cursor-pointer"
            aria-label="Switch Language"
          >
            <Globe className="w-3.5 h-3.5 text-cyan-400" />
            <span>{language === 'ar' ? 'English' : 'العربية'}</span>
          </button>

          {/* User Avatar */}
          <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-purple-600 to-indigo-600 flex items-center justify-center text-xs font-bold text-white border border-purple-400/40 shadow-sm">
            W
          </div>
        </div>
      </div>
    </header>
  );
};
