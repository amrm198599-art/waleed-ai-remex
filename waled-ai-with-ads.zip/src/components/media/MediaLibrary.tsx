import React, { useState } from 'react';
import { useLocalization } from '../../lib/localization';
import { CHARACTER_CATALOG } from '../../lib/animation/characters';
import { BACKGROUND_CATALOG } from '../../lib/animation/backgrounds';
import { CharacterCanvas } from '../studio/CharacterCanvas';
import { audioEngine } from '../../lib/audio/engine';
import {
  FolderOpen,
  Sparkles,
  Music,
  Volume2,
  ShieldCheck,
  Search,
  Layers,
  Check,
} from 'lucide-react';

export const MediaLibrary: React.FC = () => {
  const { language, t } = useLocalization();
  const [activeTab, setActiveTab] = useState<'characters' | 'backgrounds' | 'audio' | 'licenses'>('characters');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const musicTracks = [
    {
      id: 'playful_adventure',
      nameAr: 'مغامرة مرحة',
      nameEn: 'Playful Adventure',
      genre: 'Acoustic / Marimba',
      bpm: 110,
      license: 'CC0 1.0 Universal',
    },
    {
      id: 'whimsical_story',
      nameAr: 'حكاية خيالية',
      nameEn: 'Whimsical Story',
      genre: 'Ambient / Chimes',
      bpm: 96,
      license: 'CC0 1.0 Universal',
    },
    {
      id: 'upbeat_groove',
      nameAr: 'إيقاع حيوي',
      nameEn: 'Upbeat Groove',
      genre: 'Synth / Upbeat',
      bpm: 120,
      license: 'CC0 1.0 Universal',
    },
  ];

  const soundEffects = [
    { id: 'pop', nameAr: 'فرقعة كرتونية', nameEn: 'Pop Bubble', desc: 'Fast frequency pop drop' },
    { id: 'boing', nameAr: 'ارتداد رنان', nameEn: 'Boing Spring', desc: 'Bouncy spring oscillation' },
    { id: 'whoosh', nameAr: 'هبوب سريع', nameEn: 'Whoosh Sweep', desc: 'Dynamic filtered wind burst' },
    { id: 'cheer', nameAr: 'هتاف واحتفال', nameEn: 'Victory Cheer', desc: 'Harmonic chime flourish' },
    { id: 'laugh', nameAr: 'ضحكة مرحة', nameEn: 'Laugh Bursts', desc: 'Staccato playful chirp series' },
    { id: 'footsteps', nameAr: 'خطوات مشي', nameEn: 'Step Thumps', desc: 'Gentle low-frequency walking' },
    { id: 'bell', nameAr: 'جرس نقي', nameEn: 'Crystal Bell', desc: '880Hz resonant bell chime' },
  ];

  return (
    <div className="space-y-6 pb-16">
      {/* Header */}
      <div className="glass-panel rounded-3xl p-6 border border-purple-500/20">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-extrabold text-white flex items-center gap-2">
              <FolderOpen className="w-6 h-6 text-cyan-400" />
              <span>{t('nav.media_library')}</span>
            </h1>
            <p className="text-xs md:text-sm text-slate-400 mt-1">
              {language === 'ar'
                ? 'مكتبة الأصول المتجهة المرخصة والموسيقى التصويرية والمؤثرات الصوتية للاستخدام الحر والتجاري'
                : 'Curated vector assets, audio tracks, and sound effects with full open-source licensing metadata'}
            </p>
          </div>

          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-950/40 border border-emerald-500/30 text-emerald-300 text-xs font-bold">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>{language === 'ar' ? 'رخصة CC0 1.0 العامة' : 'CC0 1.0 Universal License'}</span>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex items-center gap-2 mt-6 overflow-x-auto pb-1 scrollbar-none">
          {[
            { id: 'characters', label: language === 'ar' ? 'الشخصيات الكرتونية' : 'Characters' },
            { id: 'backgrounds', label: language === 'ar' ? 'الخلفيات والبيئات' : 'Backgrounds' },
            { id: 'audio', label: language === 'ar' ? 'الموسيقى والمؤثرات' : 'Music & SFX' },
            { id: 'licenses', label: language === 'ar' ? 'بيانات التراخيص' : 'Licenses & Rights' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer border ${
                activeTab === tab.id
                  ? 'bg-waled-gradient text-white border-transparent shadow-md shadow-purple-600/30'
                  : 'bg-slate-900/60 text-slate-300 border-slate-800 hover:bg-slate-800'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Tab: Characters */}
      {activeTab === 'characters' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {CHARACTER_CATALOG.map((char) => (
            <div
              key={char.id}
              className="glass-panel rounded-2xl overflow-hidden border border-purple-500/20 p-4 space-y-4"
            >
              <div className="h-44 rounded-xl overflow-hidden bg-slate-900 flex items-center justify-center border border-purple-500/20">
                <CharacterCanvas
                  characterId={char.id}
                  action="idle"
                  expression="happy"
                  width={240}
                  height={176}
                  scale={0.95}
                />
              </div>

              <div>
                <div className="flex items-center justify-between">
                  <h3 className="text-base font-bold text-white">
                    {language === 'ar' ? char.nameAr : char.nameEn}
                  </h3>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-purple-950 text-purple-300 border border-purple-500/30">
                    {char.species}
                  </span>
                </div>
                <p className="text-xs text-slate-300 mt-1">
                  {language === 'ar' ? char.descriptionAr : char.descriptionEn}
                </p>
              </div>

              <div className="pt-2 border-t border-purple-500/10 flex items-center justify-between text-[11px] text-slate-400">
                <span>{char.supportedActions.length} {language === 'ar' ? 'حركات مدعومة' : 'actions'}</span>
                <span className="text-emerald-400 font-semibold">CC0 Public Domain</span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Tab: Backgrounds */}
      {activeTab === 'backgrounds' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {BACKGROUND_CATALOG.map((bg) => (
            <div
              key={bg.id}
              className="glass-panel rounded-2xl overflow-hidden border border-purple-500/20 p-4 space-y-4"
            >
              <div className="relative aspect-video rounded-xl overflow-hidden bg-slate-900 border border-purple-500/20 flex items-center justify-center">
                <CharacterCanvas
                  characterId="bader_rabbit"
                  action="idle"
                  backgroundId={bg.id}
                  width={400}
                  height={225}
                  scale={0.5}
                />
              </div>

              <div>
                <h3 className="text-base font-bold text-white">
                  {language === 'ar' ? bg.nameAr : bg.nameEn}
                </h3>
                <p className="text-xs text-slate-300 mt-1">
                  {language === 'ar' ? bg.descriptionAr : bg.descriptionEn}
                </p>
              </div>

              <div className="pt-2 border-t border-purple-500/10 flex items-center justify-between text-[11px] text-slate-400">
                <span className="font-mono text-purple-300">ID: {bg.id}</span>
                <span className="text-emerald-400 font-semibold">CC0 Public Domain</span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Tab: Audio (Music & SFX) */}
      {activeTab === 'audio' && (
        <div className="space-y-6">
          {/* Music Section */}
          <div className="glass-panel rounded-2xl p-6 border border-purple-500/20 space-y-4">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Music className="w-5 h-5 text-purple-400" />
              <span>{language === 'ar' ? 'المقطوعات الموسيقية التصويرية' : 'Background Orchestrations'}</span>
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {musicTracks.map((track) => (
                <div
                  key={track.id}
                  className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 space-y-3"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-white">
                      {language === 'ar' ? track.nameAr : track.nameEn}
                    </span>
                    <span className="text-[10px] font-mono text-purple-300">{track.bpm} BPM</span>
                  </div>
                  <p className="text-[11px] text-slate-400">{track.genre}</p>
                  <button
                    onClick={() => {
                      audioEngine.startMusic(track.id as any);
                      setTimeout(() => audioEngine.stopMusic(), 4000);
                    }}
                    className="w-full py-2 rounded-lg bg-purple-600/30 hover:bg-purple-600 text-purple-200 hover:text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition cursor-pointer"
                  >
                    <Volume2 className="w-3.5 h-3.5" />
                    <span>{t('common.preview')}</span>
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* SFX Section */}
          <div className="glass-panel rounded-2xl p-6 border border-purple-500/20 space-y-4">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Volume2 className="w-5 h-5 text-cyan-400" />
              <span>{language === 'ar' ? 'المؤثرات الصوتية (SFX)' : 'Sound Effects (SFX)'}</span>
            </h3>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {soundEffects.map((sfx) => (
                <button
                  key={sfx.id}
                  onClick={() => audioEngine.playSFX(sfx.id as any)}
                  className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800 hover:border-purple-500/40 text-left rtl:text-right transition cursor-pointer group"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-white group-hover:text-cyan-300 transition">
                      {language === 'ar' ? sfx.nameAr : sfx.nameEn}
                    </span>
                    <Volume2 className="w-3.5 h-3.5 text-slate-500 group-hover:text-cyan-300" />
                  </div>
                  <p className="text-[10px] text-slate-400 mt-1">{sfx.desc}</p>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Tab: Licenses */}
      {activeTab === 'licenses' && (
        <div className="glass-panel rounded-3xl p-6 md:p-8 border border-purple-500/20 space-y-4">
          <div className="flex items-center gap-2 text-emerald-400 font-bold">
            <ShieldCheck className="w-6 h-6" />
            <h3 className="text-lg text-white">
              {language === 'ar' ? 'سياسة التراخيص والاستخدام الآمن' : 'Asset Licensing & Compliance'}
            </h3>
          </div>
          <p className="text-xs md:text-sm text-slate-300 leading-relaxed">
            {language === 'ar'
              ? 'تلتزم منصة وليد AI بأعلى معايير النزاهة القانونية والفنية. جميع تصاميم الشخصيات (الأرنب بدر، الدب فارس، القرد ميمون، سلمى المستكشفة، الروبوت زيرو) والخلفيات المتجهة والمقاطع الموسيقية المضمنة تم تصميمها وتطويرها خصيصاً للمنصة، وتخضع لترخيص المشاع الإبداعي CC0 1.0 Universal.'
              : 'Waled AI strictly respects intellectual property and licensing boundaries. All character rigs, background compositions, and harmonic synthesizer presets are custom-engineered for Waled AI under the Creative Commons CC0 1.0 Universal dedication.'}
          </p>
          <div className="p-4 rounded-2xl bg-slate-950 border border-purple-500/20 text-xs text-slate-400 space-y-1 font-mono">
            {language === 'ar' ? (<>
              <p>• الاستخدام: مجاني للفيديوهات التجارية وغير التجارية.</p>
              <p>• الإسناد: غير مطلوب قانونيًا، لكن يُفضّل كتابة «صُنع بواسطة وليد AI».</p>
              <p>• بدون مخالفات حقوق نشر: مسارات متجهة وصوت مُولَّد خوارزميًا 100%.</p>
            </>) : (<>
              <p>• Permitted Use: Free for commercial and non-commercial video creations.</p>
              <p>• Attribution: Not legally required, but appreciated as "Created with Waled AI".</p>
              <p>• Zero Copyright Strikes: 100% clean vector paths &amp; algorithmic audio synthesis.</p>
            </>)}
          </div>
        </div>
      )}
    </div>
  );
};
