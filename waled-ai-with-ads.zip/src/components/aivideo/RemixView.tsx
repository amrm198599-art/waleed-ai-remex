import React, { useEffect, useRef, useState } from 'react';
import { Layers, Loader2, Upload, Smartphone, Download, AlertTriangle } from 'lucide-react';
import { useLocalization } from '../../lib/localization';
import { Project } from '../../types';
import { showWaitingAd } from '../../lib/ads/ads';

type Src = { type: 'upload' | 'project'; id: string; label: string } | null;
type AudioMode = 'both' | 'top' | 'bottom' | 'none';

const TXT: Record<'ar' | 'en', Record<string, string>> = {
  ar: {
    title: 'ريمكس: شاشة مقسومة',
    sub: 'ادمج فيديوهين في شاشة واحدة، واحد فوق والتاني تحت، واحفظ الناتج في معرض الهاتف.',
    top: 'الفيديو العلوي', bottom: 'الفيديو السفلي',
    upload: 'ارفع فيديو', app: 'فيديو من التطبيق', choose: 'اختر فيديو من التطبيق',
    uploading: 'جارٍ الرفع...', ready: 'جاهز',
    audio: 'الصوت', both: 'الاثنين', onlyTop: 'العلوي فقط', onlyBottom: 'السفلي فقط', none: 'بدون صوت',
    len: 'المدة', shortest: 'الأقصر', longest: 'الأطول (الأقصر يتكرر)',
    start: 'اعمل الريمكس', working: 'جارٍ الدمج...', done: 'الريمكس جاهز',
    save: 'حفظ في معرض الهاتف', saving: 'جارٍ التجهيز...', download: 'تنزيل MP4',
    hint: 'على الهاتف: اختر «حفظ الفيديو» من قائمة المشاركة.',
    need: 'اختر الفيديوهين أولاً.', same: 'اختر فيديوهين مختلفين.',
    wait: 'الدمج شغال في الخلفية. الإعلانات بتساعدنا نخلي التطبيق مجانيًا.',
    pollFail: 'انقطع الاتصال بالخادم أثناء الدمج. حاول مرة أخرى.',
  },
  en: {
    title: 'Remix: split screen',
    sub: 'Combine two videos in one screen, one on top and one below, and save the result to your phone gallery.',
    top: 'Top video', bottom: 'Bottom video',
    upload: 'Upload a video', app: 'Video from the app', choose: 'Choose an app video',
    uploading: 'Uploading...', ready: 'Ready',
    audio: 'Audio', both: 'Both', onlyTop: 'Top only', onlyBottom: 'Bottom only', none: 'No audio',
    len: 'Length', shortest: 'Shortest', longest: 'Longest (shorter one loops)',
    start: 'Make the remix', working: 'Mixing...', done: 'Your remix is ready',
    save: 'Save to phone gallery', saving: 'Preparing...', download: 'Download MP4',
    hint: 'On a phone: choose "Save video" in the share sheet.',
    need: 'Pick both videos first.', same: 'Pick two different videos.',
    wait: 'Your remix is rendering. Ads help keep the app free.',
    pollFail: 'Lost connection to the server while mixing. Please try again.',
  },
};

const Slot: React.FC<{
  title: string; value: Src; onChange: (s: Src) => void; projects: Project[]; L: Record<string, string>; setError: (e: string) => void;
}> = ({ title, value, onChange, projects, L, setError }) => {
  const [mode, setMode] = useState<'upload' | 'project'>('upload');
  const [busy, setBusy] = useState(false);
  const withVideo = projects.filter((p) => p.status === 'completed' && (p.streamUrl || p.downloadUrl));

  const onFile = async (f?: File) => {
    if (!f) return;
    setBusy(true); setError('');
    try {
      const r = await fetch(`/api/remix/upload?name=${encodeURIComponent(f.name)}`, {
        method: 'POST', headers: { 'Content-Type': 'application/octet-stream' }, body: f,
      });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error || 'Upload failed');
      onChange({ type: 'upload', id: d.id, label: f.name });
    } catch (e: any) { onChange(null); setError(e.message); }
    finally { setBusy(false); }
  };

  return (
    <div className="rounded-xl border border-slate-700 p-4 space-y-3">
      <div className="font-semibold">{title}</div>
      <div className="flex gap-2">
        {(['upload', 'project'] as const).map((m) => (
          <button key={m} onClick={() => { setMode(m); onChange(null); }}
            className={`rounded-full border px-3 py-1 text-sm ${mode === m ? 'border-purple-500 bg-purple-500/10' : 'border-slate-600'}`}>
            {m === 'upload' ? L.upload : L.app}
          </button>
        ))}
      </div>
      {mode === 'upload' ? (
        <label className="flex items-center gap-2 rounded-lg border border-dashed border-slate-600 p-3 cursor-pointer text-sm">
          {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
          <span className="truncate">{busy ? L.uploading : value ? `${value.label} — ${L.ready}` : L.upload}</span>
          <input type="file" accept="video/*" className="hidden" onChange={(e) => onFile(e.target.files?.[0])} />
        </label>
      ) : (
        <select className="w-full rounded-lg bg-slate-800 border border-slate-600 p-3"
          value={value?.id || ''} onChange={(e) => {
            const p = withVideo.find((x) => x.id === e.target.value);
            onChange(p ? { type: 'project', id: p.id, label: p.title } : null);
          }}>
          <option value="">{L.choose}</option>
          {withVideo.map((p) => <option key={p.id} value={p.id}>{p.title}</option>)}
        </select>
      )}
    </div>
  );
};

export const RemixView: React.FC<{ projects: Project[] }> = ({ projects }) => {
  const { language } = useLocalization();
  const L = TXT[language];
  const [top, setTop] = useState<Src>(null);
  const [bottom, setBottom] = useState<Src>(null);
  const [audio, setAudio] = useState<AudioMode>('both');
  const [duration, setDuration] = useState<'shortest' | 'longest'>('shortest');
  const [job, setJob] = useState<any>(null);
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);
  const timer = useRef<number | null>(null);
  useEffect(() => () => { if (timer.current) window.clearInterval(timer.current); }, []);

  const running = job?.status === 'running';
  const stopPolling = () => { if (timer.current) { window.clearInterval(timer.current); timer.current = null; } };

  const start = async () => {
    stopPolling(); // never leave an old poller running
    setError(''); setJob(null);
    if (!top || !bottom) return setError(L.need);
    if (top.id === bottom.id) return setError(L.same);
    try {
      const r = await fetch('/api/remix/create', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ top: { type: top.type, id: top.id }, bottom: { type: bottom.type, id: bottom.id }, audio, duration }),
      });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error || 'Request failed');
      setJob(d.job);
      showWaitingAd(); // user is waiting anyway: show an ad now
      let failures = 0;
      timer.current = window.setInterval(async () => {
        try {
          const r2 = await fetch(`/api/remix/jobs/${d.job.id}`);
          const j = await r2.json();
          if (!r2.ok) throw new Error(j.error || 'poll failed');
          failures = 0;
          setJob(j);
          if (j.status !== 'running') stopPolling();
        } catch {
          if (++failures >= 5) { stopPolling(); setJob(null); setError(L.pollFail); }
        }
      }, 2000);
    } catch (e: any) { setError(e.message); }
  };

  const saveToGallery = async (url: string) => {
    setSaving(true);
    try {
      const blob = await (await fetch(url)).blob();
      const file = new File([blob], 'waled-ai-remix.mp4', { type: 'video/mp4' });
      const nav: any = navigator;
      if (nav.canShare && nav.canShare({ files: [file] })) await nav.share({ files: [file], title: 'Waled AI' });
      else { const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = file.name; a.click(); }
    } catch (e: any) { if (e?.name !== 'AbortError') setError(e.message || 'Save failed'); }
    finally { setSaving(false); }
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold flex items-center gap-2"><Layers className="w-6 h-6 text-purple-400" />{L.title}</h1>
        <p className="text-slate-400 mt-1 text-sm">{L.sub}</p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        <Slot title={L.top} value={top} onChange={setTop} projects={projects} L={L} setError={setError} />
        <Slot title={L.bottom} value={bottom} onChange={setBottom} projects={projects} L={L} setError={setError} />
      </div>

      <div className="rounded-xl border border-slate-700 bg-slate-900/50 p-5 space-y-4">
        <div className="grid gap-4 sm:grid-cols-2">
          <label className="space-y-1 block"><span className="text-sm text-slate-300">{L.audio}</span>
            <select value={audio} onChange={(e) => setAudio(e.target.value as AudioMode)} className="w-full rounded-lg bg-slate-800 border border-slate-600 p-3">
              <option value="both">{L.both}</option><option value="top">{L.onlyTop}</option>
              <option value="bottom">{L.onlyBottom}</option><option value="none">{L.none}</option>
            </select></label>
          <label className="space-y-1 block"><span className="text-sm text-slate-300">{L.len}</span>
            <select value={duration} onChange={(e) => setDuration(e.target.value as any)} className="w-full rounded-lg bg-slate-800 border border-slate-600 p-3">
              <option value="shortest">{L.shortest}</option><option value="longest">{L.longest}</option>
            </select></label>
        </div>
        <button onClick={start} disabled={running}
          className="w-full rounded-lg bg-purple-600 hover:bg-purple-500 disabled:opacity-50 p-3 font-semibold flex items-center justify-center gap-2">
          {running ? <><Loader2 className="w-4 h-4 animate-spin" />{L.working}</> : <><Layers className="w-4 h-4" />{L.start}</>}
        </button>
      </div>

      {running && <p className="text-xs text-slate-400 text-center">{L.wait}</p>}

      {error && <div className="rounded-lg border border-red-500/40 bg-red-500/10 p-3 text-sm flex gap-2"><AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />{error}</div>}
      {job?.status === 'failed' && <div className="rounded-lg border border-red-500/40 bg-red-500/10 p-3 text-sm">{job.error}</div>}

      {job?.status === 'completed' && (
        <div className="rounded-xl border border-slate-700 bg-slate-900/50 p-5 space-y-3">
          <p className="font-semibold text-emerald-400">{L.done}</p>
          <video src={job.streamUrl} controls playsInline className="w-full max-w-sm mx-auto rounded-lg bg-black" />
          <div className="flex flex-wrap gap-2 justify-center">
            <button onClick={() => saveToGallery(job.downloadUrl)} disabled={saving}
              className="inline-flex items-center gap-2 rounded-lg bg-purple-600 hover:bg-purple-500 disabled:opacity-60 px-4 py-2 text-sm font-semibold">
              {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Smartphone className="w-4 h-4" />}{saving ? L.saving : L.save}
            </button>
            <a href={job.downloadUrl} className="inline-flex items-center gap-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 px-4 py-2 text-sm font-semibold">
              <Download className="w-4 h-4" />{L.download}
            </a>
          </div>
          <p className="text-xs text-slate-500 text-center">{L.hint}</p>
        </div>
      )}
    </div>
  );
};
