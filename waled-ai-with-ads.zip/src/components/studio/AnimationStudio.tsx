import React, { useState } from 'react';
import { useLocalization } from '../../lib/localization';
import {
  CharacterId,
  CharacterAction,
  FacialExpression,
  BackgroundId,
  CameraMovement,
  SFXType,
} from '../../types';
import { CHARACTER_CATALOG } from '../../lib/animation/characters';
import { BACKGROUND_CATALOG } from '../../lib/animation/backgrounds';
import { CharacterCanvas } from './CharacterCanvas';
import { audioEngine } from '../../lib/audio/engine';
import {
  Sparkles,
  Sliders,
  Volume2,
  Maximize2,
  Video,
  Camera,
  Play,
  RotateCcw,
  Check,
} from 'lucide-react';

interface AnimationStudioProps {
  onNavigate: (view: string) => void;
}

export const AnimationStudio: React.FC<AnimationStudioProps> = ({ onNavigate }) => {
  const { language, t } = useLocalization();

  const [selectedCharId, setSelectedCharId] = useState<CharacterId>('bader_rabbit');
  const [selectedAction, setSelectedAction] = useState<CharacterAction>('walk');
  const [selectedExpression, setSelectedExpression] = useState<FacialExpression>('happy');
  const [selectedBackground, setSelectedBackground] = useState<BackgroundId>('enchanted_forest');
  const [selectedCamera, setSelectedCamera] = useState<CameraMovement>('static');
  const [charScale, setCharScale] = useState<number>(1.2);
  const [flipX, setFlipX] = useState<boolean>(false);

  const currentChar =
    CHARACTER_CATALOG.find((c) => c.id === selectedCharId) || CHARACTER_CATALOG[0];

  const actionsList: { id: CharacterAction; labelEn: string; labelAr: string }[] = [
    { id: 'idle', labelEn: 'Idle', labelAr: 'وقوف وتنفس' },
    { id: 'walk', labelEn: 'Walk Cycle', labelAr: 'مشي إيقاعي' },
    { id: 'run', labelEn: 'Run Cycle', labelAr: 'ركض سريع' },
    { id: 'jump', labelEn: 'Jump Arc', labelAr: 'قفز بهلواني' },
    { id: 'wave', labelEn: 'Hand Wave', labelAr: 'تلويح وتحية' },
    { id: 'talk', labelEn: 'Talk Lip-Sync', labelAr: 'تحدث وتحريك الفم' },
    { id: 'laugh', labelEn: 'Laugh Shaking', labelAr: 'ضحك مرح' },
    { id: 'celebrate', labelEn: 'Celebrate & Cheer', labelAr: 'احتفال وتشجيع' },
    { id: 'fall', labelEn: 'Comedic Fall', labelAr: 'سقوط كوميدي' },
    { id: 'look_left', labelEn: 'Turn Left', labelAr: 'التفات لليسار' },
    { id: 'look_right', labelEn: 'Turn Right', labelAr: 'التفات لليمين' },
  ];

  const expressionsList: { id: FacialExpression; labelEn: string; labelAr: string }[] = [
    { id: 'happy', labelEn: 'Happy', labelAr: 'سعيد' },
    { id: 'talking', labelEn: 'Talking', labelAr: 'متحدث' },
    { id: 'surprised', labelEn: 'Surprised', labelAr: 'متفاجئ' },
    { id: 'laughing', labelEn: 'Laughing', labelAr: 'ضاحك' },
    { id: 'determined', labelEn: 'Determined', labelAr: 'عازم' },
    { id: 'silly', labelEn: 'Silly', labelAr: 'مشاغب' },
  ];

  const sfxList: { id: SFXType; labelEn: string; labelAr: string }[] = [
    { id: 'pop', labelEn: 'Pop', labelAr: 'فرقعة' },
    { id: 'boing', labelEn: 'Boing', labelAr: 'ارتداد رنان' },
    { id: 'whoosh', labelEn: 'Whoosh', labelAr: 'هبوب سريع' },
    { id: 'cheer', labelEn: 'Cheer', labelAr: 'هتاف واحتفال' },
    { id: 'laugh', labelEn: 'Laugh', labelAr: 'ضحكة' },
    { id: 'footsteps', labelEn: 'Steps', labelAr: 'خطوات' },
    { id: 'bell', labelEn: 'Bell', labelAr: 'جرس نقي' },
  ];

  return (
    <div className="space-y-6 pb-16">
      {/* Studio Header */}
      <div className="glass-panel rounded-3xl p-6 border border-purple-500/20 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-500/20 text-purple-300 text-xs font-bold mb-2">
            <Sparkles className="w-3.5 h-3.5 text-cyan-300" />
            <span>{language === 'ar' ? 'الوضع أ: استوديو الكرتون المتحرك' : 'Mode A: Animated Cartoon Studio'}</span>
          </div>
          <h1 className="text-2xl md:text-3xl font-extrabold text-white">
            {language === 'ar' ? 'استوديو التحريك ثنائي الأبعاد' : '2D Cartoon Animation Studio'}
          </h1>
          <p className="text-xs md:text-sm text-slate-400 mt-1">
            {language === 'ar'
              ? 'تحكم كامل بنماذج الشخصيات المتجهة، والوضعيات، وحركات الكاميرا، مع المحافظة التامة على الهوية البصرية.'
              : 'Real-time rigged character testing, skeletal keyframe actions, lip-syncing, and camera staging.'}
          </p>
        </div>

        <button
          onClick={() => onNavigate('create')}
          className="px-5 py-3 rounded-2xl bg-waled-gradient hover:opacity-95 text-white font-bold text-xs md:text-sm shadow-xl shadow-purple-600/30 flex items-center gap-2 self-start md:self-auto cursor-pointer"
        >
          <Video className="w-4 h-4" />
          <span>{language === 'ar' ? 'إنشاء مشروع جديد بهذه الإعدادات' : 'Create Video with this Rig'}</span>
        </button>
      </div>

      {/* Main Studio Workspace Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left / Center: Interactive Canvas Stage */}
        <div className="lg:col-span-8 space-y-4">
          <div className="relative aspect-video rounded-3xl overflow-hidden border-2 border-purple-500/30 shadow-2xl bg-slate-950 flex items-center justify-center">
            <CharacterCanvas
              characterId={selectedCharId}
              action={selectedAction}
              expression={selectedExpression}
              backgroundId={selectedBackground}
              width={960}
              height={540}
              scale={charScale}
              flipX={flipX}
              className="w-full h-full object-contain"
            />

            {/* Stage HUD Overlay */}
            <div className="absolute top-4 left-4 flex items-center gap-2">
              <span className="px-3 py-1 rounded-xl text-xs font-mono font-bold bg-slate-950/80 text-cyan-300 border border-purple-500/30 backdrop-blur-md">
                {language === 'ar' ? currentChar.nameAr : currentChar.nameEn}
              </span>
              <span className="px-3 py-1 rounded-xl text-xs font-mono text-purple-200 bg-purple-950/80 border border-purple-500/30 backdrop-blur-md">
                {selectedAction}
              </span>
            </div>

            <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between text-xs text-slate-300 bg-slate-950/80 p-2.5 rounded-2xl border border-purple-500/20 backdrop-blur-md">
              <span className="font-semibold text-emerald-400">● 60 FPS Vector Canvas</span>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setFlipX(!flipX)}
                  className={`px-2.5 py-1 rounded-lg border text-xs font-semibold transition ${
                    flipX ? 'bg-purple-600 text-white border-purple-400' : 'bg-slate-900 border-slate-700'
                  }`}
                >
                  {language === 'ar' ? 'عكس الاتجاه (Flip X)' : 'Flip Horizontal'}
                </button>
                <button
                  onClick={() => {
                    setCharScale(1.2);
                    setFlipX(false);
                  }}
                  className="p-1 text-slate-400 hover:text-white"
                  title="Reset Scale"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>

          {/* Sound FX Trigger Bar */}
          <div className="glass-panel p-4 rounded-2xl border border-purple-500/20">
            <p className="text-xs font-bold text-white mb-2 flex items-center gap-1.5">
              <Volume2 className="w-4 h-4 text-cyan-400" />
              <span>{language === 'ar' ? 'المؤثرات الصوتية المتزامنة (Web Audio SFX)' : 'Live Sound FX Triggers'}</span>
            </p>
            <div className="flex flex-wrap gap-2">
              {sfxList.map((s) => (
                <button
                  key={s.id}
                  onClick={() => audioEngine.playSFX(s.id)}
                  className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-purple-950/60 border border-slate-800 hover:border-purple-500/40 text-xs font-semibold text-slate-300 hover:text-white transition cursor-pointer"
                >
                  {language === 'ar' ? s.labelAr : s.labelEn}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Right: Inspector & Rig Controls */}
        <div className="lg:col-span-4 space-y-5">
          {/* 1. Character Rig Picker */}
          <div className="glass-panel p-4 rounded-2xl border border-purple-500/20 space-y-3">
            <label className="block text-xs font-bold text-slate-300">
              {language === 'ar' ? 'اختر الشخصية الأساسية' : 'Select Rigged Character'}
            </label>
            <div className="grid grid-cols-2 gap-2">
              {CHARACTER_CATALOG.map((c) => {
                const isSelected = selectedCharId === c.id;
                return (
                  <button
                    key={c.id}
                    onClick={() => setSelectedCharId(c.id)}
                    className={`p-2.5 rounded-xl text-xs font-bold transition text-left rtl:text-right border cursor-pointer ${
                      isSelected
                        ? 'bg-purple-600 text-white border-purple-400 shadow-md shadow-purple-600/30'
                        : 'bg-slate-900 text-slate-300 border-slate-800 hover:bg-slate-800'
                    }`}
                  >
                    <div>{language === 'ar' ? c.nameAr : c.nameEn}</div>
                    <span className="text-[10px] text-purple-200/70 font-normal">{c.species}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* 2. Keyframe Action Picker */}
          <div className="glass-panel p-4 rounded-2xl border border-purple-500/20 space-y-3">
            <label className="block text-xs font-bold text-slate-300">
              {language === 'ar' ? 'الحركة والوضعية الهيكلية' : 'Action Preset & Pose'}
            </label>
            <div className="grid grid-cols-2 gap-2">
              {actionsList.map((a) => {
                const isSelected = selectedAction === a.id;
                return (
                  <button
                    key={a.id}
                    onClick={() => setSelectedAction(a.id)}
                    className={`p-2 rounded-xl text-xs font-semibold transition border cursor-pointer ${
                      isSelected
                        ? 'bg-cyan-600 text-white border-cyan-400 shadow-md shadow-cyan-600/30'
                        : 'bg-slate-900 text-slate-300 border-slate-800 hover:bg-slate-800'
                    }`}
                  >
                    {language === 'ar' ? a.labelAr : a.labelEn}
                  </button>
                );
              })}
            </div>
          </div>

          {/* 3. Facial Expression & Lip-Sync */}
          <div className="glass-panel p-4 rounded-2xl border border-purple-500/20 space-y-3">
            <label className="block text-xs font-bold text-slate-300">
              {language === 'ar' ? 'تعبير الوجه وتزامن الشفاه' : 'Facial Viseme & Expression'}
            </label>
            <div className="grid grid-cols-3 gap-2">
              {expressionsList.map((ex) => {
                const isSelected = selectedExpression === ex.id;
                return (
                  <button
                    key={ex.id}
                    onClick={() => setSelectedExpression(ex.id)}
                    className={`p-2 rounded-xl text-xs font-semibold transition border cursor-pointer ${
                      isSelected
                        ? 'bg-purple-600 text-white border-purple-400 shadow-md'
                        : 'bg-slate-900 text-slate-300 border-slate-800 hover:bg-slate-800'
                    }`}
                  >
                    {language === 'ar' ? ex.labelAr : ex.labelEn}
                  </button>
                );
              })}
            </div>
          </div>

          {/* 4. Background Environment */}
          <div className="glass-panel p-4 rounded-2xl border border-purple-500/20 space-y-2">
            <label className="block text-xs font-bold text-slate-300">
              {language === 'ar' ? 'البيئة والخلفية' : 'Background Environment'}
            </label>
            <select
              value={selectedBackground}
              onChange={(e) => setSelectedBackground(e.target.value as BackgroundId)}
              className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white cursor-pointer"
            >
              {BACKGROUND_CATALOG.map((b) => (
                <option key={b.id} value={b.id}>
                  {language === 'ar' ? b.nameAr : b.nameEn}
                </option>
              ))}
            </select>
          </div>

          {/* 5. Scale Slider */}
          <div className="glass-panel p-4 rounded-2xl border border-purple-500/20 space-y-2">
            <div className="flex justify-between text-xs text-slate-300 font-bold">
              <span>{language === 'ar' ? 'مقياس الحجم' : 'Character Scale'}</span>
              <span>{charScale.toFixed(2)}x</span>
            </div>
            <input
              type="range"
              min="0.6"
              max="2.2"
              step="0.05"
              value={charScale}
              onChange={(e) => setCharScale(parseFloat(e.target.value))}
              className="w-full accent-purple-500 cursor-pointer"
            />
          </div>
        </div>
      </div>
    </div>
  );
};
