import React, { useState, useEffect, useRef } from 'react';
import { useLocalization } from '../../lib/localization';
import {
  Project,
  Scene,
  CharacterId,
  BackgroundId,
  CharacterAction,
  MusicTrackType,
  QuotaStatus,
} from '../../types';
import { CHARACTER_CATALOG } from '../../lib/animation/characters';
import { BACKGROUND_CATALOG } from '../../lib/animation/backgrounds';
import { CharacterCanvas } from '../studio/CharacterCanvas';
import { audioEngine } from '../../lib/audio/engine';
import { VideoRenderingPipeline, RenderProgressUpdate } from '../../lib/rendering/pipeline';
import { VideoExportCard } from '../exports/VideoExportCard';
import {
  Play,
  Pause,
  Video,
  Plus,
  Trash2,
  Copy,
  Clock,
  Layers,
  Save,
  Volume2,
  Sliders,
  ChevronLeft,
  ChevronRight,
  Download,
  AlertTriangle,
  CheckCircle2,
  X,
} from 'lucide-react';

interface ProjectEditorProps {
  project: Project;
  quota: QuotaStatus | null;
  onSaveProject: (updated: Project) => Promise<void>;
  onRefreshQuota: () => void;
}

export const ProjectEditor: React.FC<ProjectEditorProps> = ({
  project,
  quota,
  onSaveProject,
  onRefreshQuota,
}) => {
  const { language, t, isRTL } = useLocalization();

  const [scenes, setScenes] = useState<Scene[]>(project.scenes || []);
  const [activeSceneIdx, setActiveSceneIdx] = useState<number>(0);
  const [saveStatus, setSaveStatus] = useState<'saved' | 'saving'>('saved');

  // Preview Playback State
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const playbackTimerRef = useRef<any>(null);

  // Render modal state
  const [isRendering, setIsRendering] = useState<boolean>(false);
  const [renderProgress, setRenderProgress] = useState<RenderProgressUpdate | null>(null);
  const [renderedUrl, setRenderedUrl] = useState<string | null>(project.renderedVideoUrl || null);
  const [renderError, setRenderError] = useState<string | null>(null);
  const [showExportModal, setShowExportModal] = useState<boolean>(false);

  const activeScene = scenes[activeSceneIdx] || scenes[0];

  // Autosave when scenes change
  useEffect(() => {
    setSaveStatus('saving');
    const timer = setTimeout(async () => {
      const updated: Project = {
        ...project,
        scenes,
        duration: scenes.reduce((acc, s) => acc + (s.duration || 5), 0),
      };
      await onSaveProject(updated);
      setSaveStatus('saved');
    }, 800);

    return () => clearTimeout(timer);
  }, [scenes]);

  // Clean up playback on unmount
  useEffect(() => {
    return () => {
      if (playbackTimerRef.current) clearInterval(playbackTimerRef.current);
      audioEngine.stopAll();
    };
  }, []);

  const handleUpdateActiveScene = (updates: Partial<Scene>) => {
    setScenes((prev) => {
      const copy = [...prev];
      copy[activeSceneIdx] = { ...copy[activeSceneIdx], ...updates };
      return copy;
    });
  };

  const handleAddScene = () => {
    const newScene: Scene = {
      id: `scene_${Date.now()}`,
      order: scenes.length,
      duration: 5,
      narration: language === 'ar' ? 'مشهد جديد...' : 'New scene unfolding...',
      dialogue: [
        {
          id: `diag_${Date.now()}`,
          characterId: 'bader_rabbit',
          speakerName: language === 'ar' ? 'الأرنب بدر' : 'Bader',
          text: language === 'ar' ? 'مغامرة جديدة تبدأ الآن!' : 'A new adventure begins now!',
          expression: 'happy',
        },
      ],
      characters: [
        {
          characterId: 'bader_rabbit',
          action: 'walk',
          x: 35,
          y: 82,
          scale: 1.1,
          flipX: false,
          zIndex: 1,
        },
      ],
      backgroundId: 'enchanted_forest',
      camera: 'static',
      transition: 'fade',
      sfx: 'pop',
      musicTrack: 'playful_adventure',
      subtitlesEnabled: true,
    };
    setScenes((prev) => [...prev, newScene]);
    setActiveSceneIdx(scenes.length);
  };

  const handleDuplicateScene = (idx: number) => {
    const target = scenes[idx];
    const duplicated: Scene = {
      ...JSON.parse(JSON.stringify(target)),
      id: `scene_${Date.now()}`,
    };
    const next = [...scenes.slice(0, idx + 1), duplicated, ...scenes.slice(idx + 1)].map(
      (s, i) => ({ ...s, order: i })
    );
    setScenes(next);
    setActiveSceneIdx(idx + 1);
  };

  const handleDeleteScene = (idx: number) => {
    if (scenes.length <= 1) return;
    const next = scenes.filter((_, i) => i !== idx).map((s, i) => ({ ...s, order: i }));
    setScenes(next);
    setActiveSceneIdx(Math.max(0, idx - 1));
  };

  // Full Video Playback Sequencer
  const togglePlayAll = () => {
    if (isPlaying) {
      setIsPlaying(false);
      if (playbackTimerRef.current) clearInterval(playbackTimerRef.current);
      audioEngine.stopAll();
      return;
    }

    setIsPlaying(true);
    let currentIdx = 0;
    setActiveSceneIdx(0);

    const playScene = (idx: number) => {
      if (idx >= scenes.length) {
        setIsPlaying(false);
        audioEngine.stopAll();
        return;
      }
      setActiveSceneIdx(idx);
      const s = scenes[idx];
      if (s.musicTrack) audioEngine.startMusic(s.musicTrack);
      if (s.sfx) audioEngine.playSFX(s.sfx);
      if (s.dialogue?.[0]) {
        audioEngine.speakDialogue(s.dialogue[0].text, project.language, s.dialogue[0].characterId);
      }

      playbackTimerRef.current = setTimeout(() => {
        playScene(idx + 1);
      }, (s.duration || 5) * 1000);
    };

    playScene(0);
  };

  // Render MP4
  const handleRenderVideo = async () => {
    setRenderError(null);
    setIsRendering(true);
    setShowExportModal(true);

    try {
      // 1. Quota reservation check
      const jobRes = await fetch('/api/jobs/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          projectId: project.id,
          idempotencyKey: `render_editor_${project.id}_${Date.now()}`,
        }),
      });

      if (!jobRes.ok) {
        const errorData = await jobRes.json();
        if (jobRes.status === 429) {
          throw new Error(
            errorData.message ||
              (language === 'ar'
                ? 'هناك عملية تصيير جارية حالياً. يرجى الانتظار حتى اكتمالها.'
                : 'A video generation job is already in progress. Please wait for it to complete.')
          );
        }
        throw new Error(errorData.error || 'Failed to initialize generation slot');
      }

      onRefreshQuota();

      // 2. Render & Transcode on server with FFmpeg
      const pipeline = new VideoRenderingPipeline();
      const result = await pipeline.renderVideo(
        scenes,
        project.aspectRatio,
        project.language,
        (progress) => setRenderProgress(progress),
        project.id
      );

      setRenderedUrl(result.videoUrl);

      await onSaveProject({
        ...project,
        scenes,
        renderedVideoUrl: result.videoUrl,
        streamUrl: result.streamUrl,
        downloadUrl: result.downloadUrl,
        status: 'completed',
      });
    } catch (err: any) {
      console.error('Render error:', err);
      setRenderError(err.message || 'Rendering failed');
    } finally {
      setIsRendering(false);
      onRefreshQuota();
    }
  };

  const primaryChar = activeScene?.characters[0]?.characterId || 'bader_rabbit';
  const primaryAction = activeScene?.characters[0]?.action || 'idle';
  const totalDuration = scenes.reduce((acc, s) => acc + (s.duration || 5), 0);

  return (
    <div className="space-y-6 pb-20">
      {/* Top Action Bar */}
      <div className="glass-panel rounded-3xl p-4 md:p-6 border border-purple-500/20 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl md:text-2xl font-bold text-white">{project.title}</h1>
            <span className="px-2 py-0.5 rounded-md text-[10px] font-mono bg-purple-950 text-purple-300 border border-purple-500/30">
              {project.aspectRatio}
            </span>
          </div>
          <div className="flex items-center gap-3 text-xs text-slate-400 mt-1">
            <span>
              {scenes.length} {language === 'ar' ? 'مشاهد' : 'scenes'} • {totalDuration}s total
            </span>
            <span className="flex items-center gap-1 text-slate-400">
              <Save className="w-3 h-3 text-purple-400" />
              {saveStatus === 'saving' ? t('editor.saving') : t('editor.saved')}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={togglePlayAll}
            className={`px-4 py-2.5 rounded-2xl text-xs font-bold flex items-center gap-2 transition cursor-pointer border ${
              isPlaying
                ? 'bg-amber-600 text-white border-amber-400 animate-pulse'
                : 'bg-slate-900 text-slate-200 border-slate-700 hover:bg-slate-800'
            }`}
          >
            {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 text-emerald-400" />}
            <span>{isPlaying ? t('editor.pause') : t('editor.play_all')}</span>
          </button>

          <button
            onClick={handleRenderVideo}
            disabled={isRendering}
            className="px-5 py-2.5 rounded-2xl bg-waled-gradient hover:opacity-95 text-white font-extrabold text-xs shadow-lg shadow-purple-600/30 flex items-center gap-2 transition cursor-pointer"
          >
            <Video className="w-4 h-4 text-cyan-300" />
            <span>{t('editor.render_video')}</span>
          </button>
        </div>
      </div>

      {/* Main Canvas Stage & Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Stage Preview */}
        <div className="lg:col-span-8 space-y-4">
          <div className="relative aspect-video rounded-3xl overflow-hidden border-2 border-purple-500/30 shadow-2xl bg-slate-950 flex items-center justify-center">
            {activeScene && (
              <CharacterCanvas
                characterId={primaryChar}
                action={primaryAction}
                expression={activeScene.dialogue?.[0]?.expression || 'happy'}
                backgroundId={activeScene.backgroundId}
                width={960}
                height={540}
                scale={1.15}
              />
            )}

            {/* Subtitle Pill on Stage */}
            {activeScene?.narration && (
              <div className="absolute bottom-6 left-6 right-6 text-center">
                <span className="inline-block bg-slate-950/85 text-white text-xs md:text-sm font-bold px-4 py-2 rounded-2xl border border-purple-500/40 backdrop-blur-md shadow-lg">
                  {activeScene.dialogue?.[0]
                    ? `${activeScene.dialogue[0].speakerName}: ${activeScene.dialogue[0].text}`
                    : activeScene.narration}
                </span>
              </div>
            )}
          </div>

          {/* Timeline Strip */}
          <div className="glass-panel p-4 rounded-2xl border border-purple-500/20 space-y-3">
            <div className="flex items-center justify-between text-xs font-bold text-white">
              <span className="flex items-center gap-1.5">
                <Layers className="w-4 h-4 text-purple-400" />
                {language === 'ar' ? 'شريط المشاهد الزمني' : 'Scene Timeline'}
              </span>
              <button
                onClick={handleAddScene}
                className="px-2.5 py-1 rounded-lg bg-purple-600/30 text-purple-300 hover:bg-purple-600 hover:text-white transition flex items-center gap-1 text-[11px]"
              >
                <Plus className="w-3 h-3" />
                <span>{t('editor.add_scene')}</span>
              </button>
            </div>

            <div className="flex items-center gap-3 overflow-x-auto pb-2 scrollbar-none">
              {scenes.map((scene, idx) => {
                const isActive = activeSceneIdx === idx;
                const char = scene.characters[0]?.characterId || 'bader_rabbit';
                return (
                  <div
                    key={scene.id}
                    onClick={() => setActiveSceneIdx(idx)}
                    className={`flex-shrink-0 w-36 p-2 rounded-xl border cursor-pointer transition space-y-2 ${
                      isActive
                        ? 'bg-purple-950/70 border-purple-400 shadow-md ring-2 ring-purple-500/30'
                        : 'bg-slate-950/60 border-slate-800 hover:bg-slate-900'
                    }`}
                  >
                    <div className="h-16 rounded-lg overflow-hidden bg-slate-900 flex items-center justify-center relative">
                      <CharacterCanvas
                        characterId={char}
                        action="idle"
                        backgroundId={scene.backgroundId}
                        width={140}
                        height={64}
                        scale={0.5}
                      />
                      <span className="absolute bottom-1 right-1 px-1 rounded text-[9px] font-mono bg-black/80 text-cyan-300">
                        {scene.duration}s
                      </span>
                    </div>

                    <div className="flex items-center justify-between text-[11px]">
                      <span className="font-bold text-slate-200">
                        {t('editor.scene_number', { num: idx + 1 })}
                      </span>
                      <div className="flex items-center gap-1">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDuplicateScene(idx);
                          }}
                          className="text-slate-400 hover:text-purple-300"
                          title={t('editor.duplicate_scene')}
                        >
                          <Copy className="w-3 h-3" />
                        </button>
                        {scenes.length > 1 && (
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleDeleteScene(idx);
                            }}
                            className="text-slate-400 hover:text-rose-400"
                            title={t('editor.delete_scene')}
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Inspector Panel */}
        <div className="lg:col-span-4 space-y-4">
          <div className="glass-panel p-5 rounded-3xl border border-purple-500/20 space-y-4">
            <h3 className="text-sm font-extrabold text-white flex items-center justify-between border-b border-purple-500/20 pb-2">
              <span>{t('editor.scene_number', { num: activeSceneIdx + 1 })}</span>
              <div className="flex items-center gap-1">
                <label className="text-[11px] text-slate-400">{t('editor.duration_sec')}:</label>
                <input
                  type="number"
                  min="2"
                  max="30"
                  value={activeScene.duration}
                  onChange={(e) =>
                    handleUpdateActiveScene({ duration: Math.max(1, parseInt(e.target.value) || 5) })
                  }
                  className="w-14 bg-slate-900 border border-slate-700 rounded-lg px-2 py-0.5 text-xs text-white text-center font-mono"
                />
              </div>
            </h3>

            {/* Narration */}
            <div className="space-y-1">
              <label className="block text-xs font-bold text-slate-300">
                {t('editor.narration')}
              </label>
              <textarea
                rows={2}
                value={activeScene.narration}
                onChange={(e) => handleUpdateActiveScene({ narration: e.target.value })}
                className="w-full bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-xs text-white resize-none"
              />
            </div>

            {/* Dialogue */}
            {activeScene.dialogue && activeScene.dialogue.length > 0 && (
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-slate-300">
                    {t('editor.dialogue')} ({activeScene.dialogue[0].speakerName})
                  </label>
                  <button
                    onClick={() =>
                      audioEngine.speakDialogue(
                        activeScene.dialogue[0].text,
                        project.language,
                        activeScene.dialogue[0].characterId
                      )
                    }
                    className="text-[11px] text-purple-300 hover:text-white flex items-center gap-1"
                  >
                    <Volume2 className="w-3 h-3" />
                    <span>{t('common.preview')}</span>
                  </button>
                </div>
                <input
                  type="text"
                  value={activeScene.dialogue[0].text}
                  onChange={(e) => {
                    const copy = [...activeScene.dialogue];
                    copy[0] = { ...copy[0], text: e.target.value };
                    handleUpdateActiveScene({ dialogue: copy });
                  }}
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white"
                />
              </div>
            )}

            {/* Character Selection */}
            <div className="space-y-1">
              <label className="block text-xs font-bold text-slate-300">
                {t('editor.characters')}
              </label>
              <select
                value={primaryChar}
                onChange={(e) => {
                  const newCharId = e.target.value as CharacterId;
                  const charCopy = [...activeScene.characters];
                  if (charCopy.length > 0) charCopy[0] = { ...charCopy[0], characterId: newCharId };
                  handleUpdateActiveScene({ characters: charCopy });
                }}
                className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white cursor-pointer"
              >
                {CHARACTER_CATALOG.map((c) => (
                  <option key={c.id} value={c.id}>
                    {language === 'ar' ? c.nameAr : c.nameEn}
                  </option>
                ))}
              </select>
            </div>

            {/* Character Action */}
            <div className="space-y-1">
              <label className="block text-xs font-bold text-slate-300">
                {t('editor.action')}
              </label>
              <select
                value={primaryAction}
                onChange={(e) => {
                  const newAction = e.target.value as CharacterAction;
                  const charCopy = [...activeScene.characters];
                  if (charCopy.length > 0) charCopy[0] = { ...charCopy[0], action: newAction };
                  handleUpdateActiveScene({ characters: charCopy });
                }}
                className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white cursor-pointer"
              >
                <option value="idle">{t('actions.idle')}</option>
                <option value="walk">{t('actions.walk')}</option>
                <option value="run">{t('actions.run')}</option>
                <option value="jump">{t('actions.jump')}</option>
                <option value="wave">{t('actions.wave')}</option>
                <option value="talk">{t('actions.talk')}</option>
                <option value="laugh">{t('actions.laugh')}</option>
                <option value="celebrate">{t('actions.celebrate')}</option>
                <option value="fall">{t('actions.fall')}</option>
              </select>
            </div>

            {/* Background */}
            <div className="space-y-1">
              <label className="block text-xs font-bold text-slate-300">
                {t('editor.background')}
              </label>
              <select
                value={activeScene.backgroundId}
                onChange={(e) =>
                  handleUpdateActiveScene({ backgroundId: e.target.value as BackgroundId })
                }
                className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white cursor-pointer"
              >
                {BACKGROUND_CATALOG.map((b) => (
                  <option key={b.id} value={b.id}>
                    {language === 'ar' ? b.nameAr : b.nameEn}
                  </option>
                ))}
              </select>
            </div>

            {/* Music & SFX */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="block text-xs font-bold text-slate-300">
                  {t('editor.music')}
                </label>
                <select
                  value={activeScene.musicTrack || 'playful_adventure'}
                  onChange={(e) =>
                    handleUpdateActiveScene({ musicTrack: e.target.value as MusicTrackType })
                  }
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl px-2.5 py-1.5 text-xs text-white cursor-pointer"
                >
                  <option value="playful_adventure">{language === 'ar' ? 'مرح' : 'Playful'}</option>
                  <option value="whimsical_story">{language === 'ar' ? 'خيالي' : 'Whimsical'}</option>
                  <option value="upbeat_groove">{language === 'ar' ? 'حماسي' : 'Upbeat'}</option>
                  <option value="none">{language === 'ar' ? 'بدون' : 'None'}</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="block text-xs font-bold text-slate-300">
                  {t('editor.sound_effect')}
                </label>
                <select
                  value={activeScene.sfx || 'pop'}
                  onChange={(e) => handleUpdateActiveScene({ sfx: e.target.value as any })}
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl px-2.5 py-1.5 text-xs text-white cursor-pointer"
                >
                  <option value="pop">{language === 'ar' ? 'فقاعة' : 'Pop'}</option>
                  <option value="boing">{language === 'ar' ? 'نطّة' : 'Boing'}</option>
                  <option value="whoosh">{language === 'ar' ? 'شفطة' : 'Whoosh'}</option>
                  <option value="cheer">{language === 'ar' ? 'تشجيع' : 'Cheer'}</option>
                  <option value="laugh">{language === 'ar' ? 'ضحك' : 'Laugh'}</option>
                  <option value="footsteps">{language === 'ar' ? 'خطوات' : 'Steps'}</option>
                  <option value="bell">{language === 'ar' ? 'جرس' : 'Bell'}</option>
                  <option value="none">{language === 'ar' ? 'بدون' : 'None'}</option>
                </select>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Export / Download Modal Overlay with VideoExportCard */}
      {showExportModal && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
          <div className="relative max-w-xl w-full my-8">
            <button
              onClick={() => setShowExportModal(false)}
              className="absolute -top-12 right-0 p-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-300 hover:text-white transition z-10 cursor-pointer"
              aria-label="Close"
            >
              <X className="w-5 h-5" />
            </button>
            <VideoExportCard
              projectId={project.id}
              title={project.title}
              aspectRatio={project.aspectRatio}
              duration={totalDuration}
              videoUrl={renderedUrl || project.renderedVideoUrl}
              downloadUrl={project.downloadUrl}
              isRendering={isRendering}
              renderProgress={renderProgress}
              error={renderError}
              onRetry={handleRenderVideo}
              showEditButton={false}
            />
          </div>
        </div>
      )}

      {/* Render Download Available Banner */}
      {(renderedUrl || project.renderedVideoUrl) && !showExportModal && (
        <div className="p-4 rounded-2xl bg-emerald-950/40 border border-emerald-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-400 flex-shrink-0" />
            <div>
              <p className="text-xs md:text-sm font-bold text-white">
                {language === 'ar' ? 'فيديو MP4 جاهز للتحميل والمشاهدة' : 'Rendered MP4 Video is ready'}
              </p>
              <p className="text-[11px] text-slate-400">
                {language === 'ar'
                  ? 'تم إنتاجه بجودة عالية مع خيارات التنزيل المباشر وفتح الفيديو للهواتف.'
                  : 'Produced in verified H.264 MP4 with mobile open & direct download options.'}
              </p>
            </div>
          </div>
          <button
            onClick={() => setShowExportModal(true)}
            className="px-5 py-2.5 rounded-xl bg-waled-gradient hover:opacity-95 text-white font-bold text-xs flex items-center justify-center gap-2 transition shadow-md shadow-purple-600/30 cursor-pointer"
          >
            <Download className="w-4 h-4 text-cyan-300" />
            <span>{t('render.download_btn')}</span>
          </button>
        </div>
      )}
    </div>
  );
};
