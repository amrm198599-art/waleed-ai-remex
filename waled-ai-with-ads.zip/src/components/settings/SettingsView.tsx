import React from 'react';
import { useLocalization } from '../../lib/localization';
import { QuotaStatus } from '../../types';
import {
  Settings,
  Globe,
  Clock,
  Flame,
  ShieldCheck,
  CheckCircle2,
  Cpu,
  Database,
  Film,
  Sparkles,
} from 'lucide-react';

interface SettingsViewProps {
  quota: QuotaStatus | null;
  onRefreshQuota: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({ quota, onRefreshQuota }) => {
  const { language, setLanguage, t } = useLocalization();

  const formatResetTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    if (hours > 0) return `${hours}h ${mins}m`;
    return `${mins}m`;
  };

  return (
    <div className="space-y-6 max-w-4xl pb-16">
      <div className="glass-panel rounded-3xl p-6 border border-purple-500/20">
        <h1 className="text-2xl font-extrabold text-white flex items-center gap-2">
          <Settings className="w-6 h-6 text-purple-400" />
          <span>{t('nav.settings')}</span>
        </h1>
        <p className="text-xs md:text-sm text-slate-400 mt-1">
          {language === 'ar'
            ? 'إدارة إعدادات المنصة، الرصيد اليومي، واللغة المفضلة'
            : 'Manage platform settings, daily free quota, and language preferences'}
        </p>
      </div>

      {/* 1. Free Quota & Usage Policy */}
      <div className="glass-panel rounded-3xl p-6 border border-purple-500/20 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Flame className="w-5 h-5 text-amber-400" />
            <h2 className="text-base font-bold text-white">{t('quota.title')}</h2>
          </div>
          <button
            onClick={onRefreshQuota}
            className="text-xs font-semibold text-purple-300 hover:text-white px-3 py-1 rounded-lg bg-purple-950/60 border border-purple-500/30"
          >
            {language === 'ar' ? 'تحديث الرصيد' : 'Refresh Quota'}
          </button>
        </div>

        <div className="p-4 rounded-2xl bg-slate-950/80 border border-purple-500/20 space-y-3">
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-300">{language === 'ar' ? 'الفيديوهات المستخدمة اليوم:' : 'Videos Used Today:'}</span>
            <span className="font-mono font-bold text-purple-300 text-sm">
              {quota ? `${quota.usedToday || 0} من 30` : '0 من 30'}
            </span>
          </div>

          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-300">{language === 'ar' ? 'الفيديوهات المتبقية اليوم:' : 'Remaining Videos Today:'}</span>
            <span className="font-mono font-bold text-cyan-300 text-sm">
              {quota ? `${quota.remaining} / 30` : '30 / 30'}
            </span>
          </div>

          <div className="w-full bg-slate-900 rounded-full h-2 overflow-hidden border border-purple-500/30">
            <div
              className="bg-waled-gradient h-full rounded-full transition-all duration-300"
              style={{
                width: `${quota ? ((quota.usedToday || 0) / 30) * 100 : 0}%`,
              }}
            />
          </div>

          {quota && quota.resetInSeconds > 0 && (
            <div className="flex items-center justify-between text-xs text-amber-300/90 pt-1">
              <span className="flex items-center gap-1">
                <Clock className="w-3.5 h-3.5" />
                {language === 'ar' ? 'موعد إعادة التعيين (UTC):' : 'Reset In (UTC):'}
              </span>
              <span className="font-mono font-bold">{formatResetTime(quota.resetInSeconds)}</span>
            </div>
          )}

          <div className="text-[11px] text-slate-400 space-y-1 pt-2 border-t border-slate-800">
            <p className="flex items-center gap-1.5 text-emerald-400">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>{language === 'ar' ? 'حتى 30 فيديو عالي الجودة يومياً' : 'Up to 30 high-quality videos daily'}</span>
            </p>
            <p>
              {language === 'ar'
                ? '• سياسة الاستخدام: يحق لكل مستخدم إنشاء ما يصل إلى 30 فيديو يومياً. تتم إعادة تعيين العداد يومياً في تمام منتصف الليل بتوقيت UTC.'
                : '• Usage Policy: Each user is allocated up to 30 video generations per day. Counter resets daily at midnight UTC.'}
            </p>
          </div>
        </div>
      </div>

      {/* 2. Language & Interface Preferences */}
      <div className="glass-panel rounded-3xl p-6 border border-purple-500/20 space-y-4">
        <div className="flex items-center gap-2">
          <Globe className="w-5 h-5 text-cyan-400" />
          <h2 className="text-base font-bold text-white">
            {language === 'ar' ? 'اللغة والاتجاه' : 'Language & Layout Direction'}
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <button
            onClick={() => setLanguage('ar')}
            className={`p-4 rounded-2xl border text-right transition cursor-pointer ${
              language === 'ar'
                ? 'bg-purple-950/70 border-purple-400 shadow-md ring-2 ring-purple-500/20'
                : 'bg-slate-950/60 border-slate-800 hover:bg-slate-900'
            }`}
          >
            <p className="text-sm font-bold text-white">العربية (الافتراضية)</p>
            <p className="text-xs text-purple-300/80 mt-1">تنسيق RTL مع خط تجوال العربي الاحترافي</p>
          </button>

          <button
            onClick={() => setLanguage('en')}
            className={`p-4 rounded-2xl border text-left transition cursor-pointer ${
              language === 'en'
                ? 'bg-purple-950/70 border-purple-400 shadow-md ring-2 ring-purple-500/20'
                : 'bg-slate-950/60 border-slate-800 hover:bg-slate-900'
            }`}
          >
            <p className="text-sm font-bold text-white">English (LTR)</p>
            <p className="text-xs text-purple-300/80 mt-1">Left-to-Right layout with Plus Jakarta Sans</p>
          </button>
        </div>
      </div>

      {/* Privacy & Support */}
      <div className="glass-panel rounded-3xl p-6 border border-purple-500/20 space-y-3">
        <h2 className="text-base font-bold text-white">
          {language === 'ar' ? 'الخصوصية والدعم' : 'Privacy & Support'}
        </h2>
        <a href="/privacy-policy.html" target="_blank" rel="noopener noreferrer"
          className="block p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-sm text-purple-300 hover:bg-slate-900">
          {language === 'ar' ? 'سياسة الخصوصية' : 'Privacy Policy'}
        </a>
        <a href="mailto:waleedmmh789@gmail.com"
          className="block p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-sm text-purple-300 hover:bg-slate-900">
          {language === 'ar' ? 'الدعم الفني: ' : 'Support: '}waleedmmh789@gmail.com
        </a>
      </div>

      {/* 3. System Architecture & Diagnostics */}
      <div className="glass-panel rounded-3xl p-6 border border-purple-500/20 space-y-4">
        <div className="flex items-center gap-2">
          <Cpu className="w-5 h-5 text-purple-400" />
          <h2 className="text-base font-bold text-white">
            {language === 'ar' ? 'تشخيص وبنية المنصة (Architecture)' : 'Architecture & Engine Status'}
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
            <span className="text-slate-300">FFmpeg Video Processor:</span>
            <span className="text-emerald-400 font-bold flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              /usr/bin/ffmpeg (Active)
            </span>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
            <span className="text-slate-300">2D Animation Engine:</span>
            <span className="text-emerald-400 font-bold flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              Canvas 60FPS (Active)
            </span>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
            <span className="text-slate-300">Web Audio Synthesizer:</span>
            <span className="text-emerald-400 font-bold flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              Harmonic Engine (Active)
            </span>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
            <span className="text-slate-300">Database & Quota Store:</span>
            <span className="text-emerald-400 font-bold flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              Atomic JSON / SQL (Active)
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
