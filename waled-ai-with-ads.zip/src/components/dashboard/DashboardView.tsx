import React, { useState } from 'react';
import { useLocalization } from '../../lib/localization';
import { Project, QuotaStatus, CharacterId, CharacterAction } from '../../types';
import { CHARACTER_CATALOG } from '../../lib/animation/characters';
import { CharacterCanvas } from '../studio/CharacterCanvas';
import {
  Video,
  Sparkles,
  Play,
  Edit3,
  Trash2,
  Download,
  Clock,
  Layers,
  ArrowRight,
  ArrowLeft,
  Flame,
  CheckCircle2,
} from 'lucide-react';

interface DashboardViewProps {
  projects: Project[];
  quota: QuotaStatus | null;
  onNavigate: (view: string) => void;
  onOpenProject: (projectId: string) => void;
  onDeleteProject: (projectId: string) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  projects,
  quota,
  onNavigate,
  onOpenProject,
  onDeleteProject,
}) => {
  const { language, t, isRTL } = useLocalization();

  const [selectedShowcaseChar, setSelectedShowcaseChar] = useState<CharacterId>('bader_rabbit');
  const [showcaseAction, setShowcaseAction] = useState<CharacterAction>('walk');

  const currentCharDef = CHARACTER_CATALOG.find((c) => c.id === selectedShowcaseChar) || CHARACTER_CATALOG[0];

  const actionsList: { id: CharacterAction; labelEn: string; labelAr: string }[] = [
    { id: 'walk', labelEn: 'Walk', labelAr: 'مشي' },
    { id: 'run', labelEn: 'Run', labelAr: 'ركض' },
    { id: 'jump', labelEn: 'Jump', labelAr: 'قفز' },
    { id: 'wave', labelEn: 'Wave', labelAr: 'تحية' },
    { id: 'talk', labelEn: 'Talk', labelAr: 'تحدث' },
    { id: 'laugh', labelEn: 'Laugh', labelAr: 'ضحك' },
    { id: 'celebrate', labelEn: 'Celebrate', labelAr: 'احتفال' },
  ];

  return (
    <div className="space-y-8 pb-12">
      {/* Hero Welcome Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-purple-900/60 via-indigo-950/50 to-slate-900/80 border border-purple-500/30 p-6 md:p-10 shadow-2xl backdrop-blur-xl">
        <div className="absolute -right-16 -top-16 w-64 h-64 bg-purple-600/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -left-16 -bottom-16 w-64 h-64 bg-cyan-600/20 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 max-w-2xl space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-500/20 border border-purple-500/30 text-purple-300 text-xs font-semibold">
            <Sparkles className="w-3.5 h-3.5 text-cyan-300" />
            <span>{language === 'ar' ? 'الجيل الجديد من استوديوهات الرسوم المتحركة' : 'Next-Gen 2D Animation Engine'}</span>
          </div>

          <h1 className="text-3xl md:text-5xl font-extrabold tracking-tight text-white leading-tight">
            {t('dashboard.welcome')}
          </h1>

          <p className="text-slate-300 text-sm md:text-base leading-relaxed">
            {t('dashboard.subtitle')}
          </p>

          <div className="flex flex-wrap items-center gap-3 pt-2">
            <button
              onClick={() => onNavigate('create')}
              className="px-6 py-3.5 rounded-2xl bg-waled-gradient hover:opacity-95 text-white font-bold text-sm shadow-xl shadow-purple-600/30 flex items-center gap-2.5 transition transform hover:-translate-y-0.5 cursor-pointer"
            >
              <Video className="w-4 h-4" />
              <span>{t('dashboard.cta_create')}</span>
              {isRTL ? <ArrowLeft className="w-4 h-4" /> : <ArrowRight className="w-4 h-4" />}
            </button>

            <button
              onClick={() => onNavigate('studio')}
              className="px-6 py-3.5 rounded-2xl glass-panel-elevated hover:bg-slate-800/80 text-purple-200 hover:text-white font-semibold text-sm transition flex items-center gap-2 border border-purple-500/30 cursor-pointer"
            >
              <Sparkles className="w-4 h-4 text-cyan-400" />
              <span>{t('dashboard.open_studio')}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Quick Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="glass-panel p-4 md:p-5 rounded-2xl border border-purple-500/20 space-y-1">
          <span className="text-xs font-medium text-slate-400 flex items-center gap-1.5">
            <Layers className="w-4 h-4 text-purple-400" />
            {t('dashboard.quick_stats.total_projects')}
          </span>
          <p className="text-2xl md:text-3xl font-extrabold text-white">{projects.length}</p>
        </div>

        <div className="glass-panel p-4 md:p-5 rounded-2xl border border-purple-500/20 space-y-1">
          <span className="text-xs font-medium text-slate-400 flex items-center gap-1.5">
            <Video className="w-4 h-4 text-cyan-400" />
            {t('dashboard.quick_stats.rendered_videos')}
          </span>
          <p className="text-2xl md:text-3xl font-extrabold text-white">
            {projects.filter((p) => p.status === 'completed').length}
          </p>
        </div>

        <div className="glass-panel p-4 md:p-5 rounded-2xl border border-purple-500/20 space-y-1">
          <span className="text-xs font-medium text-slate-400 flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-amber-400" />
            {t('dashboard.quick_stats.active_characters')}
          </span>
          <p className="text-2xl md:text-3xl font-extrabold text-white">{CHARACTER_CATALOG.length}</p>
        </div>

        <div className="glass-panel p-4 md:p-5 rounded-2xl border border-purple-500/20 space-y-1">
          <span className="text-xs font-medium text-slate-400 flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-cyan-400" />
            {language === 'ar' ? 'الفيديوهات المتبقية اليوم' : 'Remaining Today'}
          </span>
          <div className="flex items-baseline gap-2">
            <p className="text-xl md:text-2xl font-extrabold text-cyan-300">
              {quota ? `${quota.remaining} / 30` : '30 / 30'}
            </p>
          </div>
        </div>
      </div>

      {/* Interactive Cast Showcase (Mode A Preview) */}
      <div className="glass-panel rounded-3xl p-6 md:p-8 border border-purple-500/20 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-xl md:text-2xl font-bold text-white flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-cyan-400" />
              <span>{language === 'ar' ? 'شخصيات استوديو الرسوم المتحركة' : 'Cartoon Character Studio'}</span>
            </h2>
            <p className="text-xs md:text-sm text-slate-400">
              {language === 'ar'
                ? 'نماذج متجهة حقيقية قابلة للتحريك الكامل مع المحافظة على الهوية البصرية عبر جميع المشاهد'
                : 'True vector rigs with consistent identities and reusable skeletal keyframe motion across scenes'}
            </p>
          </div>

          <button
            onClick={() => onNavigate('studio')}
            className="self-start sm:self-auto text-xs font-bold text-purple-300 hover:text-white flex items-center gap-1 px-3 py-1.5 rounded-xl bg-purple-950/40 border border-purple-500/30 transition"
          >
            <span>{language === 'ar' ? 'فتح استوديو التحريك المتقدم' : 'Open Full Animation Rig'}</span>
            {isRTL ? <ArrowLeft className="w-3.5 h-3.5" /> : <ArrowRight className="w-3.5 h-3.5" />}
          </button>
        </div>

        {/* Character Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
          {CHARACTER_CATALOG.map((char) => {
            const isSelected = selectedShowcaseChar === char.id;
            return (
              <button
                key={char.id}
                onClick={() => setSelectedShowcaseChar(char.id)}
                className={`px-4 py-2.5 rounded-2xl text-xs font-bold whitespace-nowrap transition cursor-pointer flex items-center gap-2 border ${
                  isSelected
                    ? 'bg-waled-gradient text-white border-transparent shadow-lg shadow-purple-600/30'
                    : 'bg-slate-900/60 text-slate-300 border-purple-500/20 hover:bg-slate-800'
                }`}
              >
                <span>{language === 'ar' ? char.nameAr : char.nameEn}</span>
              </button>
            );
          })}
        </div>

        {/* Live Canvas Stage & Action Controls */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center bg-slate-950/60 rounded-2xl p-4 md:p-6 border border-purple-500/10">
          <div className="md:col-span-5 flex justify-center">
            <div className="relative rounded-2xl overflow-hidden border border-purple-500/30 shadow-2xl bg-gradient-to-b from-slate-900 to-slate-950">
              <CharacterCanvas
                characterId={selectedShowcaseChar}
                action={showcaseAction}
                expression="happy"
                width={280}
                height={280}
                scale={1.25}
              />
              <div className="absolute bottom-2 left-2 right-2 text-center text-[11px] font-mono font-bold text-cyan-300 bg-slate-950/80 px-2 py-1 rounded-lg backdrop-blur-sm border border-purple-500/20">
                {language === 'ar' ? currentCharDef.nameAr : currentCharDef.nameEn} • {showcaseAction}
              </div>
            </div>
          </div>

          <div className="md:col-span-7 space-y-4">
            <div>
              <h3 className="text-lg font-bold text-white">
                {language === 'ar' ? currentCharDef.nameAr : currentCharDef.nameEn}
              </h3>
              <p className="text-xs text-slate-300 mt-1">
                {language === 'ar' ? currentCharDef.descriptionAr : currentCharDef.descriptionEn}
              </p>
            </div>

            <div>
              <p className="text-xs font-semibold text-purple-300 mb-2">
                {language === 'ar' ? 'اختر حركة لتجربتها مباشرة:' : 'Select an Action to Test Live:'}
              </p>
              <div className="flex flex-wrap gap-2">
                {actionsList.map((act) => (
                  <button
                    key={act.id}
                    onClick={() => setShowcaseAction(act.id)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition border cursor-pointer ${
                      showcaseAction === act.id
                        ? 'bg-purple-600 text-white border-purple-400 shadow-sm'
                        : 'bg-slate-900 text-slate-300 border-slate-700 hover:bg-slate-800'
                    }`}
                  >
                    {language === 'ar' ? act.labelAr : act.labelEn}
                  </button>
                ))}
              </div>
            </div>

            <div className="pt-2 flex items-center gap-3">
              <button
                onClick={() => onNavigate('create')}
                className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs flex items-center gap-2 transition"
              >
                <Video className="w-3.5 h-3.5" />
                <span>{language === 'ar' ? 'إنشاء قصة بهذه الشخصية' : 'Create Video with this Character'}</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Projects Section */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-bold text-white">{t('dashboard.recent_projects')}</h2>
            <p className="text-xs text-slate-400">
              {language === 'ar' ? 'مشاريعك المحفوظة القابلة للتعديل وإعادة التصدير دون استهلاك رصيد إضافي' : 'Saved projects can be reopened and re-downloaded anytime without consuming quota'}
            </p>
          </div>
          {projects.length > 0 && (
            <button
              onClick={() => onNavigate('projects')}
              className="text-xs font-bold text-purple-300 hover:text-white flex items-center gap-1"
            >
              <span>{language === 'ar' ? 'عرض الكل' : 'View All'}</span>
              {isRTL ? <ArrowLeft className="w-3.5 h-3.5" /> : <ArrowRight className="w-3.5 h-3.5" />}
            </button>
          )}
        </div>

        {projects.length === 0 ? (
          <div className="glass-panel rounded-3xl p-10 text-center space-y-4 border border-purple-500/20">
            <div className="w-14 h-14 rounded-2xl bg-purple-950/60 border border-purple-500/30 flex items-center justify-center mx-auto text-purple-400">
              <Video className="w-7 h-7" />
            </div>
            <div>
              <p className="text-base font-bold text-white">{t('dashboard.no_projects')}</p>
              <p className="text-xs text-slate-400 mt-1 max-w-md mx-auto">
                {language === 'ar'
                  ? 'اكتب فكرة سريعة أو قصة قصيرة لتحويلها إلى سيناريو متحرك مع أصوات وشخصيات وموسيقى تصويرية.'
                  : 'Enter a creative prompt or story to turn it into an animated video with voiceover and sound FX.'}
              </p>
            </div>
            <button
              onClick={() => onNavigate('create')}
              className="px-5 py-2.5 rounded-xl bg-waled-gradient hover:opacity-95 text-white font-bold text-xs shadow-md shadow-purple-600/30 inline-flex items-center gap-2 transition"
            >
              <Video className="w-4 h-4" />
              <span>{t('dashboard.cta_create')}</span>
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {projects.slice(0, 6).map((proj) => {
              const firstChar = proj.scenes[0]?.characters[0]?.characterId || 'bader_rabbit';
              return (
                <div
                  key={proj.id}
                  className="glass-panel rounded-2xl overflow-hidden border border-purple-500/20 hover:border-purple-500/40 transition group flex flex-col justify-between"
                >
                  <div className="p-4 space-y-3">
                    {/* Visual Card Header */}
                    <div className="relative h-36 rounded-xl overflow-hidden bg-slate-900 border border-purple-500/20 flex items-center justify-center">
                      <CharacterCanvas
                        characterId={firstChar}
                        action="idle"
                        expression="happy"
                        backgroundId={proj.scenes[0]?.backgroundId || 'enchanted_forest'}
                        width={280}
                        height={144}
                        scale={0.8}
                      />
                      <div className="absolute top-2 left-2 px-2 py-0.5 rounded-md text-[10px] font-mono font-bold bg-slate-950/80 text-cyan-300 border border-purple-500/30 backdrop-blur-sm">
                        {proj.aspectRatio} • {proj.duration}s
                      </div>
                      <div className="absolute top-2 right-2 px-2 py-0.5 rounded-md text-[10px] font-bold bg-purple-950/80 text-purple-200 border border-purple-500/30 backdrop-blur-sm">
                        {proj.language === 'ar' ? 'عربي' : 'English'}
                      </div>
                    </div>

                    <div>
                      <h3 className="text-sm font-bold text-white line-clamp-1 group-hover:text-purple-300 transition">
                        {proj.title}
                      </h3>
                      <p className="text-xs text-slate-400 line-clamp-2 mt-1">
                        {proj.description || (proj.scenes[0]?.narration ?? '')}
                      </p>
                    </div>

                    <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1 border-t border-purple-500/10">
                      <span>{proj.scenes.length} {language === 'ar' ? 'مشاهد' : 'scenes'}</span>
                      <span className="flex items-center gap-1 text-emerald-400">
                        <CheckCircle2 className="w-3 h-3" />
                        {language === 'ar' ? 'جاهز' : 'Ready'}
                      </span>
                    </div>
                  </div>

                  {/* Actions Footer */}
                  <div className="px-4 py-3 bg-slate-950/60 border-t border-purple-500/20 flex items-center justify-between gap-2">
                    <button
                      onClick={() => onOpenProject(proj.id)}
                      className="px-3 py-1.5 rounded-xl bg-purple-600/80 hover:bg-purple-600 text-white font-semibold text-xs flex items-center gap-1.5 transition flex-1 justify-center"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                      <span>{language === 'ar' ? 'تعديل المشروع' : 'Edit Project'}</span>
                    </button>
                    <button
                      onClick={() => onDeleteProject(proj.id)}
                      className="p-1.5 rounded-xl text-slate-400 hover:text-rose-400 hover:bg-rose-950/30 transition"
                      title={t('common.delete')}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
