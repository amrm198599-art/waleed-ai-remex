import React, { useState } from 'react';
import { useLocalization } from '../../lib/localization';
import {
  Project,
  Scene,
  VideoAspectRatio,
  VideoLanguage,
  VideoStyle,
  CharacterId,
  BackgroundId,
  CharacterAction,
  MusicTrackType,
  QuotaStatus,
} from '../../types';
import { CHARACTER_CATALOG } from '../../lib/animation/characters';
import { BACKGROUND_CATALOG } from '../../lib/animation/backgrounds';
import { CharacterCanvas } from '../studio/CharacterCanvas';
import { audioEngine } from '../../lib/audio/engine';
import { VideoRenderingPipeline, RenderProgressUpdate } from '../../lib/rendering/pipeline';
import { VideoExportCard } from '../exports/VideoExportCard';
import {
  Sparkles,
  Video,
  Layers,
  Volume2,
  Play,
  ArrowRight,
  ArrowLeft,
  Check,
  Plus,
  Trash2,
  Copy,
  Clock,
  Film,
  Download,
  Share2,
  RefreshCw,
  AlertTriangle,
  Flame,
  Wand2,
} from 'lucide-react';

interface CreateWorkflowProps {
  quota: QuotaStatus | null;
  onProjectCreated: (project: Project) => void;
  onOpenEditor: (projectId: string) => void;
  onRefreshQuota: () => void;
}

export const CreateWorkflow: React.FC<CreateWorkflowProps> = ({
  quota,
  onProjectCreated,
  onOpenEditor,
  onRefreshQuota,
}) => {
  const { language, t, isRTL } = useLocalization();

  // Wizard Step (1 to 5)
  const [currentStep, setCurrentStep] = useState<number>(1);

  // Step 1: Idea & Settings
  const [prompt, setPrompt] = useState<string>(
    language === 'ar'
      ? 'اصنع كرتوناً كوميدياً مدته 15 ثانية عن أرنب ودب يتقاسمان موزة في غابة ساحرة'
      : 'Create a funny 15-second cartoon about a rabbit and a bear sharing a banana in a magical forest'
  );
  const [title, setTitle] = useState<string>(
    language === 'ar' ? 'مغامرة الأرنب والدب في الغابة' : 'The Rabbit and Bear Forest Adventure'
  );
  const [targetLang, setTargetLang] = useState<VideoLanguage>(language);
  const [videoStyle, setVideoStyle] = useState<VideoStyle>('cartoon');
  const [durationSeconds, setDurationSeconds] = useState<number>(15);
  const [aspectRatio, setAspectRatio] = useState<VideoAspectRatio>('16:9');
  const [audience, setAudience] = useState<string>('kids');

  // Step 2 & 3: Script & Storyboard Scenes
  const [isGeneratingScript, setIsGeneratingScript] = useState<boolean>(false);
  const [scenes, setScenes] = useState<Scene[]>([]);

  // Step 4: Audio preferences
  const [selectedMusic, setSelectedMusic] = useState<MusicTrackType>('playful_adventure');

  // Step 5: Rendering State
  const [isRendering, setIsRendering] = useState<boolean>(false);
  const [renderProgress, setRenderProgress] = useState<RenderProgressUpdate | null>(null);
  const [renderedVideoUrl, setRenderedVideoUrl] = useState<string | null>(null);
  const [savedProjectId, setSavedProjectId] = useState<string | null>(null);
  const [renderError, setRenderError] = useState<string | null>(null);

  // ---------------------------------------------------------------------------
  // STEP 1 -> STEP 2: GENERATE SCRIPT
  // ---------------------------------------------------------------------------
  const handleGenerateScript = async () => {
    if (!prompt.trim()) return;
    setIsGeneratingScript(true);
    setRenderError(null);

    try {
      const res = await fetch('/api/generate/script', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt,
          language: targetLang,
          aspectRatio,
          durationSeconds,
          targetAudience: audience,
          videoStyle,
        }),
      });

      if (!res.ok) {
        throw new Error(`Script generation failed with status ${res.status}`);
      }

      const data = await res.json();
      if (data.title) setTitle(data.title);
      if (data.scenes && data.scenes.length > 0) {
        setScenes(data.scenes);
        setCurrentStep(2);
      }
    } catch (err: any) {
      console.error('Error generating script:', err);
      setRenderError(err.message || 'Failed to generate script');
    } finally {
      setIsGeneratingScript(false);
    }
  };

  // ---------------------------------------------------------------------------
  // STORYBOARD MANAGEMENT
  // ---------------------------------------------------------------------------
  const handleUpdateScene = (idx: number, updates: Partial<Scene>) => {
    setScenes((prev) => {
      const copy = [...prev];
      copy[idx] = { ...copy[idx], ...updates };
      return copy;
    });
  };

  const handleDuplicateScene = (idx: number) => {
    setScenes((prev) => {
      const target = prev[idx];
      const newScene: Scene = {
        ...JSON.parse(JSON.stringify(target)),
        id: `scene_${Date.now()}`,
        order: prev.length,
      };
      return [...prev.slice(0, idx + 1), newScene, ...prev.slice(idx + 1)].map((s, i) => ({
        ...s,
        order: i,
      }));
    });
  };

  const handleDeleteScene = (idx: number) => {
    if (scenes.length <= 1) return;
    setScenes((prev) => prev.filter((_, i) => i !== idx).map((s, i) => ({ ...s, order: i })));
  };

  const handleAddScene = () => {
    const newScene: Scene = {
      id: `scene_${Date.now()}`,
      order: scenes.length,
      duration: 5,
      narration: language === 'ar' ? 'مشهد جديد ينضم إلى القصة...' : 'A new scene unfolds...',
      dialogue: [
        {
          id: `diag_${Date.now()}`,
          characterId: 'bader_rabbit',
          speakerName: language === 'ar' ? 'الأرنب بدر' : 'Bader',
          text: language === 'ar' ? 'مرحباً بالجميع في هذه المغامرة!' : 'Hello everyone in this adventure!',
          expression: 'happy',
        },
      ],
      characters: [
        {
          characterId: 'bader_rabbit',
          action: 'wave',
          x: 40,
          y: 82,
          scale: 1.1,
          flipX: false,
          zIndex: 1,
        },
      ],
      backgroundId: 'enchanted_forest',
      camera: 'static',
      transition: 'fade',
      sfx: 'pop',
      musicTrack: selectedMusic,
      subtitlesEnabled: true,
    };
    setScenes((prev) => [...prev, newScene]);
  };

  // ---------------------------------------------------------------------------
  // STEP 5: ATOMIC QUOTA RESERVATION & REAL VIDEO RENDERING
  // ---------------------------------------------------------------------------
  const handleStartRender = async () => {
    setRenderError(null);
    setIsRendering(true);

    try {
      // 1. Create/Save project first
      const saveRes = await fetch('/api/projects', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title,
          description: prompt,
          language: targetLang,
          aspectRatio,
          videoStyle,
          duration: scenes.reduce((acc, s) => acc + (s.duration || 5), 0),
          scenes,
        }),
      });

      if (!saveRes.ok) throw new Error('Failed to create project record');
      const savedProj = await saveRes.json();
      setSavedProjectId(savedProj.id);
      onProjectCreated(savedProj);

      // 2. Atomically reserve quota slot
      const jobRes = await fetch('/api/jobs/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          projectId: savedProj.id,
          idempotencyKey: `render_${savedProj.id}_${Date.now()}`,
        }),
      });

      if (!jobRes.ok) {
        const errorData = await jobRes.json();
        if (jobRes.status === 429) {
          throw new Error(
            errorData.message ||
              (language === 'ar'
                ? 'هناك عملية تصيير فيديو جارية حالياً. يرجى الانتظار حتى اكتمالها.'
                : 'A video generation job is already in progress. Please wait for it to complete.')
          );
        }
        throw new Error(errorData.error || 'Failed to initialize video render');
      }

      onRefreshQuota();

      // 3. Launch Real Video Rendering Pipeline (Canvas + Web Audio + MediaRecorder + Server FFmpeg MP4)
      const pipeline = new VideoRenderingPipeline();
      const result = await pipeline.renderVideo(
        scenes,
        aspectRatio,
        targetLang,
        (progressUpdate) => {
          setRenderProgress(progressUpdate);
        },
        savedProj.id
      );

      setRenderedVideoUrl(result.videoUrl);

      // Update project with final URLs
      await fetch(`/api/projects/${savedProj.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          status: 'completed',
          renderedVideoUrl: result.videoUrl,
          streamUrl: result.streamUrl,
          downloadUrl: result.downloadUrl,
        }),
      });
    } catch (err: any) {
      console.error('Rendering error:', err);
      setRenderError(err.message || 'Video rendering failed');
    } finally {
      setIsRendering(false);
      onRefreshQuota();
    }
  };

  const totalCalculatedDuration = scenes.reduce((acc, s) => acc + (s.duration || 5), 0);

  return (
    <div className="max-w-5xl mx-auto space-y-8 pb-16">
      {/* Stepper Header */}
      <div className="glass-panel rounded-3xl p-4 md:p-6 border border-purple-500/20">
        <div className="flex items-center justify-between">
          {[1, 2, 3, 4, 5].map((step) => {
            const isCompleted = step < currentStep;
            const isCurrent = step === currentStep;
            return (
              <div key={step} className="flex items-center flex-1 last:flex-none">
                <button
                  onClick={() => {
                    if (scenes.length > 0 && step <= 4) setCurrentStep(step);
                  }}
                  disabled={scenes.length === 0 && step > 1}
                  className={`w-9 h-9 md:w-11 md:h-11 rounded-2xl flex items-center justify-center font-bold text-xs md:text-sm transition cursor-pointer ${
                    isCompleted
                      ? 'bg-emerald-500 text-white shadow-lg shadow-emerald-500/30'
                      : isCurrent
                      ? 'bg-waled-gradient text-white shadow-lg shadow-purple-600/40 ring-4 ring-purple-500/20'
                      : 'bg-slate-900 text-slate-500 border border-slate-800'
                  }`}
                >
                  {isCompleted ? <Check className="w-4 h-4 md:w-5 md:h-5" /> : step}
                </button>
                {step < 5 && (
                  <div
                    className={`flex-1 h-1 mx-2 rounded-full transition-colors ${
                      step < currentStep ? 'bg-emerald-500' : 'bg-slate-800'
                    }`}
                  />
                )}
              </div>
            );
          })}
        </div>

        <div className="mt-4 text-center">
          <h2 className="text-lg md:text-xl font-extrabold text-white">
            {t(`create.step${currentStep}_title`)}
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            {t(`create.step${currentStep}_desc`)}
          </p>
        </div>
      </div>

      {/* Active in-flight render notice if concurrency limit reached */}
      {quota && quota.activeJobs >= quota.maxConcurrentJobs && currentStep === 1 && (
        <div className="p-4 rounded-2xl bg-indigo-950/40 border border-purple-500/30 flex items-start gap-3 text-purple-200 text-xs">
          <Clock className="w-5 h-5 text-cyan-400 flex-shrink-0 mt-0.5" />
          <div className="space-y-1">
            <p className="font-bold">
              {language === 'ar' ? 'هناك معالجة فيديو قيد التنفيذ حالياً' : 'A video render is currently processing'}
            </p>
            <p className="text-purple-300/80">
              {language === 'ar'
                ? 'يمكنك متابعة تحضير السيناريو الحالي، وسيبدأ التصيير بمجرد اكتمال العملية الجارية.'
                : 'You can continue setting up this storyboard. Rendering will proceed as soon as the active job completes.'}
            </p>
          </div>
        </div>
      )}

      {/* STEP 1: IDEA & PREFERENCES */}
      {currentStep === 1 && (
        <div className="glass-panel rounded-3xl p-6 md:p-8 border border-purple-500/20 space-y-6">
          {/* Prompt Editor */}
          <div className="space-y-2">
            <label className="block text-sm font-bold text-white flex items-center justify-between">
              <span className="flex items-center gap-2">
                <Wand2 className="w-4 h-4 text-purple-400" />
                {t('create.prompt_label')}
              </span>
              <span className="text-[11px] text-purple-300 font-normal">
                {language === 'ar' ? 'محرك السيناريو الذكي' : 'AI Screenplay Writer'}
              </span>
            </label>
            <textarea
              rows={4}
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder={t('create.prompt_placeholder')}
              className="w-full bg-slate-950/80 border border-purple-500/30 rounded-2xl p-4 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-purple-400 focus:ring-2 focus:ring-purple-500/20 transition resize-none"
            />
          </div>

          {/* Title & Language */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="block text-xs font-bold text-slate-300">
                {t('create.video_title')}
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder={t('create.video_title_placeholder')}
                className="w-full bg-slate-950/80 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-purple-400 transition"
              />
            </div>

            <div className="space-y-2">
              <label className="block text-xs font-bold text-slate-300">
                {t('create.target_language')}
              </label>
              <select
                value={targetLang}
                onChange={(e) => setTargetLang(e.target.value as VideoLanguage)}
                className="w-full bg-slate-950/80 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-purple-400 transition cursor-pointer"
              >
                <option value="ar">{language === 'ar' ? 'العربية (حوار وصوت عربي)' : 'Arabic (Arabic dialogue & voice)'}</option>
                <option value="en">{language === 'ar' ? 'الإنجليزية (حوار وصوت إنجليزي)' : 'English (English dialogue & voice)'}</option>
              </select>
            </div>
          </div>

          {/* Duration, Aspect Ratio, Video Style */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <label className="block text-xs font-bold text-slate-300">
                {t('create.duration')}
              </label>
              <div className="grid grid-cols-3 gap-2">
                {[15, 30, 60].map((dur) => (
                  <button
                    key={dur}
                    type="button"
                    onClick={() => setDurationSeconds(dur)}
                    className={`py-2 rounded-xl text-xs font-bold transition border cursor-pointer ${
                      durationSeconds === dur
                        ? 'bg-purple-600 text-white border-purple-400'
                        : 'bg-slate-900 text-slate-300 border-slate-800 hover:bg-slate-800'
                    }`}
                  >
                    {dur} {t('common.seconds')}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <label className="block text-xs font-bold text-slate-300">
                {t('create.aspect_ratio')}
              </label>
              <div className="grid grid-cols-3 gap-2">
                {(['16:9', '9:16', '1:1'] as VideoAspectRatio[]).map((ratio) => (
                  <button
                    key={ratio}
                    type="button"
                    onClick={() => setAspectRatio(ratio)}
                    className={`py-2 rounded-xl text-xs font-bold transition border cursor-pointer ${
                      aspectRatio === ratio
                        ? 'bg-purple-600 text-white border-purple-400'
                        : 'bg-slate-900 text-slate-300 border-slate-800 hover:bg-slate-800'
                    }`}
                  >
                    {ratio}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <label className="block text-xs font-bold text-slate-300">
                {t('create.audience')}
              </label>
              <select
                value={audience}
                onChange={(e) => setAudience(e.target.value)}
                className="w-full bg-slate-950/80 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-purple-400 transition cursor-pointer"
              >
                <option value="kids">{t('create.audience_kids')}</option>
                <option value="general">{t('create.audience_general')}</option>
                <option value="social">{t('create.audience_social')}</option>
              </select>
            </div>
          </div>

          {/* Generate Button */}
          <div className="pt-4 flex items-center justify-between">
            <span className="text-[11px] text-purple-300/70">
              {t('create.offline_notice')}
            </span>

            <button
              onClick={handleGenerateScript}
              disabled={isGeneratingScript || !prompt.trim()}
              className="px-6 py-3.5 rounded-2xl bg-waled-gradient hover:opacity-95 disabled:opacity-50 text-white font-bold text-sm shadow-xl shadow-purple-600/30 flex items-center gap-2 transition cursor-pointer"
            >
              {isGeneratingScript ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>{t('create.generating_script')}</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-cyan-300" />
                  <span>{t('create.btn_generate_script')}</span>
                  {isRTL ? <ArrowLeft className="w-4 h-4" /> : <ArrowRight className="w-4 h-4" />}
                </>
              )}
            </button>
          </div>
        </div>
      )}

      {/* STEP 2: SCRIPT REVIEW */}
      {currentStep === 2 && (
        <div className="glass-panel rounded-3xl p-6 md:p-8 border border-purple-500/20 space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-xl font-bold text-white">{title}</h3>
              <p className="text-xs text-slate-400">
                {scenes.length} {language === 'ar' ? 'مشاهد هيكلية مكتملة' : 'structured scenes generated'} ({totalCalculatedDuration}s total)
              </p>
            </div>
            <button
              onClick={handleAddScene}
              className="px-3 py-1.5 rounded-xl bg-purple-950/60 border border-purple-500/30 text-purple-300 hover:text-white text-xs font-semibold flex items-center gap-1.5 transition"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{t('editor.add_scene')}</span>
            </button>
          </div>

          {/* Scene Cards */}
          <div className="space-y-4">
            {scenes.map((scene, idx) => (
              <div
                key={scene.id}
                className="p-4 rounded-2xl bg-slate-950/70 border border-purple-500/20 space-y-3"
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-purple-300">
                    {t('editor.scene_number', { num: idx + 1 })}
                  </span>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-slate-400">{scene.duration}s</span>
                    <button
                      onClick={() => handleDuplicateScene(idx)}
                      className="p-1 text-slate-400 hover:text-purple-300 transition"
                      title={t('editor.duplicate_scene')}
                    >
                      <Copy className="w-3.5 h-3.5" />
                    </button>
                    {scenes.length > 1 && (
                      <button
                        onClick={() => handleDeleteScene(idx)}
                        className="p-1 text-slate-400 hover:text-rose-400 transition"
                        title={t('editor.delete_scene')}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="block text-[11px] font-semibold text-slate-400">
                    {t('editor.narration')}
                  </label>
                  <textarea
                    rows={2}
                    value={scene.narration}
                    onChange={(e) => handleUpdateScene(idx, { narration: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-purple-400 resize-none"
                  />
                </div>

                {scene.dialogue && scene.dialogue.length > 0 && (
                  <div className="space-y-2">
                    <label className="block text-[11px] font-semibold text-slate-400">
                      {t('editor.dialogue')} ({scene.dialogue[0].speakerName})
                    </label>
                    <input
                      type="text"
                      value={scene.dialogue[0].text}
                      onChange={(e) => {
                        const diagCopy = [...scene.dialogue];
                        diagCopy[0] = { ...diagCopy[0], text: e.target.value };
                        handleUpdateScene(idx, { dialogue: diagCopy });
                      }}
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-purple-400"
                    />
                  </div>
                )}
              </div>
            ))}
          </div>

          <div className="flex items-center justify-between pt-4 border-t border-purple-500/20">
            <button
              onClick={() => setCurrentStep(1)}
              className="px-5 py-2.5 rounded-xl border border-slate-700 text-xs font-semibold text-slate-300 hover:text-white transition"
            >
              {t('common.back')}
            </button>
            <button
              onClick={() => setCurrentStep(3)}
              className="px-6 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs flex items-center gap-2 transition"
            >
              <span>{t('common.next')}: {t('create.step3_title')}</span>
              {isRTL ? <ArrowLeft className="w-3.5 h-3.5" /> : <ArrowRight className="w-3.5 h-3.5" />}
            </button>
          </div>
        </div>
      )}

      {/* STEP 3: STORYBOARD & CAST ASSIGNMENT */}
      {currentStep === 3 && (
        <div className="glass-panel rounded-3xl p-6 md:p-8 border border-purple-500/20 space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-xl font-bold text-white">{t('create.step3_title')}</h3>
              <p className="text-xs text-slate-400">
                {language === 'ar'
                  ? 'قم بتخصيص الشخصيات وحركاتها والخلفيات لكل مشهد مع الحفاظ التام على هوية الشخصية'
                  : 'Customize characters, poses, and backgrounds while ensuring visual consistency'}
              </p>
            </div>
            <button
              onClick={handleAddScene}
              className="px-3 py-1.5 rounded-xl bg-purple-950/60 border border-purple-500/30 text-purple-300 hover:text-white text-xs font-semibold flex items-center gap-1.5 transition"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{t('editor.add_scene')}</span>
            </button>
          </div>

          {/* Storyboard Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {scenes.map((scene, idx) => {
              const primaryChar = scene.characters[0]?.characterId || 'bader_rabbit';
              const primaryAction = scene.characters[0]?.action || 'idle';
              return (
                <div
                  key={scene.id}
                  className="rounded-2xl bg-slate-950/80 border border-purple-500/20 p-4 space-y-4"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-purple-300">
                      {t('editor.scene_number', { num: idx + 1 })}
                    </span>
                    <span className="text-[11px] font-mono text-cyan-300 bg-slate-900 px-2 py-0.5 rounded-md border border-slate-800">
                      {scene.duration}s
                    </span>
                  </div>

                  {/* Scene Preview Stage */}
                  <div className="relative h-44 rounded-xl overflow-hidden bg-slate-900 border border-purple-500/20 flex items-center justify-center">
                    <CharacterCanvas
                      characterId={primaryChar}
                      action={primaryAction}
                      expression={scene.dialogue?.[0]?.expression || 'happy'}
                      backgroundId={scene.backgroundId}
                      width={320}
                      height={176}
                      scale={0.9}
                    />
                  </div>

                  {/* Character Selector */}
                  <div className="space-y-1">
                    <label className="block text-[11px] font-semibold text-slate-400">
                      {t('editor.characters')}
                    </label>
                    <select
                      value={primaryChar}
                      onChange={(e) => {
                        const newCharId = e.target.value as CharacterId;
                        const charCopy = [...scene.characters];
                        if (charCopy.length > 0) {
                          charCopy[0] = { ...charCopy[0], characterId: newCharId };
                        }
                        handleUpdateScene(idx, { characters: charCopy });
                      }}
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white cursor-pointer"
                    >
                      {CHARACTER_CATALOG.map((c) => (
                        <option key={c.id} value={c.id}>
                          {language === 'ar' ? c.nameAr : c.nameEn} ({c.species})
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Action Selector */}
                  <div className="space-y-1">
                    <label className="block text-[11px] font-semibold text-slate-400">
                      {t('editor.action')}
                    </label>
                    <select
                      value={primaryAction}
                      onChange={(e) => {
                        const newAction = e.target.value as CharacterAction;
                        const charCopy = [...scene.characters];
                        if (charCopy.length > 0) {
                          charCopy[0] = { ...charCopy[0], action: newAction };
                        }
                        handleUpdateScene(idx, { characters: charCopy });
                      }}
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white cursor-pointer"
                    >
                      <option value="idle">{t('actions.idle')}</option>
                      <option value="walk">{t('actions.walk')}</option>
                      <option value="run">{t('actions.run')}</option>
                      <option value="jump">{t('actions.jump')}</option>
                      <option value="wave">{t('actions.wave')}</option>
                      <option value="talk">{t('actions.talk')}</option>
                      <option value="laugh">{t('actions.laugh')}</option>
                      <option value="celebrate">{t('actions.celebrate')}</option>
                      <option value="fall">{t('actions.fall')}</option>
                    </select>
                  </div>

                  {/* Background Selector */}
                  <div className="space-y-1">
                    <label className="block text-[11px] font-semibold text-slate-400">
                      {t('editor.background')}
                    </label>
                    <select
                      value={scene.backgroundId}
                      onChange={(e) =>
                        handleUpdateScene(idx, { backgroundId: e.target.value as BackgroundId })
                      }
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white cursor-pointer"
                    >
                      {BACKGROUND_CATALOG.map((bg) => (
                        <option key={bg.id} value={bg.id}>
                          {language === 'ar' ? bg.nameAr : bg.nameEn}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="flex items-center justify-between pt-4 border-t border-purple-500/20">
            <button
              onClick={() => setCurrentStep(2)}
              className="px-5 py-2.5 rounded-xl border border-slate-700 text-xs font-semibold text-slate-300 hover:text-white transition"
            >
              {t('common.back')}
            </button>
            <button
              onClick={() => setCurrentStep(4)}
              className="px-6 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs flex items-center gap-2 transition"
            >
              <span>{t('common.next')}: {t('create.step4_title')}</span>
              {isRTL ? <ArrowLeft className="w-3.5 h-3.5" /> : <ArrowRight className="w-3.5 h-3.5" />}
            </button>
          </div>
        </div>
      )}

      {/* STEP 4: AUDIO & VOICEOVER */}
      {currentStep === 4 && (
        <div className="glass-panel rounded-3xl p-6 md:p-8 border border-purple-500/20 space-y-6">
          <div>
            <h3 className="text-xl font-bold text-white">{t('create.step4_title')}</h3>
            <p className="text-xs text-slate-400">
              {language === 'ar'
                ? 'استمع لمعاينة الأصوات، اختر الموسيقى التصويرية ونغمات المؤثرات'
                : 'Configure voice personas, background orchestration, and audio cues'}
            </p>
          </div>

          {/* Background Music Selector */}
          <div className="space-y-3">
            <label className="block text-sm font-bold text-white">
              {t('editor.music')}
            </label>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {[
                { id: 'playful_adventure', nameAr: 'مغامرة مرحة (أكوستيك)', nameEn: 'Playful Adventure (Acoustic)' },
                { id: 'whimsical_story', nameAr: 'حكاية خيالية (أجراس ونغمات)', nameEn: 'Whimsical Story (Ambient)' },
                { id: 'upbeat_groove', nameAr: 'إيقاع حيوي (سريع)', nameEn: 'Upbeat Groove (Energetic)' },
              ].map((m) => (
                <div
                  key={m.id}
                  onClick={() => setSelectedMusic(m.id as MusicTrackType)}
                  className={`p-4 rounded-2xl border cursor-pointer transition flex items-center justify-between ${
                    selectedMusic === m.id
                      ? 'bg-purple-950/60 border-purple-500 shadow-md shadow-purple-600/20'
                      : 'bg-slate-950/60 border-slate-800 hover:bg-slate-900'
                  }`}
                >
                  <div>
                    <p className="text-xs font-bold text-white">
                      {language === 'ar' ? m.nameAr : m.nameEn}
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      audioEngine.startMusic(m.id as MusicTrackType);
                      setTimeout(() => audioEngine.stopMusic(), 4000);
                    }}
                    className="p-2 rounded-xl bg-purple-600/30 text-purple-300 hover:text-white hover:bg-purple-600 transition"
                    title="Preview Track"
                  >
                    <Volume2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Dialogue Lines Speech Preview */}
          <div className="space-y-3">
            <label className="block text-sm font-bold text-white">
              {language === 'ar' ? 'معاينة نبرات الحوار الصوتي' : 'Speech Preview & Dialogue Lines'}
            </label>
            <div className="space-y-2">
              {scenes.map((scene, idx) => {
                const line = scene.dialogue?.[0];
                if (!line) return null;
                return (
                  <div
                    key={idx}
                    className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800 flex items-center justify-between gap-4"
                  >
                    <div>
                      <span className="text-[11px] font-bold text-purple-300">
                        {line.speakerName}:
                      </span>
                      <p className="text-xs text-white mt-0.5">{line.text}</p>
                    </div>
                    <button
                      onClick={() =>
                        audioEngine.speakDialogue(line.text, targetLang, line.characterId)
                      }
                      className="px-3 py-1.5 rounded-xl bg-purple-600/80 hover:bg-purple-600 text-white text-xs font-semibold flex items-center gap-1.5 flex-shrink-0 transition"
                    >
                      <Volume2 className="w-3.5 h-3.5" />
                      <span>{t('common.preview')}</span>
                    </button>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="flex items-center justify-between pt-4 border-t border-purple-500/20">
            <button
              onClick={() => setCurrentStep(3)}
              className="px-5 py-2.5 rounded-xl border border-slate-700 text-xs font-semibold text-slate-300 hover:text-white transition"
            >
              {t('common.back')}
            </button>
            <button
              onClick={() => {
                setCurrentStep(5);
                handleStartRender();
              }}
              className="px-8 py-3.5 rounded-2xl bg-waled-gradient hover:opacity-95 text-white font-extrabold text-sm shadow-xl shadow-purple-600/30 flex items-center gap-2 transition cursor-pointer"
            >
              <Video className="w-4 h-4 text-cyan-300" />
              <span>{t('editor.render_video')}</span>
            </button>
          </div>
        </div>
      )}

      {/* STEP 5: ANIMATION & RENDERING */}
      {currentStep === 5 && (
        <div className="space-y-6">
          <div className="text-center max-w-xl mx-auto space-y-2">
            <h2 className="text-2xl font-extrabold text-white">
              {isRendering
                ? t('render.rendering_title')
                : renderedVideoUrl
                ? t('render.ready_title')
                : t('create.step5_title')}
            </h2>
            <p className="text-xs text-slate-400">
              {isRendering
                ? language === 'ar'
                  ? 'يتم دمج إطارات التحريك والأصوات المتزامنة والترجمة التوضيحية داخل ملف MP4 حقيقي.'
                  : 'Synthesizing frames, audio tracks, and burned-in subtitles into an actual MP4 video container.'
                : t('create.step5_desc')}
            </p>
          </div>

          <div className="max-w-2xl mx-auto">
            <VideoExportCard
              projectId={savedProjectId || 'new_proj'}
              title={title}
              aspectRatio={aspectRatio}
              duration={totalCalculatedDuration}
              videoUrl={renderedVideoUrl}
              isRendering={isRendering}
              renderProgress={renderProgress}
              error={renderError}
              onRetry={handleStartRender}
              onEdit={() => savedProjectId && onOpenEditor(savedProjectId)}
              showEditButton={Boolean(savedProjectId)}
            />
          </div>
        </div>
      )}
    </div>
  );
};
