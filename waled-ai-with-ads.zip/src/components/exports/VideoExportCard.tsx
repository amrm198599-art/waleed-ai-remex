import React, { useState, useEffect, useRef } from 'react';
import { useLocalization } from '../../lib/localization';
import { VideoAspectRatio } from '../../types';
import { RenderProgressUpdate, VideoRenderingPipeline } from '../../lib/rendering/pipeline';
import {
  Download,
  ExternalLink,
  Film,
  Share2,
  Check,
  AlertCircle,
  RefreshCw,
  Video,
  CheckCircle2,
  Smartphone,
  Info,
} from 'lucide-react';

export interface VideoExportCardProps {
  projectId: string;
  title: string;
  aspectRatio?: VideoAspectRatio;
  duration?: number;
  videoUrl?: string | null;
  downloadUrl?: string | null;
  isRendering?: boolean;
  renderProgress?: RenderProgressUpdate | null;
  error?: string | null;
  onRetry?: () => void;
  onEdit?: () => void;
  showEditButton?: boolean;
  compact?: boolean;
}

export const VideoExportCard: React.FC<VideoExportCardProps> = ({
  projectId,
  title,
  aspectRatio = '16:9',
  duration = 15,
  videoUrl,
  downloadUrl,
  isRendering = false,
  renderProgress = null,
  error = null,
  onRetry,
  onEdit,
  showEditButton = true,
  compact = false,
}) => {
  const { language, t, isRTL } = useLocalization();

  const [verifiedFile, setVerifiedFile] = useState<{
    exists: boolean;
    size: number;
    streamUrl: string;
    downloadUrl: string;
  } | null>(null);

  const [isCheckingFile, setIsCheckingFile] = useState<boolean>(false);
  const [copiedLink, setCopiedLink] = useState<boolean>(false);
  const [checkError, setCheckError] = useState<string | null>(null);

  const activeBlobUrlRef = useRef<string | null>(null);

  // Reconcile and track any temporary blob URLs for cleanup
  useEffect(() => {
    if (videoUrl && videoUrl.startsWith('blob:')) {
      activeBlobUrlRef.current = videoUrl;
    }
    return () => {
      if (activeBlobUrlRef.current) {
        VideoRenderingPipeline.revokeUrl(activeBlobUrlRef.current);
        activeBlobUrlRef.current = null;
      }
    };
  }, [videoUrl]);

  // Check server file readiness on mount or when rendering finishes
  const verifyServerFile = async () => {
    if (!projectId || isRendering) return;
    setIsCheckingFile(true);
    setCheckError(null);

    try {
      const res = await fetch(`/api/videos/${projectId}/status`, {
        cache: 'no-store',
      });
      if (res.ok) {
        const data = await res.json();
        setVerifiedFile(data);
      } else if (res.status === 404) {
        setVerifiedFile({
          exists: false,
          size: 0,
          streamUrl: `/api/videos/${projectId}/view`,
          downloadUrl: `/api/videos/${projectId}/download`,
        });
      }
    } catch (e: any) {
      console.warn('[VideoExportCard] Could not verify file status on server:', e);
      setCheckError(e.message || 'Network error verifying file');
    } finally {
      setIsCheckingFile(false);
    }
  };

  useEffect(() => {
    verifyServerFile();
  }, [projectId, isRendering, videoUrl]);

  // Determine active media URLs
  const effectiveStreamUrl =
    verifiedFile?.exists
      ? verifiedFile.streamUrl
      : videoUrl || `/api/videos/${projectId}/view`;

  const effectiveDownloadUrl =
    verifiedFile?.exists
      ? verifiedFile.downloadUrl
      : downloadUrl || `/api/videos/${projectId}/download`;

  const isReady =
    !isRendering &&
    !error &&
    (verifiedFile?.exists || Boolean(videoUrl));

  // Format file size
  const formatSize = (bytes: number) => {
    if (!bytes || bytes === 0) return '';
    if (bytes >= 1048576) {
      return `${(bytes / 1048576).toFixed(1)} MB`;
    }
    return `${Math.round(bytes / 1024)} KB`;
  };

  // Safe file title
  const safeFilename = `${title.trim().replace(/[^\w\s\u0600-\u06FF-]/gi, '_') || 'waled_video'}.mp4`;

  // Handle Share
  const handleShare = async () => {
    const shareUrl = effectiveStreamUrl.startsWith('http')
      ? effectiveStreamUrl
      : `${window.location.origin}${effectiveStreamUrl}`;

    if (navigator.share) {
      try {
        await navigator.share({
          title,
          text: language === 'ar' ? `شاهد هذا الفيديو الكرتوني من وليد AI: ${title}` : `Watch this animated cartoon created on Waled AI: ${title}`,
          url: shareUrl,
        });
      } catch (e) {
        // Ignored share cancellation
      }
    } else {
      navigator.clipboard.writeText(shareUrl);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2200);
    }
  };

  // Aspect ratio classes for responsive video container
  const getAspectClass = () => {
    if (aspectRatio === '9:16') return 'aspect-[9/16] max-w-xs mx-auto';
    if (aspectRatio === '1:1') return 'aspect-square max-w-sm mx-auto';
    return 'aspect-video w-full';
  };

  return (
    <div className="glass-panel rounded-3xl overflow-hidden border border-purple-500/25 p-4 md:p-6 space-y-5 transition-all shadow-xl">
      {/* 1. Video Player or In-Progress Canvas */}
      <div className={`relative rounded-2xl overflow-hidden bg-black border border-purple-500/30 shadow-2xl flex items-center justify-center ${getAspectClass()}`}>
        {isRendering ? (
          <div className="p-6 text-center space-y-4 w-full">
            <div className="w-14 h-14 rounded-2xl bg-waled-gradient mx-auto flex items-center justify-center animate-pulse shadow-lg shadow-purple-600/40">
              <Video className="w-7 h-7 text-white" />
            </div>
            <div>
              <h4 className="text-sm md:text-base font-bold text-white">
                {t('render.rendering_title')}
              </h4>
              <p className="text-xs text-purple-300/80 mt-1">
                {renderProgress
                  ? language === 'ar'
                    ? renderProgress.messageAr
                    : renderProgress.messageEn
                  : t('render.stage_rendering')}
              </p>
            </div>
            <div className="w-full bg-slate-900 rounded-full h-2 overflow-hidden border border-purple-500/30">
              <div
                className="bg-waled-gradient h-full rounded-full transition-all duration-300"
                style={{ width: `${renderProgress?.progress || 15}%` }}
              />
            </div>
          </div>
        ) : error ? (
          <div className="p-6 text-center space-y-3 w-full">
            <div className="w-12 h-12 rounded-xl bg-rose-950/70 border border-rose-500/40 flex items-center justify-center mx-auto text-rose-400">
              <AlertCircle className="w-6 h-6" />
            </div>
            <h4 className="text-sm font-bold text-white">{t('render.render_failed')}</h4>
            <p className="text-xs text-rose-300/90 max-w-sm mx-auto">{error}</p>
            {onRetry && (
              <button
                onClick={onRetry}
                className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs inline-flex items-center gap-1.5 transition"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>{language === 'ar' ? 'إعادة المحاولة' : 'Retry'}</span>
              </button>
            )}
          </div>
        ) : isReady ? (
          <video
            src={effectiveStreamUrl}
            controls
            playsInline
            preload="metadata"
            className="w-full h-full object-contain"
          />
        ) : (
          <div className="p-6 text-center space-y-2 text-slate-400">
            <Video className="w-8 h-8 mx-auto text-purple-400/60" />
            <p className="text-xs">
              {language === 'ar'
                ? 'الفيديو بانتظار بدء المعالجة والتصدير...'
                : 'Video is queued and ready for rendering...'}
            </p>
          </div>
        )}

        {/* Status Pill Badge */}
        {isReady && (
          <div className="absolute top-3 left-3 px-2.5 py-1 rounded-lg bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 text-[11px] font-bold flex items-center gap-1.5 backdrop-blur-md">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            <span>{language === 'ar' ? 'جاهز للتنزيل' : 'Ready to Download'}</span>
          </div>
        )}
      </div>

      {/* 2. Metadata Specs */}
      <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
        <div>
          <h3 className="font-extrabold text-white text-base line-clamp-1">{title}</h3>
          <p className="text-[11px] text-slate-400 mt-0.5">
            {aspectRatio} • {duration}s
            {verifiedFile?.size ? ` • ${formatSize(verifiedFile.size)} • MP4 (H.264/AAC)` : ' • MP4'}
          </p>
        </div>

        {verifiedFile?.exists && (
          <span className="text-[11px] font-mono font-bold text-cyan-300 px-2 py-0.5 rounded-md bg-purple-950/80 border border-purple-500/30">
            {formatSize(verifiedFile.size)}
          </span>
        )}
      </div>

      {/* 3. Action Buttons (Download, Open Video, Edit, Share) */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5 pt-1">
        {/* Primary Download Button */}
        <a
          href={isReady ? effectiveDownloadUrl : '#'}
          download={isReady ? safeFilename : undefined}
          aria-disabled={!isReady}
          onClick={(e) => {
            if (!isReady) {
              e.preventDefault();
            }
          }}
          className={`flex-1 py-3 px-4 rounded-xl font-bold text-xs md:text-sm flex items-center justify-center gap-2 transition shadow-lg ${
            isReady
              ? 'bg-waled-gradient hover:opacity-95 text-white shadow-purple-600/30 cursor-pointer active:scale-98'
              : 'bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed opacity-60'
          }`}
          title={language === 'ar' ? 'تحميل ملف MP4 مباشرة إلى جهازك' : 'Download MP4 file directly to your device'}
        >
          <Download className="w-4 h-4 text-cyan-300" />
          <span>{t('render.download_btn')}</span>
        </a>

        {/* Alternative "Open Video" Button (Crucial for Mobile Safari / Android Chrome) */}
        <a
          href={isReady ? effectiveStreamUrl : '#'}
          target="_blank"
          rel="noopener noreferrer"
          aria-disabled={!isReady}
          onClick={(e) => {
            if (!isReady) {
              e.preventDefault();
            }
          }}
          className={`py-3 px-4 rounded-xl font-semibold text-xs md:text-sm flex items-center justify-center gap-2 transition border ${
            isReady
              ? 'bg-slate-900 hover:bg-slate-800 text-cyan-300 border-cyan-500/40 hover:border-cyan-400 cursor-pointer'
              : 'bg-slate-900 text-slate-600 border-slate-800 cursor-not-allowed opacity-60'
          }`}
          title={language === 'ar' ? 'فتح الفيديو في علامة تبويب جديدة أو مشغل الهاتف' : 'Open video in a new tab or mobile video player'}
        >
          <ExternalLink className="w-4 h-4" />
          <span>{t('render.open_video')}</span>
        </a>

        {/* Edit Button */}
        {showEditButton && onEdit && (
          <button
            onClick={onEdit}
            className="py-3 px-3.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-purple-300 hover:text-white border border-purple-500/30 text-xs font-semibold flex items-center justify-center gap-1.5 transition cursor-pointer"
            title={t('render.edit_btn')}
          >
            <Film className="w-4 h-4 text-purple-400" />
            <span className="hidden sm:inline">{t('render.edit_btn')}</span>
          </button>
        )}

        {/* Share Button */}
        {isReady && (
          <button
            onClick={handleShare}
            className="py-3 px-3.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-200 hover:text-white border border-slate-700 text-xs font-semibold flex items-center justify-center transition cursor-pointer"
            title={t('render.share_btn')}
          >
            {copiedLink ? (
              <Check className="w-4 h-4 text-emerald-400" />
            ) : (
              <Share2 className="w-4 h-4 text-cyan-400" />
            )}
          </button>
        )}
      </div>

      {/* 4. Mobile Download Guidance Tip */}
      <div className="p-3 rounded-2xl bg-slate-950/60 border border-purple-500/15 flex items-start gap-2.5 text-[11px] text-slate-300">
        <Smartphone className="w-4 h-4 text-cyan-400 flex-shrink-0 mt-0.5" />
        <p className="leading-relaxed">
          <strong className="text-white">
            {language === 'ar' ? 'ملاحظة للهواتف: ' : 'Mobile Tip: '}
          </strong>
          {t('render.mobile_download_tip')}
        </p>
      </div>
    </div>
  );
};
