import React, { useState } from 'react';
import { useLocalization } from '../../lib/localization';
import { Project } from '../../types';
import { VideoExportCard } from './VideoExportCard';
import {
  Download,
  Film,
  Video,
} from 'lucide-react';

interface ExportsViewProps {
  projects: Project[];
  onOpenEditor: (projectId: string) => void;
  onNavigate: (view: string) => void;
}

export const ExportsView: React.FC<ExportsViewProps> = ({
  projects,
  onOpenEditor,
  onNavigate,
}) => {
  const { language, t } = useLocalization();

  const completedProjects = projects.filter((p) => p.status === 'completed');

  return (
    <div className="space-y-6 pb-16">
      <div className="glass-panel rounded-3xl p-6 border border-purple-500/20">
        <h1 className="text-2xl font-extrabold text-white flex items-center gap-2">
          <Download className="w-6 h-6 text-cyan-400" />
          <span>{t('nav.exports')}</span>
        </h1>
        <p className="text-xs md:text-sm text-slate-400 mt-1">
          {language === 'ar'
            ? 'الفيديوهات المنتجة والجاهزة للتحميل المباشر بصيغة MP4 وبدون قيود'
            : 'Download and manage your rendered MP4 cartoon videos with verified streaming'}
        </p>
      </div>

      {completedProjects.length === 0 ? (
        <div className="glass-panel rounded-3xl p-12 text-center space-y-4 border border-purple-500/20 max-w-lg mx-auto">
          <div className="w-14 h-14 rounded-2xl bg-purple-950/60 border border-purple-500/30 flex items-center justify-center mx-auto text-purple-400">
            <Video className="w-7 h-7" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white">
              {language === 'ar' ? 'لا توجد فيديوهات مصدرة بعد' : 'No Rendered Videos Yet'}
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              {language === 'ar'
                ? 'أنشئ أول قصة كرتونية لك ثم قم بمعالجتها وتصديرها كفيديو MP4 كامل مع الصوت والترجمة.'
                : 'Create and render your first cartoon video with full synchronized dialogue and music.'}
            </p>
          </div>
          <button
            onClick={() => onNavigate('create')}
            className="px-5 py-2.5 rounded-xl bg-waled-gradient hover:opacity-95 text-white font-bold text-xs shadow-md shadow-purple-600/30 inline-flex items-center gap-2 transition"
          >
            <Video className="w-4 h-4" />
            <span>{t('dashboard.cta_create')}</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {completedProjects.map((proj) => (
            <VideoExportCard
              key={proj.id}
              projectId={proj.id}
              title={proj.title}
              aspectRatio={proj.aspectRatio}
              duration={proj.duration}
              videoUrl={proj.renderedVideoUrl}
              downloadUrl={proj.downloadUrl}
              onEdit={() => onOpenEditor(proj.id)}
              showEditButton={true}
            />
          ))}
        </div>
      )}
    </div>
  );
};
