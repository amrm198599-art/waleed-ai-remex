import React, { useState, useEffect } from 'react';
import { LocalizationProvider } from './lib/localization';
import { Navbar } from './components/layout/Navbar';
import { Sidebar } from './components/layout/Sidebar';
import { DashboardView } from './components/dashboard/DashboardView';
import { CreateWorkflow } from './components/create/CreateWorkflow';
import { AnimationStudio } from './components/studio/AnimationStudio';
import { ProjectEditor } from './components/editor/ProjectEditor';
import { ProjectsView } from './components/projects/ProjectsView';
import { MediaLibrary } from './components/media/MediaLibrary';
import { ExportsView } from './components/exports/ExportsView';
import { SettingsView } from './components/settings/SettingsView';
import { AiVideoView } from './components/aivideo/AiVideoView';
import { RemixView } from './components/aivideo/RemixView';
import { Project, QuotaStatus } from './types';
import { initAds, onScreenChange, onTaskCompleted } from './lib/ads/ads';

export default function App() {
  return (
    <LocalizationProvider>
      <MainApp />
    </LocalizationProvider>
  );
}

function MainApp() {
  const [activeView, setActiveView] = useState<string>('dashboard');
  const [isOpenMobile, setIsOpenMobile] = useState<boolean>(false);
  const [projects, setProjects] = useState<Project[]>([]);
  const [quota, setQuota] = useState<QuotaStatus | null>(null);
  const [currentProject, setCurrentProject] = useState<Project | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [bannerHeight, setBannerHeight] = useState<number>(0);

  // Ads (Android app only): banner stays at the bottom, interstitial is rate-limited.
  useEffect(() => {
    initAds(setBannerHeight);
  }, []);

  const navigate = (view: string) => {
    setActiveView(view);
    onScreenChange();
  };

  // Fetch initial user, quota, and projects
  const refreshData = async () => {
    try {
      const [authRes, projRes] = await Promise.all([
        fetch('/api/auth/me'),
        fetch('/api/projects'),
      ]);

      if (authRes.ok) {
        const authData = await authRes.json();
        if (authData.quota) setQuota(authData.quota);
      }

      if (projRes.ok) {
        const projData = await projRes.json();
        setProjects(projData);
      }
    } catch (e) {
      console.error('Error fetching data:', e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    refreshData();
  }, []);

  const handleOpenProject = (projectId: string) => {
    const proj = projects.find((p) => p.id === projectId);
    if (proj) {
      setCurrentProject(proj);
      setActiveView('editor');
    }
  };

  const handleSaveProject = async (updated: Project) => {
    try {
      const res = await fetch(`/api/projects/${updated.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updated),
      });
      if (res.ok) {
        const saved = await res.json();
        setProjects((prev) => prev.map((p) => (p.id === saved.id ? saved : p)));
        setCurrentProject(saved);
      }
    } catch (e) {
      console.error('Error saving project:', e);
    }
  };

  const handleDeleteProject = async (projectId: string) => {
    try {
      const res = await fetch(`/api/projects/${projectId}`, {
        method: 'DELETE',
      });
      if (res.ok) {
        setProjects((prev) => prev.filter((p) => p.id !== projectId));
        if (currentProject?.id === projectId) {
          setCurrentProject(null);
          setActiveView('dashboard');
        }
      }
    } catch (e) {
      console.error('Error deleting project:', e);
    }
  };

  const handleProjectCreated = (newProject: Project) => {
    setProjects((prev) => [newProject, ...prev]);
    setCurrentProject(newProject);
    onTaskCompleted();
  };

  return (
    <div style={{ paddingBottom: bannerHeight }} className="min-h-screen bg-[#0c0d14] text-slate-100 flex flex-col selection:bg-purple-600 selection:text-white">
      {/* Top Navbar */}
      <Navbar
        quota={quota}
        onOpenMobileMenu={() => setIsOpenMobile(true)}
        onNavigate={(view) => navigate(view)}
        activeView={activeView}
      />

      {/* Main Container with Sidebar & Content */}
      <div className="flex-1 flex max-w-7xl w-full mx-auto">
        <Sidebar
          activeView={activeView}
          onNavigate={(view) => navigate(view)}
          quota={quota}
          isOpenMobile={isOpenMobile}
          onCloseMobile={() => setIsOpenMobile(false)}
        />

        <main className="flex-1 p-4 md:p-8 overflow-y-auto">
          {activeView === 'dashboard' && (
            <DashboardView
              projects={projects}
              quota={quota}
              onNavigate={(view) => navigate(view)}
              onOpenProject={handleOpenProject}
              onDeleteProject={handleDeleteProject}
            />
          )}

          {activeView === 'create' && (
            <CreateWorkflow
              quota={quota}
              onProjectCreated={handleProjectCreated}
              onOpenEditor={(id) => handleOpenProject(id)}
              onRefreshQuota={refreshData}
            />
          )}

          {activeView === 'studio' && (
            <AnimationStudio onNavigate={(view) => navigate(view)} />
          )}

          {activeView === 'editor' && currentProject && (
            <ProjectEditor
              project={currentProject}
              quota={quota}
              onSaveProject={handleSaveProject}
              onRefreshQuota={refreshData}
            />
          )}

          {activeView === 'projects' && (
            <ProjectsView
              projects={projects}
              onOpenProject={handleOpenProject}
              onDeleteProject={handleDeleteProject}
              onNavigate={(view) => navigate(view)}
            />
          )}

          {activeView === 'aivideo' && <AiVideoView projects={projects} onProjectCreated={handleProjectCreated} />}

          {activeView === 'remix' && <RemixView projects={projects} />}

          {activeView === 'media' && <MediaLibrary />}

          {activeView === 'exports' && (
            <ExportsView
              projects={projects}
              onOpenEditor={handleOpenProject}
              onNavigate={(view) => navigate(view)}
            />
          )}

          {activeView === 'settings' && (
            <SettingsView quota={quota} onRefreshQuota={refreshData} />
          )}
        </main>
      </div>
    </div>
  );
}
