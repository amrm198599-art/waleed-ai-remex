export type VideoAspectRatio = '16:9' | '9:16' | '1:1';
export type VideoLanguage = 'ar' | 'en';
export type VideoStyle = 'cartoon' | 'storyboard_media';

export type CharacterId =
  | 'bader_rabbit'
  | 'faris_bear'
  | 'maymoun_monkey'
  | 'salma_explorer'
  | 'robo_z';

export type CharacterAction =
  | 'idle'
  | 'walk'
  | 'run'
  | 'jump'
  | 'wave'
  | 'talk'
  | 'laugh'
  | 'celebrate'
  | 'fall'
  | 'look_left'
  | 'look_right';

export type FacialExpression =
  | 'happy'
  | 'talking'
  | 'surprised'
  | 'laughing'
  | 'determined'
  | 'silly';

export type BackgroundId =
  | 'enchanted_forest'
  | 'sunny_meadow'
  | 'treehouse_interior'
  | 'cosmic_galaxy'
  | 'city_park';

export type CameraMovement =
  | 'static'
  | 'pan_left'
  | 'pan_right'
  | 'zoom_in'
  | 'zoom_out'
  | 'shake';

export type TransitionType = 'fade' | 'cut' | 'wipe' | 'dissolve';

export type SFXType =
  | 'none'
  | 'pop'
  | 'boing'
  | 'whoosh'
  | 'cheer'
  | 'laugh'
  | 'footsteps'
  | 'bell';

export type MusicTrackType =
  | 'none'
  | 'playful_adventure'
  | 'whimsical_story'
  | 'upbeat_groove';

export interface DialogueLine {
  id: string;
  characterId: CharacterId;
  speakerName: string;
  text: string;
  expression?: FacialExpression;
  startTime?: number;
  duration?: number;
}

export interface CharacterPlacement {
  characterId: CharacterId;
  action: CharacterAction;
  x: number; // 0 to 100 (% of canvas width)
  y: number; // 0 to 100 (% of canvas height)
  scale: number; // default 1.0
  flipX: boolean;
  zIndex: number;
}

export interface Scene {
  id: string;
  order: number;
  duration: number; // in seconds (e.g. 5.0)
  narration: string;
  dialogue: DialogueLine[];
  characters: CharacterPlacement[];
  backgroundId: BackgroundId;
  camera: CameraMovement;
  transition: TransitionType;
  sfx?: SFXType;
  musicTrack?: MusicTrackType;
  subtitlesEnabled?: boolean;
}

export interface ScriptModel {
  title: string;
  scenes: Scene[];
}

export interface Project {
  id: string;
  userId: string;
  title: string;
  description: string;
  language: VideoLanguage;
  aspectRatio: VideoAspectRatio;
  videoStyle: VideoStyle;
  duration: number;
  scenes: Scene[];
  status: 'draft' | 'rendering' | 'completed' | 'failed';
  renderedVideoUrl?: string;
  downloadUrl?: string;
  streamUrl?: string;
  thumbnailUrl?: string;
  createdAt: string;
  updatedAt: string;
}

export interface GenerationJob {
  id: string;
  userId: string;
  projectId: string;
  status:
    | 'queued'
    | 'validating_assets'
    | 'synthesizing_audio'
    | 'rendering_frames'
    | 'assembling_stream'
    | 'completed'
    | 'failed'
    | 'cancelled';
  progress: number; // 0 to 100
  idempotencyKey: string;
  outputVideoUrl?: string;
  outputFormat?: string;
  errorCode?: string;
  errorMessage?: string;
  logs: string[];
  createdAt: string;
  startedAt?: string;
  completedAt?: string;
}

export interface QuotaStatus {
  isUnlimited: boolean;
  activeJobs: number;
  maxConcurrentJobs: number;
  canGenerate: boolean;
  totalGenerated: number;
  planName: string;
  usedToday: number;
  maxAllowed: number;
  remaining: number;
  resetInSeconds: number;
  nextResetIso: string;
}

export interface UserProfile {
  id: string;
  displayName: string;
  email: string;
  preferredLanguage: VideoLanguage;
  preferredTheme: 'light' | 'dark';
}
