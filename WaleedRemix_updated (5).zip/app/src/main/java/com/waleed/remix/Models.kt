package com.waleed.remix

import android.net.Uri
import androidx.annotation.StringRes
import kotlin.math.roundToInt

/** عنصر مختار: كل الملفات محفوظة داخل مخزن التطبيق (480p للفيديو) لذلك لا تضيع. */
data class MediaEntry(
    val uri: Uri,
    val isVideo: Boolean,
    val durationMs: Long,
    val shortSide: Int = 0,
    /** الأبعاد المعروضة (بعد الدوران) قبل الضغط، لحساب مقاس 480. */
    val width: Int = 0,
    val height: Int = 0,
)

/** خلية داخل الشاشة النهائية، كنسب من 0 إلى 1 (من أعلى اليسار). */
data class Cell(val x: Float, val y: Float, val w: Float, val h: Float)

/** مكان الفيديو الصغير (صورة الوجه مثلًا) في وضع "شاشة كاملة + فيديو صغير". */
enum class PipCorner(@StringRes val labelRes: Int) {
    SIDE_RIGHT(R.string.corner_sr),
    SIDE_LEFT(R.string.corner_sl),
    BOTTOM_RIGHT(R.string.corner_br),
    BOTTOM_LEFT(R.string.corner_bl),
}

/** صوت وضع الفيديو الصغير (ريأكشن): الأساسي فقط / الصغير فقط / دمج الصوتين. */
enum class PipAudio(@StringRes val labelRes: Int) {
    PRIMARY(R.string.pip_audio_primary),
    SMALL(R.string.pip_audio_small),
    BOTH(R.string.pip_audio_both),
}

// كل الإخراج بدقة 480 فقط
private const val PW = 480 // عرض الشاشة الطولية
private const val PH = 854 // ارتفاعها

enum class RemixLayout(
    @StringRes val labelRes: Int,
    val canvasW: Int,
    val canvasH: Int,
    private val baseCells: List<Cell>,
    val isPip: Boolean = false,
    /** لصق متتالي: كل العناصر واحدًا بعد الآخر في فيديو واحد (لا يظهر ضمن خيارات الدمج). */
    val isSequential: Boolean = false,
) {
    CONCAT_P(R.string.mode_concat, PW, PH, listOf(Cell(0f, 0f, 1f, 1f)), isSequential = true),
    CONCAT_L(R.string.mode_concat, PH, PW, listOf(Cell(0f, 0f, 1f, 1f)), isSequential = true),
    V2(R.string.layout_v2, PW, PH, listOf(Cell(0f, 0f, 1f, .5f), Cell(0f, .5f, 1f, .5f))),
    H2(R.string.layout_h2, PH, PW, listOf(Cell(0f, 0f, .5f, 1f), Cell(.5f, 0f, .5f, 1f))),
    PIP_P(R.string.layout_pip_p, PW, PH, listOf(Cell(0f, 0f, 1f, 1f), Cell(0f, 0f, 0.3f, 0.3f)), isPip = true),
    PIP_L(R.string.layout_pip_l, PH, PW, listOf(Cell(0f, 0f, 1f, 1f), Cell(0f, 0f, 0.3f, 0.3f)), isPip = true),
    V3(
        R.string.layout_v3, PW, PH,
        listOf(Cell(0f, 0f, 1f, 1f / 3), Cell(0f, 1f / 3, 1f, 1f / 3), Cell(0f, 2f / 3, 1f, 1f / 3)),
    ),
    H3(
        R.string.layout_h3, PH, PW,
        listOf(Cell(0f, 0f, 1f / 3, 1f), Cell(1f / 3, 0f, 1f / 3, 1f), Cell(2f / 3, 0f, 1f / 3, 1f)),
    ),
    G4(
        R.string.layout_g4, PW, PH,
        listOf(Cell(0f, 0f, .5f, .5f), Cell(.5f, 0f, .5f, .5f), Cell(0f, .5f, .5f, .5f), Cell(.5f, .5f, .5f, .5f)),
    );

    val count: Int get() = baseCells.size

    /** خلايا الدمج؛ في وضع الفيديو الصغير يتحدد مكانه حسب [corner]. */
    fun cells(corner: PipCorner): List<Cell> {
        if (!isPip) return baseCells
        val sidePx = if (canvasW < canvasH) 0.32f * canvasW else 0.22f * canvasW
        val w = sidePx / canvasW
        val h = sidePx / canvasH
        val mx = 0.04f
        val myBottom = 0.11f // مساحة أكبر بالأسفل حتى لا يغطي العلامة المائية
        val onRight = corner == PipCorner.SIDE_RIGHT || corner == PipCorner.BOTTOM_RIGHT
        val onSide = corner == PipCorner.SIDE_RIGHT || corner == PipCorner.SIDE_LEFT
        val x = if (onRight) 1f - mx - w else mx
        // الجانب: في منتصف الارتفاع، الأسفل: قريب من الحافة السفلية
        val y = if (onSide) (1f - h) / 2f else 1f - myBottom - h
        return listOf(Cell(0f, 0f, 1f, 1f), Cell(x, y, w, h))
    }

    fun cellWidthPx(i: Int, corner: PipCorner): Int = even(cells(corner)[i].w * canvasW)
    fun cellHeightPx(i: Int, corner: PipCorner): Int = even(cells(corner)[i].h * canvasH)

    companion object {
        fun forCount(n: Int): List<RemixLayout> = when (n) {
            2 -> listOf(V2, H2, PIP_P, PIP_L)
            3 -> listOf(V3, H3)
            4 -> listOf(G4)
            else -> emptyList()
        }

        private fun even(v: Float): Int = (v.roundToInt() / 2) * 2
    }
}

/** أوضاع التطبيق: دمج على الشاشة، لصق متتالي، ضغط فيديو واحد. */
enum class RemixMode { MERGE, CONCAT, COMPRESS }

/** مستوى ضغط الفيديو المنفرد: أقصر ضلع + معدل البيانات. */
enum class CompressLevel(@StringRes val labelRes: Int, val shortSide: Int, val bitrate: Int) {
    HIGH(R.string.level_high, 360, 600_000),
    MEDIUM(R.string.level_medium, 480, 1_000_000),
    LIGHT(R.string.level_light, 720, 2_000_000),
}

sealed interface ExportState {
    data object Idle : ExportState
    data class Running(val progress: Float) : ExportState
    data class Done(val uri: Uri) : ExportState
    data class Error(val message: String) : ExportState
}
