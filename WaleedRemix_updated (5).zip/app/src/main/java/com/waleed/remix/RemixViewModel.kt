package com.waleed.remix

import android.app.Application
import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.media.ExifInterface
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.text.Layout
import android.text.SpannableString
import android.text.Spanned
import android.text.style.AbsoluteSizeSpan
import android.text.style.AlignmentSpan
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.Size
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.OverlaySettings
import androidx.media3.effect.Presentation
import androidx.media3.effect.TextOverlay
import androidx.media3.effect.TextureOverlay
import androidx.media3.effect.VideoCompositorSettings
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import com.google.common.collect.ImmutableList
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.roundToInt
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

enum class Screen { HOME, PREVIEW }

/** أقصى مدة للفيديو الواحد: دقيقة. */
const val MAX_VIDEO_MS = 60_000L

/** أقصى مدة للفيديو الواحد في اللصق المتتالي وضغط الفيديو: 3 دقائق. */
const val MAX_VIDEO_MS_LONG = 180_000L
private const val SHORT_SIDE = 480

/** قيمة audioChoice التي تعني: استخدم الصوت المختار من الهاتف. */
const val AUDIO_PHONE = -2


/** مدة الصورة: 15 ثانية. */
private const val IMAGE_MS = 15_000L
private const val IN_BITRATE = 1_200_000
private const val OUT_BITRATE = 1_500_000

class RemixViewModel(app: Application) : AndroidViewModel(app) {

    val items = mutableStateListOf<MediaEntry>()
    var layout by mutableStateOf<RemixLayout?>(null)
        private set

    /** فهرس العنصر الأساسي (الذي يختاره المستخدم) داخل [items]. */
    var primaryIndex by mutableStateOf(0)
        private set

    /** الوضع الحالي: دمج / لصق متتالي / ضغط فيديو. */
    var mode by mutableStateOf(RemixMode.MERGE)
        private set

    var compressLevel by mutableStateOf(CompressLevel.MEDIUM)
        private set

    /** حجم آخر فيديو تم إنتاجه بالبايت (يُعرض بعد الحفظ). */
    var outputBytes by mutableStateOf(0L)
        private set
    var pipAudio by mutableStateOf(PipAudio.PRIMARY)
        private set

    var pipCorner by mutableStateOf(PipCorner.BOTTOM_RIGHT)
        private set

    /** true = الفيديو كامل بدون قص (حواف سوداء)، false = ملء الإطار مع قص الأطراف. */
    var fitFull by mutableStateOf(true)
        private set

    /** فهرس العنصر الذي يُسمع صوته، أو -1 لبدون صوت. */
    var audioChoice by mutableStateOf(0)
        private set

    /** صوت اختاره المستخدم من الهاتف (اختيار الصوت = -2). */
    var extraAudioUri by mutableStateOf<Uri?>(null)
        private set
    var extraAudioName by mutableStateOf("")
        private set
    var screen by mutableStateOf(Screen.HOME)
    var exportState by mutableStateOf<ExportState>(ExportState.Idle)
        private set

    var compressing by mutableStateOf(false)
        private set
    var compressIndex by mutableStateOf(0)
        private set
    var compressTotal by mutableStateOf(0)
        private set
    var compressProgress by mutableStateOf(0f)
        private set
    var skippedLong by mutableStateOf(0)
        private set
    var skippedDevice by mutableStateOf(0)
        private set

    /** هاتف ضعيف: يدعم فيديو مزدوج فقط. */
    val weakDevice: Boolean = DeviceCapability.isWeak(app)
    val maxVideos: Int get() = if (weakDevice) 2 else 4

    /** يتحول true عندما يحاول المستخدم بدء دمج وفيه دمج شغال؛ الواجهة تعرض رسالة ثم تصفّره. */
    var busyNotice by mutableStateOf(false)
        private set

    private val appCtx: Application = app
    private val prefs = app.getSharedPreferences("remix_state", Context.MODE_PRIVATE)
    private val inputsDir = File(app.filesDir, "inputs").apply { mkdirs() }

    // نطاق مستقل عن الشاشة: العمل يكمل حتى لو الـ Activity اتقفلت
    private val workScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var transformer: Transformer? = null
    private var importJob: Job? = null
    private var exportJob: Job? = null
    private var lastPercent = -1

    init {
        restore()
    }

    val availableLayouts: List<RemixLayout> get() = RemixLayout.forCount(items.size)

    /** أقصى عدد عناصر: ضغط الفيديو لفيديو واحد فقط. */
    val maxItems: Int get() = if (mode == RemixMode.COMPRESS) 1 else 4

    private val videoLimitMs: Long get() = if (mode == RemixMode.MERGE) MAX_VIDEO_MS else MAX_VIDEO_MS_LONG

    /** مقاس اللصق المتتالي: يتبع اتجاه أول فيديو (طولي أو عرضي). */
    val concatLayout: RemixLayout
        get() {
            val src = mergeOrder.map { items[it] }.firstOrNull { it.width > 0 && it.height > 0 }
            return if (src != null && src.width > src.height) RemixLayout.CONCAT_L else RemixLayout.CONCAT_P
        }

    /** الشكل الفعّال حسب الوضع (للمعاينة والعلامة المائية). */
    val activeLayout: RemixLayout?
        get() = when (mode) {
            RemixMode.MERGE -> layout
            RemixMode.CONCAT -> if (items.size >= 2) concatLayout else null
            RemixMode.COMPRESS -> null
        }

    /** هل العناصر الحالية جاهزة للمعاينة والحفظ في الوضع الحالي؟ */
    val canExport: Boolean
        get() = when (mode) {
            RemixMode.MERGE -> layout?.let { items.size >= 2 && items.size == it.count } == true
            RemixMode.CONCAT -> items.size >= 2
            RemixMode.COMPRESS -> items.size == 1
        }

    /**
     * ترتيب الدمج الفعلي (فهارس داخل [items]): العنصر الأساسي أولًا ثم باقي العناصر بترتيبها.
     * الأساسي يأخذ الخلية الأولى (فوق / يسار / الشاشة الكاملة في وضع الفيديو الصغير).
     */
    val mergeOrder: List<Int>
        get() {
            val p = primaryIndex.coerceIn(0, (items.size - 1).coerceAtLeast(0))
            return if (items.isEmpty()) emptyList() else listOf(p) + items.indices.filter { it != p }
        }

    fun isBusy(): Boolean = compressing || exportState is ExportState.Running || ExportService.busy

    fun consumeBusyNotice() {
        busyNotice = false
    }

    val audioIndex: Int
        get() {
            if (audioChoice == -1 || audioChoice == AUDIO_PHONE) return -1
            val c = items.getOrNull(audioChoice)
            if (c != null && c.isVideo) return audioChoice
            return items.indexOfFirst { it.isVideo }
        }

    // ───────────────────── حفظ واسترجاع الحالة ─────────────────────

    private fun persist() {
        val arr = JSONArray()
        items.forEach {
            arr.put(
                JSONObject()
                    .put("p", it.uri.path ?: "")
                    .put("v", it.isVideo)
                    .put("d", it.durationMs)
                    .put("s", it.shortSide)
                    .put("w", it.width)
                    .put("h", it.height),
            )
        }
        prefs.edit()
            .putString("items", arr.toString())
            .putInt("audio", audioChoice)
            .putInt("primary", primaryIndex)
            .putString("mode", mode.name)
            .putString("clevel", compressLevel.name)
            .putString("xaudio", extraAudioUri?.path)
            .putString("xname", extraAudioName)
            .putString("pipPos", pipCorner.name)
            .putString("pipAudio", pipAudio.name)
            .putBoolean("fit", fitFull)
            .putString("layout", layout?.name)
            .apply()
    }

    private fun restore() {
        try {
            val raw = prefs.getString("items", null)
            if (raw != null) {
                val arr = JSONArray(raw)
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val f = File(o.getString("p"))
                    if (f.exists()) {
                        items.add(MediaEntry(Uri.fromFile(f), o.getBoolean("v"), o.getLong("d"), o.optInt("s", 0), o.optInt("w", 0), o.optInt("h", 0)))
                    }
                }
            }
        } catch (_: Exception) {
            items.clear()
        }
        mode = RemixMode.values().firstOrNull { it.name == prefs.getString("mode", null) } ?: RemixMode.MERGE
        compressLevel = CompressLevel.values().firstOrNull { it.name == prefs.getString("clevel", null) }
            ?: CompressLevel.MEDIUM
        if (mode == RemixMode.COMPRESS && items.size > 1) {
            while (items.size > 1) items.removeAt(items.lastIndex)
        }
        audioChoice = prefs.getInt("audio", 0)
        // قيمة قديمة (-3) كانت لوضع "واحد وراه واحد" المحذوف
        if (audioChoice < -2) audioChoice = 0
        primaryIndex = prefs.getInt("primary", 0).coerceIn(0, (items.size - 1).coerceAtLeast(0))
        prefs.getString("xaudio", null)?.let { p ->
            val f = File(p)
            if (f.exists()) {
                extraAudioUri = Uri.fromFile(f)
                extraAudioName = prefs.getString("xname", "") ?: ""
            }
        }
        if (audioChoice == AUDIO_PHONE && extraAudioUri == null) audioChoice = 0
        fitFull = prefs.getBoolean("fit", true)
        pipCorner = PipCorner.values().firstOrNull { it.name == prefs.getString("pipPos", null) }
            ?: PipCorner.BOTTOM_RIGHT
        pipAudio = PipAudio.values().firstOrNull { it.name == prefs.getString("pipAudio", null) }
            ?: PipAudio.PRIMARY
        val saved = prefs.getString("layout", null)
        val options = RemixLayout.forCount(items.size)
        layout = options.firstOrNull { it.name == saved } ?: options.firstOrNull()
        // حذف أي ملفات غير مستخدمة
        val used = items.map { File(it.uri.path ?: "").name }.toSet() +
            listOfNotNull(extraAudioUri?.path?.let { File(it).name })
        inputsDir.listFiles()?.forEach { if (it.name !in used) it.delete() }
        // ملفات مؤقتة قديمة
        appCtx.cacheDir.listFiles()?.forEach { if (it.name.startsWith("remix_")) it.delete() }
    }

    private fun deleteFilesOf(list: List<MediaEntry>) {
        list.forEach { e ->
            val f = File(e.uri.path ?: return@forEach)
            if (f.parentFile == inputsDir) f.delete()
        }
    }

    // ───────────────────── استيراد وضغط 480 ─────────────────────

    fun addUris(uris: List<Uri>) = importUris(uris, replace = false)

    fun replaceUris(uris: List<Uri>) = importUris(uris, replace = true)

    private fun importUris(uris: List<Uri>, replace: Boolean) {
        if (isBusy()) {
            busyNotice = true
            return
        }
        ExportService.busy = true
        importJob = workScope.launch {
            val room = if (replace) maxItems else maxItems - items.size
            val picked = uris.take(room)
            if (picked.isEmpty()) {
                ExportService.busy = false
                return@launch
            }
            compressing = true
            compressTotal = picked.size
            compressIndex = 0
            compressProgress = 0f
            skippedLong = 0
            skippedDevice = 0
            ExportService.start(appCtx, appCtx.getString(R.string.notif_working))
            val result = mutableListOf<MediaEntry>()
            try {
                for (u in picked) {
                    compressIndex++
                    compressProgress = 0f
                    lastPercent = -1
                    val e = withContext(Dispatchers.IO) { readEntry(u) }
                    if (mode == RemixMode.COMPRESS && !e.isVideo) continue
                    if (e.isVideo && e.durationMs > videoLimitMs + 500) {
                        skippedLong++
                        continue
                    }
                    val videosSoFar = (if (replace) 0 else items.count { it.isVideo }) + result.count { it.isVideo }
                    if (mode == RemixMode.MERGE && e.isVideo && videosSoFar >= maxVideos) {
                        skippedDevice++
                        continue
                    }
                    result += if (e.isVideo) prepareVideo(e) else withContext(Dispatchers.IO) { normalizeImage(e) }
                }
            } catch (ex: CancellationException) {
                deleteFilesOf(result)
                throw ex
            } finally {
                compressing = false
                ExportService.busy = false
                ExportService.stop(appCtx)
            }
            if (replace) {
                deleteFilesOf(items.toList())
                items.clear()
                primaryIndex = 0
            }
            items.addAll(result)
            refreshLayout()
            persist()
            // معاينة تلقائية: بمجرد اكتمال الاختيار ننتقل لشاشة المعاينة بدون ضغط زر
            if (result.isNotEmpty() && canExport) screen = Screen.PREVIEW
        }
    }

    private fun readEntry(uri: Uri): MediaEntry {
        val type = appCtx.contentResolver.getType(uri) ?: ""
        val isVideo = type.startsWith("video")
        var duration = 0L
        var shortSide = 0
        var dispW = 0
        var dispH = 0
        if (isVideo) {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(appCtx, uri)
                duration = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
                val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
                val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
                if (w > 0 && h > 0) {
                    shortSide = minOf(w, h)
                    val swap = rot == 90 || rot == 270
                    dispW = if (swap) h else w
                    dispH = if (swap) w else h
                }
            } catch (_: Exception) {
            } finally {
                try { r.release() } catch (_: Exception) {}
            }
        }
        return MediaEntry(uri, isVideo, duration, shortSide, dispW, dispH)
    }

    private fun copyToInputs(src: Uri, name: String): File? {
        return try {
            val out = File(inputsDir, name)
            val input = appCtx.contentResolver.openInputStream(src) ?: return null
            input.use { i -> out.outputStream().use { o -> i.copyTo(o) } }
            out
        } catch (_: Exception) {
            null
        }
    }

    /** يفك الصورة بحجم معقول ويطبّق اتجاه EXIF حتى لا تظهر مقلوبة أو بأبعاد غريبة. */
    private fun decodeOriented(uri: Uri, maxSide: Int): Bitmap? {
        return try {
            val cr = appCtx.contentResolver
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= maxSide) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val raw = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null
            val orientation = try {
                cr.openInputStream(uri)?.use {
                    ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
                } ?: ExifInterface.ORIENTATION_NORMAL
            } catch (_: Exception) {
                ExifInterface.ORIENTATION_NORMAL
            }
            val matrix = Matrix()
            when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
                ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
                ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
                ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.postScale(-1f, 1f)
                ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.postScale(1f, -1f)
                ExifInterface.ORIENTATION_TRANSPOSE -> { matrix.postRotate(90f); matrix.postScale(-1f, 1f) }
                ExifInterface.ORIENTATION_TRANSVERSE -> { matrix.postRotate(270f); matrix.postScale(-1f, 1f) }
            }
            if (matrix.isIdentity) raw else Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, matrix, true)
        } catch (_: Throwable) {
            null
        }
    }

    /** توحيد الصورة عند الاستيراد: اتجاه صحيح، أقصى ضلع 1280، أبعاد زوجية، حفظ JPEG. */
    private fun normalizeImage(e: MediaEntry): MediaEntry {
        val bmp = decodeOriented(e.uri, 1280) ?: return copyImage(e)
        return try {
            val f = minOf(1f, 1280f / maxOf(bmp.width, bmp.height))
            val ew = evenSize(bmp.width * f)
            val eh = evenSize(bmp.height * f)
            val scaled = if (ew == bmp.width && eh == bmp.height) bmp else Bitmap.createScaledBitmap(bmp, ew, eh, true)
            val out = File(inputsDir, "img_${System.nanoTime()}.jpg")
            out.outputStream().use { scaled.compress(Bitmap.CompressFormat.JPEG, 90, it) }
            if (scaled !== bmp) bmp.recycle()
            e.copy(uri = Uri.fromFile(out), width = ew, height = eh)
        } catch (_: Throwable) {
            copyImage(e)
        }
    }

    /** يرسم الصورة بالضبط على مقاس الخلية مع حواف سوداء (Pad) أو قص (Fill). */
    private fun renderPadded(src: Uri, w: Int, h: Int, fit: Boolean, out: File) {
        val bmp = decodeOriented(src, 1600) ?: throw IllegalStateException("image decode failed")
        val canvasBmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(canvasBmp)
        c.drawColor(Color.BLACK)
        val scale = if (fit) minOf(w.toFloat() / bmp.width, h.toFloat() / bmp.height)
        else maxOf(w.toFloat() / bmp.width, h.toFloat() / bmp.height)
        val dw = bmp.width * scale
        val dh = bmp.height * scale
        val dst = RectF((w - dw) / 2f, (h - dh) / 2f, (w + dw) / 2f, (h + dh) / 2f)
        c.drawBitmap(bmp, null, dst, Paint(Paint.FILTER_BITMAP_FLAG))
        out.outputStream().use { canvasBmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
        bmp.recycle()
        canvasBmp.recycle()
    }

    /**
     * وضع الأمان: يوحّد كل عنصر (فيديو أو صورة) على مقاس خليته بالضبط مع حواف سوداء
     * قبل الدمج، لتفادي أخطاء معالجة الإطارات مع الأبعاد المختلفة.
     */
    private suspend fun unifyEntries(
        entries: List<MediaEntry>,
        sizes: List<Pair<Int, Int>>,
        fit: Boolean,
        temps: MutableList<File>,
        onProgress: (Float) -> Unit,
    ): List<MediaEntry> {
        val layoutMode = if (fit) Presentation.LAYOUT_SCALE_TO_FIT else Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP
        val result = mutableListOf<MediaEntry>()
        for ((i, e) in entries.withIndex()) {
            val (w, h) = sizes[i]
            val base = i.toFloat() / entries.size
            val span = 1f / entries.size
            if (e.isVideo) {
                val out = File(appCtx.cacheDir, "unify_${System.nanoTime()}.mp4")
                temps += out
                val item = EditedMediaItem.Builder(MediaItem.fromUri(e.uri))
                    .setEffects(Effects(emptyList(), listOf(Presentation.createForWidthAndHeight(w, h, layoutMode))))
                    .build()
                awaitTransformer(
                    start = { it.start(item, out.absolutePath) },
                    onProgress = { onProgress(base + it * span) },
                    bitrate = IN_BITRATE,
                )
                result += e.copy(uri = Uri.fromFile(out), width = w, height = h, shortSide = minOf(w, h))
            } else {
                val out = File(appCtx.cacheDir, "unify_${System.nanoTime()}.jpg")
                temps += out
                withContext(Dispatchers.IO) { renderPadded(e.uri, w, h, fit, out) }
                onProgress(base + span)
                result += e.copy(uri = Uri.fromFile(out), width = w, height = h)
            }
        }
        return result
    }

    private fun copyImage(e: MediaEntry): MediaEntry {
        val type = appCtx.contentResolver.getType(e.uri) ?: ""
        val ext = when {
            type.contains("png") -> "png"
            type.contains("webp") -> "webp"
            type.contains("heic") -> "heic"
            else -> "jpg"
        }
        val f = copyToInputs(e.uri, "img_${System.nanoTime()}.$ext") ?: return e
        return e.copy(uri = Uri.fromFile(f))
    }

    /** يحفظ الفيديو داخل التطبيق بدقة 480 (ضغط خفيف، أو نسخ مباشر لو هو أصلًا 480 أو أقل). */
    private suspend fun prepareVideo(e: MediaEntry): MediaEntry {
        val out = File(inputsDir, "v_${System.nanoTime()}.mp4")
        // توحيد: تصغير لـ 480 أو تصحيح الأبعاد الفردية (تسبب أخطاء في معالجة الإطارات)
        val needsCompress = mode != RemixMode.COMPRESS && e.width > 0 && e.height > 0 &&
            (e.shortSide > SHORT_SIDE || e.width % 2 != 0 || e.height % 2 != 0)
        if (needsCompress) {
            try {
                // تصغير بحيث الضلع الأقصر = 480 مع الحفاظ على النسبة
                val factor = minOf(1f, SHORT_SIDE.toFloat() / minOf(e.width, e.height))
                val outW = evenSize(e.width * factor)
                val outH = evenSize(e.height * factor)
                val item = EditedMediaItem.Builder(MediaItem.fromUri(e.uri))
                    .setEffects(
                        Effects(
                            emptyList(),
                            listOf(Presentation.createForWidthAndHeight(outW, outH, Presentation.LAYOUT_SCALE_TO_FIT)),
                        ),
                    )
                    .build()
                awaitTransformer(
                    start = { it.start(item, out.absolutePath) },
                    onProgress = {
                        compressProgress = it
                        notifyProgress(R.string.notif_compressing, it)
                    },
                    bitrate = IN_BITRATE,
                )
                return e.copy(uri = Uri.fromFile(out), shortSide = minOf(outW, outH), width = outW, height = outH)
            } catch (ex: CancellationException) {
                out.delete()
                throw ex
            } catch (ex: Exception) {
                out.delete()
            }
        }
        // لا حاجة للضغط أو فشل الضغط: نسخة كما هي داخل التطبيق
        val copied = withContext(Dispatchers.IO) { copyToInputs(e.uri, out.name) }
        return if (copied != null) e.copy(uri = Uri.fromFile(copied)) else e
    }

    private fun evenSize(v: Float): Int = maxOf(2, (v.roundToInt() / 2) * 2)

    private fun notifyProgress(textRes: Int, fraction: Float) {
        val pct = (fraction * 100).toInt()
        if (pct == lastPercent) return
        lastPercent = pct
        ExportService.update(appCtx, appCtx.getString(textRes, pct), pct)
    }

    // ───────────────────── التحكم في القائمة والخيارات ─────────────────────

    fun removeAt(index: Int) {
        if (compressing || exportState is ExportState.Running) return
        if (index in items.indices) {
            val removed = items.removeAt(index)
            deleteFilesOf(listOf(removed))
            if (audioChoice == index) audioChoice = 0 else if (audioChoice > index) audioChoice--
            if (primaryIndex == index) primaryIndex = 0 else if (primaryIndex > index) primaryIndex--
        }
        refreshLayout()
        persist()
    }

    /** اختيار ملف صوت من الهاتف ليكون صوت الفيديو الناتج. */
    fun importAudio(uri: Uri) {
        if (exportState is ExportState.Running) return
        workScope.launch {
            val type = appCtx.contentResolver.getType(uri) ?: ""
            val ext = when {
                type.contains("mpeg") || type.contains("mp3") -> "mp3"
                type.contains("mp4") || type.contains("m4a") || type.contains("aac") -> "m4a"
                type.contains("wav") -> "wav"
                type.contains("ogg") -> "ogg"
                else -> "mp3"
            }
            val name = withContext(Dispatchers.IO) { displayName(uri) }
            val copied = withContext(Dispatchers.IO) { copyToInputs(uri, "aud_${System.nanoTime()}.$ext") }
            if (copied != null) {
                removeExtraAudioFile()
                extraAudioUri = Uri.fromFile(copied)
                extraAudioName = name
                audioChoice = AUDIO_PHONE
                persist()
            }
        }
    }

    fun removeExtraAudio() {
        if (exportState is ExportState.Running) return
        removeExtraAudioFile()
        if (audioChoice == AUDIO_PHONE) audioChoice = 0
        persist()
    }

    private fun removeExtraAudioFile() {
        extraAudioUri?.path?.let { File(it).delete() }
        extraAudioUri = null
        extraAudioName = ""
    }

    private fun displayName(uri: Uri): String = try {
        appCtx.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
            ?: "audio"
    } catch (_: Exception) {
        "audio"
    }

    fun clearAll() {
        if (compressing || exportState is ExportState.Running) return
        deleteFilesOf(items.toList())
        removeExtraAudioFile()
        if (audioChoice == AUDIO_PHONE) audioChoice = 0
        items.clear()
        primaryIndex = 0
        refreshLayout()
        persist()
    }

    fun reverse() {
        val reversed = items.reversed()
        items.clear()
        items.addAll(reversed)
        if (audioChoice >= 0) audioChoice = items.size - 1 - audioChoice
        primaryIndex = items.size - 1 - primaryIndex
        persist()
    }

    /** تحريك عنصر لأعلى/لأسفل لترتيب الفيديوهات واحد وراه واحد. */
    fun move(index: Int, delta: Int) {
        if (isBusy()) return
        val to = index + delta
        if (index !in items.indices || to !in items.indices) return
        val e = items.removeAt(index)
        items.add(to, e)
        if (audioChoice == index) audioChoice = to else if (audioChoice == to) audioChoice = index
        if (primaryIndex == index) primaryIndex = to else if (primaryIndex == to) primaryIndex = index
        persist()
    }

    fun switchMode(m: RemixMode) {
        if (m == mode || isBusy()) return
        if (m == RemixMode.COMPRESS) {
            // ضغط الفيديو لفيديو واحد: نبقي أول فيديو (الأساسي) فقط
            val keep = mergeOrder.map { items[it] }.firstOrNull { it.isVideo }
            val drop = items.filter { it !== keep }
            deleteFilesOf(drop)
            items.clear()
            if (keep != null) items.add(keep)
            primaryIndex = 0
        }
        mode = m
        screen = Screen.HOME
        refreshLayout()
        persist()
    }

    fun selectCompressLevel(level: CompressLevel) {
        compressLevel = level
        exportState = ExportState.Idle
        persist()
    }

    /** يحدد العنصر الأساسي الذي سيُعتمد عليه في الدمج. */
    fun selectPrimary(index: Int) {
        if (isBusy()) return
        if (index !in items.indices) return
        primaryIndex = index
        exportState = ExportState.Idle
        persist()
    }

    fun selectLayout(l: RemixLayout) {
        layout = l
        persist()
    }

    fun selectPipCorner(c: PipCorner) {
        pipCorner = c
        persist()
    }

    fun selectPipAudio(a: PipAudio) {
        pipAudio = a
        // اختيار صوت من خيارات الريأكشن يلغي "بدون صوت" أو صوت الهاتف
        if (audioChoice < 0) audioChoice = 0
        persist()
    }

    fun selectFit(full: Boolean) {
        fitFull = full
        persist()
    }

    fun selectAudio(index: Int) {
        audioChoice = index
        persist()
    }

    fun resetExport() {
        exportState = ExportState.Idle
    }

    private fun refreshLayout() {
        val options = availableLayouts
        layout = if (options.isEmpty()) null else if (layout in options) layout else options.first()
        if (audioChoice >= items.size) audioChoice = 0
        if (audioChoice == AUDIO_PHONE && extraAudioUri == null) audioChoice = 0
        primaryIndex = primaryIndex.coerceIn(0, (items.size - 1).coerceAtLeast(0))
        exportState = ExportState.Idle
    }

    /** إلغاء الضغط أو الدمج الجاري. */
    fun cancel() {
        importJob?.cancel()
        exportJob?.cancel()
        transformer?.cancel()
        if (exportState is ExportState.Running) exportState = ExportState.Idle
    }

    // ───────────────────────── التصدير ─────────────────────────

    /** [pro] = شاهد إعلان المكافأة → بدون علامة مائية. */
    fun export(pro: Boolean) {
        val m = mode
        if (!canExport) return
        if (isBusy()) {
            busyNotice = true
            return
        }
        // الأساسي أولًا ثم الباقي: يتغير ترتيب الخلايا وفق اختيار المستخدم
        val order = mergeOrder
        val snapshot = order.map { items[it] }
        val audioIdx = order.indexOf(audioIndex)
        val pipMode = mode == RemixMode.MERGE && layout?.isPip == true
        val pipSel = pipAudio
        val phoneAudio = if (audioChoice == AUDIO_PHONE) extraAudioUri else null
        val keepOriginalAudio = audioChoice != -1 && audioChoice != AUDIO_PHONE
        // أي فيديو يحتفظ بصوته: في الريأكشن حسب اختيار المستخدم، وغيره حسب الفيديو المختار
        val audioMask: List<Boolean> = snapshot.indices.map { i ->
            when {
                !keepOriginalAudio -> false
                pipMode -> when (pipSel) {
                    PipAudio.PRIMARY -> i == 0
                    PipAudio.SMALL -> i == 1
                    PipAudio.BOTH -> true
                }
                else -> i == audioIdx
            }
        }
        val corner = pipCorner
        val fit = fitFull
        val mergeLayout = layout
        val cl = concatLayout
        val level = compressLevel
        exportState = ExportState.Running(0f)
        lastPercent = -1
        ExportService.busy = true
        ExportService.start(appCtx, appCtx.getString(R.string.notif_working))
        exportJob = workScope.launch {
            val outFile = File(appCtx.cacheDir, "remix_${System.currentTimeMillis()}.mp4")
            val temps = mutableListOf<File>()
            try {
                suspend fun encode(entries: List<MediaEntry>, base: Float, span: Float) {
                    val composition = when (m) {
                        RemixMode.MERGE -> buildComposition(
                            entries, mergeLayout!!, audioMask, phoneAudio, corner, fit, watermark = !pro,
                        )
                        RemixMode.CONCAT -> buildConcatComposition(
                            entries, cl, phoneAudio, keepOriginalAudio, fit, watermark = !pro,
                        )
                        RemixMode.COMPRESS -> buildCompressComposition(entries.first(), level, watermark = !pro)
                    }
                    awaitTransformer(
                        start = { it.start(composition, outFile.absolutePath) },
                        onProgress = {
                            val p = base + it * span
                            exportState = ExportState.Running(p)
                            notifyProgress(R.string.notif_merging, p)
                        },
                        bitrate = if (m == RemixMode.COMPRESS) level.bitrate else OUT_BITRATE,
                    )
                }
                try {
                    encode(snapshot, 0f, 1f)
                } catch (ex: CancellationException) {
                    throw ex
                } catch (ex: Exception) {
                    if (m == RemixMode.COMPRESS) throw ex
                    // فشل معالجة الإطارات (غالبًا اختلاف الأبعاد): نوحّد كل العناصر ثم نعيد الدمج تلقائيًا
                    outFile.delete()
                    exportState = ExportState.Running(0f)
                    val sizes = snapshot.indices.map { i ->
                        if (m == RemixMode.MERGE) {
                            mergeLayout!!.cellWidthPx(i, corner) to mergeLayout.cellHeightPx(i, corner)
                        } else {
                            cl.canvasW to cl.canvasH
                        }
                    }
                    val unified = unifyEntries(snapshot, sizes, fit, temps) {
                        exportState = ExportState.Running(it * 0.5f)
                        notifyProgress(R.string.notif_merging, it * 0.5f)
                    }
                    encode(unified, 0.5f, 0.5f)
                }
                outputBytes = outFile.length()
                val uri = withContext(Dispatchers.IO) { saveToGallery(outFile) }
                exportState = ExportState.Done(uri)
                ExportService.done(appCtx, appCtx.getString(R.string.notif_done))
            } catch (e: CancellationException) {
                exportState = ExportState.Idle
                throw e
            } catch (e: Exception) {
                // رسالة خطأ مفصلة (رمز الخطأ + السبب) لتسهيل التشخيص
                val detail = buildString {
                    append(e.message ?: e.javaClass.simpleName)
                    (e as? ExportException)?.let { append(" [").append(it.errorCodeName).append("]") }
                    e.cause?.message?.let { append(" — ").append(it.take(160)) }
                }
                exportState = ExportState.Error(detail)
                ExportService.done(appCtx, appCtx.getString(R.string.notif_failed))
            } finally {
                outFile.delete()
                temps.forEach { it.delete() }
                transformer = null
                ExportService.busy = false
                ExportService.stop(appCtx)
            }
        }
    }

    /** لصق متتالي: كل العناصر واحدًا بعد الآخر في فيديو واحد بنفس مقاس الإطار. */
    private fun buildConcatComposition(
        entries: List<MediaEntry>,
        l: RemixLayout,
        phoneAudio: Uri?,
        keepOriginalAudio: Boolean,
        fit: Boolean,
        watermark: Boolean,
    ): Composition {
        val layoutMode = if (fit) Presentation.LAYOUT_SCALE_TO_FIT else Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP
        val edited = entries.map { e ->
            val effects = Effects(
                emptyList(),
                listOf(Presentation.createForWidthAndHeight(l.canvasW, l.canvasH, layoutMode)),
            )
            val b = EditedMediaItem.Builder(MediaItem.fromUri(e.uri)).setEffects(effects)
            if (e.isVideo) {
                b.setRemoveAudio(!keepOriginalAudio)
            } else {
                b.setDurationUs(IMAGE_MS * 1000).setFrameRate(30)
            }
            b.build()
        }
        val sequences = mutableListOf(EditedMediaItemSequence.Builder(*edited.toTypedArray()).build())
        if (phoneAudio != null) {
            val audioItem = EditedMediaItem.Builder(MediaItem.fromUri(phoneAudio)).build()
            sequences.add(EditedMediaItemSequence.Builder(audioItem).setIsLooping(true).build())
        }
        val builder = Composition.Builder(sequences)
            .setHdrMode(Composition.HDR_MODE_TONE_MAP_HDR_TO_SDR_USING_OPEN_GL)
        if (watermark) {
            builder.setEffects(Effects(emptyList(), listOf(watermarkEffect(minOf(l.canvasW, l.canvasH)))))
        }
        return builder.build()
    }

    /** ضغط فيديو منفرد: تصغير المقاس (أقصر ضلع) + خفض معدل البيانات حسب المستوى. */
    private fun buildCompressComposition(e: MediaEntry, level: CompressLevel, watermark: Boolean): Composition {
        var outMin = if (e.width > 0 && e.height > 0) minOf(e.width, e.height) else 480
        val videoEffects = mutableListOf<androidx.media3.common.Effect>()
        if (e.width > 0 && e.height > 0 && minOf(e.width, e.height) > level.shortSide) {
            val factor = level.shortSide.toFloat() / minOf(e.width, e.height)
            val w = evenSize(e.width * factor)
            val h = evenSize(e.height * factor)
            videoEffects += Presentation.createForWidthAndHeight(w, h, Presentation.LAYOUT_SCALE_TO_FIT)
            outMin = minOf(w, h)
        }
        val item = EditedMediaItem.Builder(MediaItem.fromUri(e.uri))
            .setEffects(Effects(emptyList(), videoEffects))
            .build()
        val builder = Composition.Builder(listOf(EditedMediaItemSequence.Builder(item).build()))
        if (watermark) {
            builder.setEffects(Effects(emptyList(), listOf(watermarkEffect(outMin))))
        }
        return builder.build()
    }

    private fun buildComposition(
        entries: List<MediaEntry>,
        l: RemixLayout,
        audioMask: List<Boolean>,
        phoneAudio: Uri?,
        corner: PipCorner,
        fit: Boolean,
        watermark: Boolean,
    ): Composition {
        // كامل بدون قص (حواف سوداء) أو ملء الإطار مع قص الأطراف
        val layoutMode = if (fit) Presentation.LAYOUT_SCALE_TO_FIT else Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP
        val sequences = mutableListOf<EditedMediaItemSequence>()
        var compositor: VideoCompositorSettings? = null

        run {
            val cells = l.cells(corner)
            val maxVideoMs = entries.filter { it.isVideo }.maxOfOrNull { it.durationMs }?.takeIf { it > 0 } ?: IMAGE_MS
            val totalUs = maxVideoMs * 1000
            entries.forEachIndexed { i, e ->
                val effects = Effects(
                    emptyList(),
                    listOf(
                        Presentation.createForWidthAndHeight(
                            l.cellWidthPx(i, corner),
                            l.cellHeightPx(i, corner),
                            layoutMode,
                        ),
                    ),
                )
                val item = EditedMediaItem.Builder(MediaItem.fromUri(e.uri)).setEffects(effects)
                if (e.isVideo) {
                    item.setRemoveAudio(!audioMask.getOrElse(i) { false })
                } else {
                    item.setDurationUs(totalUs).setFrameRate(30)
                }
                val seq = EditedMediaItemSequence.Builder(item.build())
                if (e.isVideo && e.durationMs in 1 until (maxVideoMs - 50)) seq.setIsLooping(true)
                sequences.add(seq.build())
            }
            compositor = object : VideoCompositorSettings {
                override fun getOutputSize(inputSizes: List<Size>): Size = Size(l.canvasW, l.canvasH)

                override fun getOverlaySettings(inputId: Int, presentationTimeUs: Long): OverlaySettings {
                    val c = cells[inputId.coerceIn(0, cells.lastIndex)]
                    val ax = (c.x + c.w / 2f) * 2f - 1f
                    val ay = 1f - (c.y + c.h / 2f) * 2f
                    return OverlaySettings.Builder()
                        .setBackgroundFrameAnchor(ax, ay)
                        .setOverlayFrameAnchor(0f, 0f)
                        .build()
                }
            }
        }

        // صوت من الهاتف: مسار صوت مستقل يتكرر حتى ينتهي الفيديو (وأصوات الفيديوهات مكتومة)
        if (phoneAudio != null) {
            val audioItem = EditedMediaItem.Builder(MediaItem.fromUri(phoneAudio)).build()
            sequences.add(EditedMediaItemSequence.Builder(audioItem).setIsLooping(true).build())
        }

        val builder = Composition.Builder(sequences)
            .setHdrMode(Composition.HDR_MODE_TONE_MAP_HDR_TO_SDR_USING_OPEN_GL)
        compositor?.let { builder.setVideoCompositorSettings(it) }
        if (watermark) {
            builder.setEffects(Effects(emptyList(), listOf(watermarkEffect(minOf(l.canvasW, l.canvasH)))))
        }
        return builder.build()
    }

    /** علامة مائية: أيقونة التطبيق شبه شفافة في منتصف الفيديو. */
    private fun watermarkEffect(minSide: Int): OverlayEffect {
        val src = BitmapFactory.decodeResource(appCtx.resources, R.drawable.watermark_logo)
        val targetW = (minSide * 0.55f).toInt().coerceAtLeast(64)
        val targetH = (targetW * src.height.toFloat() / src.width).toInt().coerceAtLeast(1)
        val bmp = Bitmap.createScaledBitmap(src, targetW, targetH, true)
        val settings = OverlaySettings.Builder()
            .setBackgroundFrameAnchor(0f, 0f)
            .setOverlayFrameAnchor(0f, 0f)
            .setAlphaScale(0.4f)
            .build()
        val overlay = BitmapOverlay.createStaticBitmapOverlay(bmp, settings)
        return OverlayEffect(ImmutableList.of<TextureOverlay>(overlay))
    }

    /** يشغّل Transformer وينتظر انتهاءه، مع تحديث التقدّم على الخيط الرئيسي. */
    private suspend fun awaitTransformer(
        start: (Transformer) -> Unit,
        onProgress: (Float) -> Unit,
        bitrate: Int? = null,
    ) {
        val holder = ProgressHolder()
        coroutineScopeProgress { register ->
            suspendCancellableCoroutine<Unit> { cont ->
                val builder = Transformer.Builder(appCtx)
                    .setVideoMimeType(MimeTypes.VIDEO_H264)
                    .setAudioMimeType(MimeTypes.AUDIO_AAC)
                if (bitrate != null) {
                    builder.setEncoderFactory(
                        DefaultEncoderFactory.Builder(appCtx)
                            .setRequestedVideoEncoderSettings(
                                VideoEncoderSettings.Builder().setBitrate(bitrate).build(),
                            )
                            .build(),
                    )
                }
                val t = builder
                    .addListener(object : Transformer.Listener {
                        override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                            if (cont.isActive) cont.resume(Unit)
                        }

                        override fun onError(
                            composition: Composition,
                            exportResult: ExportResult,
                            exportException: ExportException,
                        ) {
                            if (cont.isActive) cont.resumeWithException(exportException)
                        }
                    })
                    .build()
                transformer = t
                start(t)
                register {
                    if (t.getProgress(holder) == Transformer.PROGRESS_STATE_AVAILABLE) {
                        onProgress(holder.progress / 100f)
                    }
                }
                cont.invokeOnCancellation { t.cancel() }
            }
        }
    }

    private suspend fun coroutineScopeProgress(
        block: suspend (registerPoll: (() -> Unit) -> Unit) -> Unit,
    ) {
        var poll: (() -> Unit)? = null
        val poller = workScope.launch {
            while (isActive) {
                delay(300)
                poll?.invoke()
            }
        }
        try {
            block { poll = it }
        } finally {
            poller.cancel()
        }
    }

    private fun saveToGallery(file: File): Uri {
        val name = "WaleedRemix_${System.currentTimeMillis()}.mp4"
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/WaleedRemix")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            } else {
                @Suppress("DEPRECATION")
                val dir = File(
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES),
                    "WaleedRemix",
                )
                dir.mkdirs()
                @Suppress("DEPRECATION")
                put(MediaStore.Video.Media.DATA, File(dir, name).absolutePath)
            }
        }
        val resolver = appCtx.contentResolver
        val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: error("Could not create gallery entry")
        resolver.openOutputStream(uri)!!.use { out -> file.inputStream().use { it.copyTo(out) } }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val done = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
            resolver.update(uri, done, null, null)
        }
        return uri
    }
}
